import React, { useState, useEffect, useCallback, useRef } from 'react';
import ReactDOM from 'react-dom/client';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { w3cwebsocket as W3CWebSocket } from 'websocket';
import axios from 'axios';
import './index.css';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const API_BASE_URL = 'http://localhost:8000';
const WS_URL = 'ws://localhost:8000/ws';

// Interfaces
interface MarketData {
  symbol: string;
  timeframe: string;
  timestamp: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

interface TradingSignal {
  symbol: string;
  timeframe: string;
  signal_type: string;
  confidence: number;
  entry_price: number;
  stop_loss: number;
  take_profit: number;
  timestamp: string;
  model_predictions: { [key: string]: number };
  indicators: { [key: string]: number };
  risk_reward_ratio: number;
  position_size: number;
  expected_return: number;
}

interface Prediction {
  symbol: string;
  timeframe: string;
  predicted_price: number;
  confidence: number;
  direction: string;
  timestamp: string;
  model_name: string;
  features_used: string[];
  uncertainty: number;
  volatility: number;
}

interface PortfolioMetrics {
  symbol: string;
  weight: number;
  expected_return: number;
  volatility: number;
  sharpe_ratio: number;
}

interface BacktestResult {
  symbol: string;
  timeframe: string;
  total_return: number;
  sharpe_ratio: number;
  max_drawdown: number;
  win_rate: number;
  trades: number;
  timestamp: string;
}

// WebSocket Manager
class WebSocketManager {
  private client: W3CWebSocket | null = null;
  private reconnectAttempts: number = 0;
  private maxReconnectAttempts: number = 5;
  private reconnectInterval: number = 5000;

  constructor(private url: string, private onMessage: (data: any) => void) {}

  connect() {
    this.client = new W3CWebSocket(this.url);
    
    this.client.onopen = () => {
      console.log('WebSocket connected');
      this.reconnectAttempts = 0;
      this.sendSubscription();
    };

    this.client.onmessage = (event) => {
      const data = JSON.parse(event.data.toString());
      this.onMessage(data);
    };

    this.client.onclose = () => {
      console.log('WebSocket disconnected');
      this.handleReconnect();
    };

    this.client.onerror = (error) => {
      console.error('WebSocket error:', error);
      this.client?.close();
    };
  }

  private handleReconnect() {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++;
      setTimeout(() => {
        console.log(`Reconnecting WebSocket... Attempt ${this.reconnectAttempts}`);
        this.connect();
      }, this.reconnectInterval);
    } else {
      console.error('Max reconnect attempts reached');
    }
  }

  sendSubscription() {
    if (this.client?.readyState === W3CWebSocket.OPEN) {
      this.client.send(JSON.stringify({
        type: 'subscribe',
        symbols: ['BTCUSDT', 'ETHUSDT', 'ADAUSDT'],
        timeframes: ['1h', '4h', '1d'],
      }));
    }
  }

  sendHeartbeat() {
    if (this.client?.readyState === W3CWebSocket.OPEN) {
      this.client.send(JSON.stringify({ type: 'heartbeat' }));
    }
  }

  disconnect() {
    this.client?.close();
    this.client = null;
  }
}

// Main App Component
const App: React.FC = () => {
  const [symbols, setSymbols] = useState<string[]>([]);
  const [selectedSymbol, setSelectedSymbol] = useState<string>('BTCUSDT');
  const [selectedTimeframe, setSelectedTimeframe] = useState<string>('1h');
  const [marketData, setMarketData] = useState<MarketData[]>([]);
  const [signals, setSignals] = useState<TradingSignal[]>([]);
  const [predictions, setPredictions] = useState<Prediction[]>([]);
  const [portfolioMetrics, setPortfolioMetrics] = useState<PortfolioMetrics[]>([]);
  const [backtestResults, setBacktestResults] = useState<BacktestResult[]>([]);
  const wsRef = useRef<WebSocketManager | null>(null);

  // Fetch initial data
  useEffect(() => {
    const fetchSymbols = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}/symbols`);
        setSymbols(response.data.symbols);
      } catch (error) {
        console.error('Error fetching symbols:', error);
      }
    };

    fetchSymbols();
  }, []);

  useEffect(() => {
    const fetchMarketData = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}/market-data/${selectedSymbol}/${selectedTimeframe}`);
        setMarketData(response.data.data);
      } catch (error) {
        console.error('Error fetching market data:', error);
      }
    };

    fetchMarketData();
  }, [selectedSymbol, selectedTimeframe]);

  // WebSocket setup
  useEffect(() => {
    wsRef.current = new WebSocketManager(WS_URL, (data) => {
      switch (data.type) {
        case 'signal_update':
          setSignals((prev) => [...prev, data.data.signal].slice(-10));
          break;
        case 'prediction_update':
          setPredictions((prev) => [...prev, data.data.prediction].slice(-10));
          break;
        case 'portfolio_update':
          setPortfolioMetrics(data.data.metrics);
          break;
        case 'backtest_update':
          setBacktestResults((prev) => [...prev, data.data].slice(-10));
          break;
        case 'heartbeat_ack':
          console.log('Heartbeat received:', data.timestamp);
          break;
      }
    });

    wsRef.current.connect();

    const heartbeatInterval = setInterval(() => {
      wsRef.current?.sendHeartbeat();
    }, 30000);

    return () => {
      wsRef.current?.disconnect();
      clearInterval(heartbeatInterval);
    };
  }, []);

  // Chart data
  const chartData = {
    labels: marketData.map((d) => new Date(d.timestamp).toLocaleTimeString()),
    datasets: [
      {
        label: `${selectedSymbol} Price`,
        data: marketData.map((d) => d.close),
        borderColor: 'rgb(75, 192, 192)',
        tension: 0.1,
      },
    ],
  };

  // Handle symbol/timeframe change
  const handleSymbolChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedSymbol(e.target.value);
  };

  const handleTimeframeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedTimeframe(e.target.value);
  };

  // Retrain models
  const handleRetrain = async () => {
    try {
      await axios.post(`${API_BASE_URL}/retrain-models/${selectedSymbol}/${selectedTimeframe}`);
      alert('Model retraining started');
    } catch (error) {
      console.error('Error starting retrain:', error);
      alert('Failed to start retraining');
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4">
      <div className="container mx-auto">
        <h1 className="text-3xl font-bold mb-6">Advanced Trading Dashboard</h1>

        {/* Controls */}
        <div className="mb-6 flex space-x-4">
          <select
            className="bg-gray-800 text-white p-2 rounded"
            value={selectedSymbol}
            onChange={handleSymbolChange}
          >
            {symbols.map((symbol) => (
              <option key={symbol} value={symbol}>
                {symbol}
              </option>
            ))}
          </select>
          <select
            className="bg-gray-800 text-white p-2 rounded"
            value={selectedTimeframe}
            onChange={handleTimeframeChange}
          >
            {['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w'].map((tf) => (
              <option key={tf} value={tf}>
                {tf}
              </option>
            ))}
          </select>
          <button
            className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
            onClick={handleRetrain}
          >
            Retrain Models
          </button>
        </div>

        {/* Price Chart */}
        <div className="mb-6">
          <h2 className="text-xl font-semibold mb-2">Price Chart</h2>
          <div className="bg-gray-800 p-4 rounded">
            <Line data={chartData} options={{ responsive: true, maintainAspectRatio: false }} />
          </div>
        </div>

        {/* Signals */}
        <div className="mb-6">
          <h2 className="text-xl font-semibold mb-2">Latest Signals</h2>
          <div className="bg-gray-800 p-4 rounded">
            <table className="w-full text-left">
              <thead>
                <tr>
                  <th>Symbol</th>
                  <th>Timeframe</th>
                  <th>Signal</th>
                  <th>Confidence</th>
                  <th>Entry Price</th>
                  <th>Stop Loss</th>
                  <th>Take Profit</th>
                  <th>Timestamp</th>
                </tr>
              </thead>
              <tbody>
                {signals.map((signal, index) => (
                  <tr key={index}>
                    <td>{signal.symbol}</td>
                    <td>{signal.timeframe}</td>
                    <td className={signal.signal_type === 'buy' ? 'text-green-400' : signal.signal_type === 'sell' ? 'text-red-400' : 'text-yellow-400'}>
                      {signal.signal_type.toUpperCase()}
                    </td>
                    <td>{(signal.confidence * 100).toFixed(2)}%</td>
                    <td>{signal.entry_price.toFixed(2)}</td>
                    <td>{signal.stop_loss.toFixed(2)}</td>
                    <td>{signal.take_profit.toFixed(2)}</td>
                    <td>{new Date(signal.timestamp).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Predictions */}
        <div className="mb-6">
          <h2 className="text-xl font-semibold mb-2">Latest Predictions</h2>
          <div className="bg-gray-800 p-4 rounded">
            <table className="w-full text-left">
              <thead>
                <tr>
                  <th>Symbol</th>
                  <th>Timeframe</th>
                  <th>Predicted Price</th>
                  <th>Confidence</th>
                  <th>Direction</th>
                  <th>Timestamp</th>
                </tr>
              </thead>
              <tbody>
                {predictions.map((pred, index) => (
                  <tr key={index}>
                    <td>{pred.symbol}</td>
                    <td>{pred.timeframe}</td>
                    <td>{pred.predicted_price.toFixed(2)}</td>
                    <td>{(pred.confidence * 100).toFixed(2)}%</td>
                    <td className={pred.direction === 'up' ? 'text-green-400' : 'text-red-400'}>
                      {pred.direction.toUpperCase()}
                    </td>
                    <td>{new Date(pred.timestamp).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Portfolio Metrics */}
        <div className="mb-6">
          <h2 className="text-xl font-semibold mb-2">Portfolio Metrics</h2>
          <div className="bg-gray-800 p-4 rounded">
            <table className="w-full text-left">
              <thead>
                <tr>
                  <th>Symbol</th>
                  <th>Weight</th>
                  <th>Expected Return</th>
                  <th>Volatility</th>
                  <th>Sharpe Ratio</th>
                </tr>
              </thead>
              <tbody>
                {portfolioMetrics.map((metric, index) => (
                  <tr key={index}>
                    <td>{metric.symbol}</td>
                    <td>{(metric.weight * 100).toFixed(2)}%</td>
                    <td>{(metric.expected_return * 100).toFixed(2)}%</td>
                    <td>{(metric.volatility * 100).toFixed(2)}%</td>
                    <td>{metric.sharpe_ratio.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Backtest Results */}
        <div className="mb-6">
          <h2 className="text-xl font-semibold mb-2">Backtest Results</h2>
          <div className="bg-gray-800 p-4 rounded">
            <table className="w-full text-left">
              <thead>
                <tr>
                  <th>Symbol</th>
                  <th>Timeframe</th>
                  <th>Total Return</th>
                  <th>Sharpe Ratio</th>
                  <th>Max Drawdown</th>
                  <th>Win Rate</th>
                  <th>Trades</th>
                </tr>
              </thead>
              <tbody>
                {backtestResults.map((result, index) => (
                  <tr key={index}>
                    <td>{result.symbol}</td>
                    <td>{result.timeframe}</td>
                    <td>{(result.total_return * 100).toFixed(2)}%</td>
                    <td>{result.sharpe_ratio.toFixed(2)}</td>
                    <td>{(result.max_drawdown * 100).toFixed(2)}%</td>
                    <td>{(result.win_rate * 100).toFixed(2)}%</td>
                    <td>{result.trades}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

// Render
const root = ReactDOM.createRoot(document.getElementById('root') as HTMLElement);
root.render(<App />);