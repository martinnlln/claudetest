import asyncio
import logging
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import json
import pandas as pd
import numpy as np
from dataclasses import dataclass, asdict
import sqlite3
from contextlib import asynccontextmanager
import aiohttp
import asyncio
from concurrent.futures import ThreadPoolExecutor
import threading
import time
from queue import Queue
import warnings
warnings.filterwarnings('ignore')

# ML and Data Processing
import tensorflow as tf
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import MinMaxScaler, RobustScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import xgboost as xgb
import catboost as cb
from prophet import Prophet
from statsmodels.tsa.arima.model import ARIMA
import ta
import yfinance as yf
import ccxt
import websockets
import joblib
from scipy import stats
import redis
import hashlib
from pypfopt import EfficientFrontier, risk_models, expected_returns
from pypfopt.discrete_allocation import DiscreteAllocation
import talib
import numpy as np
from typing import Union
import math
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
import scipy.signal as signal
from tensorflow.keras.layers import Layer
import tensorflow.keras.backend as K
from tensorflow.keras import Model
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import requests
from bs4 import BeautifulSoup
import re

# Download NLTK data
nltk.download('vader_lexicon')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('trading_backend.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Configuration
@dataclass
class Config:
    BINANCE_API_KEY: str = os.getenv('BINANCE_API_KEY', '')
    BINANCE_SECRET_KEY: str = os.getenv('BINANCE_SECRET_KEY', '')
    SUPPORTED_TIMEFRAMES: List[str] = None
    SUPPORTED_SYMBOLS: List[str] = None
    MODEL_RETRAIN_HOURS: int = 4
    PREDICTION_LOOKBACK_DAYS: int = 60
    ENSEMBLE_MODELS: List[str] = None
    REDIS_HOST: str = 'localhost'
    REDIS_PORT: int = 6379
    REDIS_DB: int = 0
    WS_HEARTBEAT_INTERVAL: int = 30
    PORTFOLIO_VALUE: float = 100000.0
    MAX_POSITION_SIZE: float = 0.1
    RISK_PER_TRADE: float = 0.02
    SENTIMENT_WEIGHT: float = 0.15
    MAX_NEWS_ARTICLES: int = 50
    BACKTEST_PERIODS: int = 252

    def __post_init__(self):
        if self.SUPPORTED_TIMEFRAMES is None:
            self.SUPPORTED_TIMEFRAMES = ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w']
        if self.SUPPORTED_SYMBOLS is None:
            self.SUPPORTED_SYMBOLS = ['BTCUSDT', 'ETHUSDT', 'ADAUSDT', 'DOTUSDT', 'LINKUSDT', 'BNBUSDT', 'XRPUSDT']
        if self.ENSEMBLE_MODELS is None:
            self.ENSEMBLE_MODELS = ['lstm', 'gru', 'transformer', 'xgboost', 'catboost', 'random_forest', 'prophet', 'arima', 'nbeats']

config = Config()

# Data Models
@dataclass
class MarketData:
    symbol: str
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float
    timeframe: str
    trades: Optional[int] = None
    quote_volume: Optional[float] = None

@dataclass
class TradingSignal:
    symbol: str
    timeframe: str
    signal_type: str
    confidence: float
    entry_price: float
    stop_loss: float
    take_profit: float
    timestamp: datetime
    model_predictions: Dict[str, float]
    indicators: Dict[str, float]
    risk_reward_ratio: float
    position_size: float
    expected_return: float

@dataclass
class PredictionResult:
    symbol: str
    timeframe: str
    predicted_price: float
    confidence: float
    direction: str
    timestamp: datetime
    model_name: str
    features_used: List[str]
    uncertainty: float
    volatility: float

@dataclass
class PortfolioMetrics:
    symbol: str
    weight: float
    expected_return: float
    volatility: float
    sharpe_ratio: float

@dataclass
class BacktestResult:
    symbol: str
    timeframe: str
    total_return: float
    sharpe_ratio: float
    max_drawdown: float
    win_rate: float
    trades: int
    timestamp: datetime

# Database Manager
class DatabaseManager:
    def __init__(self, db_path: str = 'trading_data.db'):
        self.db_path = db_path
        self.init_database()

    def init_database(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Market data table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS market_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                timeframe TEXT NOT NULL,
                timestamp INTEGER NOT NULL,
                open REAL NOT NULL,
                high REAL NOT NULL,
                low REAL NOT NULL,
                close REAL NOT NULL,
                volume REAL NOT NULL,
                trades INTEGER,
                quote_volume REAL,
                UNIQUE(symbol, timeframe, timestamp)
            )
        ''')

        # Predictions table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS predictions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                timeframe TEXT NOT NULL,
                timestamp INTEGER NOT NULL,
                predicted_price REAL NOT NULL,
                confidence REAL NOT NULL,
                direction TEXT NOT NULL,
                model_name TEXT NOT NULL,
                uncertainty REAL NOT NULL,
                volatility REAL NOT NULL,
                created_at INTEGER NOT NULL
            )
        ''')

        # Signals table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS signals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                timeframe TEXT NOT NULL,
                signal_type TEXT NOT NULL,
                confidence REAL NOT NULL,
                entry_price REAL NOT NULL,
                stop_loss REAL NOT NULL,
                take_profit REAL NOT NULL,
                risk_reward_ratio REAL NOT NULL,
                position_size REAL NOT NULL,
                expected_return REAL NOT NULL,
                timestamp INTEGER NOT NULL,
                created_at INTEGER NOT NULL
            )
        ''')

        # Portfolio metrics table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS portfolio_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                weight REAL NOT NULL,
                expected_return REAL NOT NULL,
                volatility REAL NOT NULL,
                sharpe_ratio REAL NOT NULL,
                timestamp INTEGER NOT NULL
            )
        ''')

        # Backtest results table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS backtest_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                timeframe TEXT NOT NULL,
                total_return REAL NOT NULL,
                sharpe_ratio REAL NOT NULL,
                max_drawdown REAL NOT NULL,
                win_rate REAL NOT NULL,
                trades INTEGER NOT NULL,
                timestamp INTEGER NOT NULL
            )
        ''')

        # Create indexes
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_market_data_symbol_timeframe ON market_data(symbol, timeframe)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_predictions_symbol_timeframe ON predictions(symbol, timeframe)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_signals_symbol_timeframe ON signals(symbol, timeframe)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_portfolio_metrics_symbol ON portfolio_metrics(symbol)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_backtest_results_symbol_timeframe ON backtest_results(symbol, timeframe)')

        conn.commit()
        conn.close()

    def insert_market_data(self, data: List[MarketData]):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        for item in data:
            cursor.execute('''
                INSERT OR REPLACE INTO market_data 
                (symbol, timeframe, timestamp, open, high, low, close, volume, trades, quote_volume)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                item.symbol, item.timeframe, int(item.timestamp.timestamp()),
                item.open, item.high, item.low, item.close, item.volume,
                item.trades, item.quote_volume
            ))

        conn.commit()
        conn.close()

    def get_market_data(self, symbol: str, timeframe: str, limit: int = 1000) -> List[MarketData]:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute('''
            SELECT symbol, timeframe, timestamp, open, high, low, close, volume, trades, quote_volume
            FROM market_data
            WHERE symbol = ? AND timeframe = ?
            ORDER BY timestamp DESC
            LIMIT ?
        ''', (symbol, timeframe, limit))

        rows = cursor.fetchall()
        conn.close()

        return [
            MarketData(
                symbol=row[0],
                timeframe=row[1],
                timestamp=datetime.fromtimestamp(row[2]),
                open=row[3],
                high=row[4],
                low=row[5],
                close=row[6],
                volume=row[7],
                trades=row[8],
                quote_volume=row[9]
            )
            for row in rows
        ]

    def insert_signal(self, signal: TradingSignal):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute('''
            INSERT INTO signals 
            (symbol, timeframe, signal_type, confidence, entry_price, stop_loss, take_profit,
             risk_reward_ratio, position_size, expected_return, timestamp, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            signal.symbol, signal.timeframe, signal.signal_type, signal.confidence,
            signal.entry_price, signal.stop_loss, signal.take_profit,
            signal.risk_reward_ratio, signal.position_size, signal.expected_return,
            int(signal.timestamp.timestamp()), int(datetime.now().timestamp())
        ))

        conn.commit()
        conn.close()

    def insert_prediction(self, prediction: PredictionResult):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute('''
            INSERT INTO predictions 
            (symbol, timeframe, timestamp, predicted_price, confidence, direction,
             model_name, uncertainty, volatility, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            prediction.symbol, prediction.timeframe, int(prediction.timestamp.timestamp()),
            prediction.predicted_price, prediction.confidence, prediction.direction,
            prediction.model_name, prediction.uncertainty, prediction.volatility,
            int(datetime.now().timestamp())
        ))

        conn.commit()
        conn.close()

    def insert_portfolio_metrics(self, metrics: List[PortfolioMetrics]):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        for metric in metrics:
            cursor.execute('''
                INSERT INTO portfolio_metrics 
                (symbol, weight, expected_return, volatility, sharpe_ratio, timestamp)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                metric.symbol, metric.weight, metric.expected_return,
                metric.volatility, metric.sharpe_ratio, int(datetime.now().timestamp())
            ))

        conn.commit()
        conn.close()

    def insert_backtest_result(self, result: BacktestResult):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute('''
            INSERT INTO backtest_results 
            (symbol, timeframe, total_return, sharpe_ratio, max_drawdown, win_rate, trades, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            result.symbol, result.timeframe, result.total_return, result.sharpe_ratio,
            result.max_drawdown, result.win_rate, result.trades, int(result.timestamp.timestamp())
        ))

        conn.commit()
        conn.close()

# Advanced Technical Indicators
class AdvancedTechnicalIndicators:
    @staticmethod
    def calculate_all_indicators(df: pd.DataFrame) -> Dict[str, Any]:
        indicators = {}
        try:
            # Basic Price Indicators
            indicators['sma_10'] = ta.trend.sma_indicator(df['close'], window=10).iloc[-1]
            indicators['sma_20'] = ta.trend.sma_indicator(df['close'], window=20).iloc[-1]
            indicators['sma_50'] = ta.trend.sma_indicator(df['close'], window=50).iloc[-1]
            indicators['ema_12'] = ta.trend.ema_indicator(df['close'], window=12).iloc[-1]
            indicators['ema_26'] = ta.trend.ema_indicator(df['close'], window=26).iloc[-1]
            indicators['wma_20'] = ta.trend.wma_indicator(df['close'], window=20).iloc[-1]

            # Momentum Indicators
            indicators['rsi_14'] = ta.momentum.rsi(df['close'], window=14).iloc[-1]
            indicators['rsi_7'] = ta.momentum.rsi(df['close'], window=7).iloc[-1]
            indicators['stoch_k'] = ta.momentum.stoch(df['high'], df['low'], df['close'], window=14).iloc[-1]
            indicators['stoch_d'] = ta.momentum.stoch_signal(df['high'], df['low'], df['close'], window=14).iloc[-1]
            indicators['williams_r'] = ta.momentum.williams_r(df['high'], df['low'], df['close'], window=14).iloc[-1]
            indicators['roc_10'] = ta.momentum.roc(df['close'], window=10).iloc[-1]
            indicators['cci_20'] = ta.trend.cci(df['high'], df['low'], df['close'], window=20).iloc[-1]

            # Volatility Indicators
            indicators['atr_14'] = ta.volatility.average_true_range(df['high'], df['low'], df['close'], window=14).iloc[-1]
            indicators['atr_7'] = ta.volatility.average_true_range(df['high'], df['low'], df['close'], window=7).iloc[-1]
            bb = ta.volatility.BollingerBands(df['close'], window=20, window_dev=2)
            indicators['bb_upper'] = bb.bollinger_hband().iloc[-1]
            indicators['bb_lower'] = bb.bollinger_lband().iloc[-1]
            indicators['bb_middle'] = bb.bollinger_mavg().iloc[-1]
            indicators['bb_width'] = (indicators['bb_upper'] - indicators['bb_lower']).iloc[-1]
            kc = ta.volatility.KeltnerChannel(df['high'], df['low'], df['close'], window=20)
            indicators['keltner_upper'] = kc.keltner_channel_hband().iloc[-1]
            indicators['keltner_lower'] = kc.keltner_channel_lband().iloc[-1]

            # Volume Indicators
            indicators['obv'] = ta.volume.on_balance_volume(df['close'], df['volume']).iloc[-1]
            indicators['cmf'] = ta.volume.chaikin_money_flow(df['high'], df['low'], df['close'], df['volume'], window=20).iloc[-1]
            indicators['vwap'] = ta.volume.volume_weighted_average_price(df['high'], df['low'], df['close'], df['volume']).iloc[-1]
            indicators['adi'] = ta.volume.acc_dist_index(df['high'], df['low'], df['close'], df['volume']).iloc[-1]

            # MACD
            macd = ta.trend.MACD(df['close'], window_slow=26, window_fast=12, window_sign=9)
            indicators['macd'] = macd.macd().iloc[-1]
            indicators['macd_signal'] = macd.macd_signal().iloc[-1]
            indicators['macd_histogram'] = macd.macd_diff().iloc[-1]

            # Advanced Indicators
            indicators['ichimoku_tenkan'] = ta.trend.ichimoku_a(df['high'], df['low'], window1=9, window2=26).iloc[-1]
            indicators['ichimoku_kijun'] = ta.trend.ichimoku_b(df['high'], df['low'], window2=26, window3=52).iloc[-1]
            indicators['supertrend'] = ta.trend.supertrend(df['high'], df['low'], df['close'], window=10, multiplier=3).iloc[-1]
            indicators['parabolic_sar'] = ta.trend.psar_up(df['high'], df['low'], df['close']).iloc[-1]
            indicators['dmi_plus'] = ta.trend.dmi(df['high'], df['low'], df['close'], window=14).iloc[-1]
            indicators['dmi_minus'] = ta.trend.adx_neg(df['high'], df['low'], df['close'], window=14).iloc[-1]
            indicators['adx'] = ta.trend.adx(df['high'], df['low'], df['close'], window=14).iloc[-1]

            # Volatility Adjusted Indicators
            indicators['volatility_adjusted_rsi'] = indicators['rsi_14'] / (1 + indicators['atr_14'] / df['close'].iloc[-1])
            indicators['volatility_ratio'] = indicators['atr_14'] / indicators['atr_7']
            indicators['price_volatility'] = df['close'].rolling(window=20).std().iloc[-1]

            # Sentiment-based Indicators
            indicators['momentum_score'] = (
                indicators['rsi_14'] * 0.3 +
                indicators['macd_histogram'] * 0.3 +
                indicators['stoch_k'] * 0.2 +
                indicators['roc_10'] * 0.2
            ) / 100

            # Cycle Indicators
            indicators['hurst'] = AdvancedTechnicalIndicators.calculate_hurst(df['close'])
            indicators['cycle_strength'] = AdvancedTechnicalIndicators.calculate_cycle_strength(df['close'])

        except Exception as e:
            logger.error(f"Error calculating indicators: {e}")
            indicators = {key: 0.0 for key in [
                'sma_10', 'sma_20', 'sma_50', 'ema_12', 'ema_26', 'wma_20',
                'rsi_14', 'rsi_7', 'stoch_k', 'stoch_d', 'williams_r', 'roc_10', 'cci_20',
                'atr_14', 'atr_7', 'bb_upper', 'bb_lower', 'bb_middle', 'bb_width',
                'keltner_upper', 'keltner_lower', 'obv', 'cmf', 'vwap', 'adi',
                'macd', 'macd_signal', 'macd_histogram', 'ichimoku_tenkan', 'ichimoku_kijun',
                'supertrend', 'parabolic_sar', 'dmi_plus', 'dmi_minus', 'adx',
                'volatility_adjusted_rsi', 'volatility_ratio', 'price_volatility',
                'momentum_score', 'hurst', 'cycle_strength'
            ]}

        return indicators

    @staticmethod
    def calculate_hurst(prices: pd.Series, lags: int = 100) -> float:
        try:
            prices = np.log(prices)
            variances = []
            for lag in range(2, lags + 1):
                tau = np.std(prices.diff(lag).dropna())
                variances.append(np.log(tau))
            m = np.polyfit(np.log(range(2, lags + 1)), variances, 1)
            return m[0] * 2.0
        except Exception as e:
            logger.error(f"Error calculating Hurst exponent: {e}")
            return 0.5

    @staticmethod
    def calculate_cycle_strength(prices: pd.Series, window: int = 20) -> float:
        try:
            fft = np.fft.fft(prices[-window:])
            power = np.abs(fft) ** 2
            return np.mean(power[1:window//2]) / np.std(power[1:window//2])
        except Exception as e:
            logger.error(f"Error calculating cycle strength: {e}")
            return 0.0

# Sentiment Analysis
class SentimentAnalyzer:
    def __init__(self):
        self.sid = SentimentIntensityAnalyzer()

    async def fetch_news(self, symbol: str) -> List[Dict]:
        try:
            async with aiohttp.ClientSession() as session:
                url = f"https://newsapi.org/v2/everything?q={symbol}&apiKey={os.getenv('NEWS_API_KEY', '')}"
                async with session.get(url) as response:
                    data = await response.json()
                    articles = data.get('articles', [])[:config.MAX_NEWS_ARTICLES]
                    return articles
        except Exception as e:
            logger.error(f"Error fetching news for {symbol}: {e}")
            return []

    def analyze_sentiment(self, text: str) -> float:
        try:
            scores = self.sid.polarity_scores(text)
            return scores['compound']
        except Exception as e:
            logger.error(f"Error analyzing sentiment: {e}")
            return 0.0

    async def get_symbol_sentiment(self, symbol: str) -> float:
        articles = await self.fetch_news(symbol)
        if not articles:
            return 0.0
        sentiments = [self.analyze_sentiment(article.get('title', '') + ' ' + article.get('description', '')) 
                     for article in articles]
        return np.mean(sentiments) if sentiments else 0.0

# Advanced ML Models
class AttentionLayer(Layer):
    def __init__(self, **kwargs):
        super(AttentionLayer, self).__init__(**kwargs)

    def build(self, input_shape):
        self.W = self.add_weight(name='attention_weight',
                                shape=(input_shape[-1], input_shape[-1]),
                                initializer='glorot_uniform',
                                trainable=True)
        self.b = self.add_weight(name='attention_bias',
                                shape=(input_shape[-1],),
                                initializer='zeros',
                                trainable=True)
        super(AttentionLayer, self).build(input_shape)

    def call(self, inputs):
        e = K.tanh(K.dot(inputs, self.W) + self.b)
        a = K.softmax(e, axis=1)
        output = inputs * a
        return K.sum(output, axis=1)

class NBeatsBlock(Layer):
    def __init__(self, units: int, theta_units: int, n_layers: int = 4, **kwargs):
        super(NBeatsBlock, self).__init__(**kwargs)
        self.units = units
        self.theta_units = theta_units
        self.n_layers = n_layers
        self.dense_layers = []
        self.theta_layer = tf.keras.layers.Dense(theta_units, activation=None)

        for _ in range(n_layers):
            self.dense_layers.append(
                tf.keras.layers.Dense(units, activation='relu')
            )

    def call(self, inputs):
        x = inputs
        for layer in self.dense_layers:
            x = layer(x)
        theta = self.theta_layer(x)
        return theta

class MLModelsManager:
    def __init__(self):
        self.models = {}
        self.scalers = {}
        self.feature_columns = [
            'open', 'high', 'low', 'close', 'volume',
            'sma_10', 'sma_20', 'sma_50', 'ema_12', 'ema_26', 'wma_20',
            'rsi_14', 'rsi_7', 'stoch_k', 'stoch_d', 'williams_r', 'roc_10', 'cci_20',
            'atr_14', 'atr_7', 'bb_upper', 'bb_lower', 'bb_middle', 'bb_width',
            'keltner_upper', 'keltner_lower', 'obv', 'cmf', 'vwap', 'adi',
            'macd', 'macd_signal', 'macd_histogram', 'ichimoku_tenkan', 'ichimoku_kijun',
            'supertrend', 'parabolic_sar', 'dmi_plus', 'dmi_minus', 'adx',
            'volatility_adjusted_rsi', 'volatility_ratio', 'price_volatility',
            'momentum_score', 'hurst', 'cycle_strength', 'sentiment_score'
        ]
        self.sentiment_analyzer = SentimentAnalyzer()

    def create_lstm_model(self, input_shape: tuple) -> tf.keras.Model:
        model = tf.keras.Sequential([
            tf.keras.layers.LSTM(256, return_sequences=True, input_shape=input_shape),
            tf.keras.layers.Dropout(0.3),
            tf.keras.layers.LSTM(128, return_sequences=True),
            tf.keras.layers.Dropout(0.3),
            tf.keras.layers.LSTM(64),
            tf.keras.layers.Dropout(0.3),
            tf.keras.layers.Dense(32, activation='relu'),
            tf.keras.layers.Dense(1)
        ])
        model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.0005), loss='mse', metrics=['mae'])
        return model

    def create_gru_model(self, input_shape: tuple) -> tf.keras.Model:
        model = tf.keras.Sequential([
            tf.keras.layers.GRU(256, return_sequences=True, input_shape=input_shape),
            tf.keras.layers.Dropout(0.3),
            tf.keras.layers.GRU(128, return_sequences=True),
            tf.keras.layers.Dropout(0.3),
            tf.keras.layers.GRU(64),
            tf.keras.layers.Dropout(0.3),
            tf.keras.layers.Dense(32, activation='relu'),
            tf.keras.layers.Dense(1)
        ])
        model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.0005), loss='mse', metrics=['mae'])
        return model

    def create_transformer_model(self, input_shape: tuple) -> tf.keras.Model:
        inputs = tf.keras.layers.Input(shape=input_shape)
        x = inputs
        for _ in range(4):
            attn_output = tf.keras.layers.MultiHeadAttention(num_heads=8, key_dim=64)(x, x)
            x = tf.keras.layers.LayerNormalization()(tf.keras.layers.Add()([x, attn_output]))
            ffn = tf.keras.layers.Dense(256, activation='relu')(x)
            ffn = tf.keras.layers.Dense(input_shape[-1])(ffn)
            x = tf.keras.layers.LayerNormalization()(tf.keras.layers.Add()([x, ffn]))
        x = tf.keras.layers.GlobalAveragePooling1D()(x)
        x = AttentionLayer()(x)
        x = tf.keras.layers.Dense(64, activation='relu')(x)
        x = tf.keras.layers.Dropout(0.3)(x)
        outputs = tf.keras.layers.Dense(1)(x)
        model = tf.keras.Model(inputs=inputs, outputs=outputs)
        model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.0005), loss='mse', metrics=['mae'])
        return model

    def create_nbeats_model(self, input_shape: tuple) -> tf.keras.Model:
        inputs = tf.keras.layers.Input(shape=input_shape)
        x = inputs
        for _ in range(3):
            block_output = NBeatsBlock(units=128, theta_units=64)(x)
            x = tf.keras.layers.Subtract()([x, block_output])
        x = tf.keras.layers.Dense(1)(x)
        model = tf.keras.Model(inputs=inputs, outputs=x)
        model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.0005), loss='mse', metrics=['mae'])
        return model

    async def prepare_features(self, df: pd.DataFrame, symbol: str) -> np.ndarray:
        indicators = AdvancedTechnicalIndicators.calculate_all_indicators(df)
        sentiment = await self.sentiment_analyzer.get_symbol_sentiment(symbol)
        indicators['sentiment_score'] = sentiment

        for key, value in indicators.items():
            df[key] = value

        features = df[self.feature_columns].fillna(0)
        return features.values

    def create_sequences(self, data: np.ndarray, target: np.ndarray, sequence_length: int = 60) -> Tuple[np.ndarray, np.ndarray]:
        X, y = [], []
        for i in range(sequence_length, len(data)):
            X.append(data[i-sequence_length:i])
            y.append(target[i])
        return np.array(X), np.array(y)

    def train_prophet_model(self, df: pd.DataFrame) -> Prophet:
        prophet_df = df[['timestamp', 'close']].rename(columns={'timestamp': 'ds', 'close': 'y'})
        model = Prophet(
            yearly_seasonality=True,
            weekly_seasonality=True,
            daily_seasonality=True,
            changepoint_prior_scale=0.05,
            seasonality_prior_scale=10.0
        )
        model.fit(prophet_df)
        return model

    def train_arima_model(self, series: pd.Series) -> ARIMA:
        model = ARIMA(series, order=(5, 1, 0))
        return model.fit()

    async def train_models(self, symbol: str, timeframe: str, df: pd.DataFrame):
        model_key = f"{symbol}_{timeframe}"
        try:
            features = await self.prepare_features(df.copy(), symbol)
            target = df['close'].values
            scaler = RobustScaler()
            features_scaled = scaler.fit_transform(features)
            self.scalers[model_key] = scaler
            models = {}
            sequence_length = 60

            if len(features_scaled) > sequence_length:
                X_seq, y_seq = self.create_sequences(features_scaled, target, sequence_length)
                X_train, X_test, y_train, y_test = train_test_split(X_seq, y_seq, test_size=0.2, random_state=42)

                # LSTM
                lstm_model = self.create_lstm_model((sequence_length, features_scaled.shape[1]))
                lstm_model.fit(X_train, y_train, epochs=50, batch_size=32, validation_data=(X_test, y_test), verbose=0)
                models['lstm'] = lstm_model

                # GRU
                gru_model = self.create_gru_model((sequence_length, features_scaled.shape[1]))
                gru_model.fit(X_train, y_train, epochs=50, batch_size=32, validation_data=(X_test, y_test), verbose=0)
                models['gru'] = gru_model

                # Transformer
                transformer_model = self.create_transformer_model((sequence_length, features_scaled.shape[1]))
                transformer_model.fit(X_train, y_train, epochs=50, batch_size=32, validation_data=(X_test, y_test), verbose=0)
                models['transformer'] = transformer_model

                # N-BEATS
                nbeats_model = self.create_nbeats_model((sequence_length, features_scaled.shape[1]))
                nbeats_model.fit(X_train, y_train, epochs=50, batch_size=32, validation_data=(X_test, y_test), verbose=0)
                models['nbeats'] = nbeats_model

            # Non-sequence models
            X_train_flat, X_test_flat, y_train_flat, y_test_flat = train_test_split(
                features_scaled, target, test_size=0.2, random_state=42
            )

            # XGBoost
            xgb_model = xgb.XGBRegressor(
                n_estimators=200,
                max_depth=7,
                learning_rate=0.05,
                random_state=42,
                n_jobs=-1
            )
            xgb_model.fit(X_train_flat, y_train_flat)
            models['xgboost'] = xgb_model

            # CatBoost
            cb_model = cb.CatBoostRegressor(
                iterations=200,
                learning_rate=0.05,
                depth=7,
                random_state=42,
                verbose=False
            )
            cb_model.fit(X_train_flat, y_train_flat)
            models['catboost'] = cb_model

            # Random Forest
            rf_model = RandomForestRegressor(
                n_estimators=200,
                max_depth=12,
                random_state=42,
                n_jobs=-1
            )
            rf_model.fit(X_train_flat, y_train_flat)
            models['random_forest'] = rf_model

            # Prophet
            prophet_model = self.train_prophet_model(df)
            models['prophet'] = prophet_model

            # ARIMA
            arima_model = self.train_arima_model(df['close'])
            models['arima'] = arima_model

            self.models[model_key] = models
            logger.info(f"Trained {len(models)} models for {symbol} {timeframe}")

        except Exception as e:
            logger.error(f"Error training models for {symbol} {timeframe}: {e}")

    async def predict(self, symbol: str, timeframe: str, df: pd.DataFrame) -> Dict[str, float]:
        model_key = f"{symbol}_{timeframe}"
        predictions = {}
        if model_key not in self.models:
            logger.warning(f"No models found for {symbol} {timeframe}")
            return predictions

        try:
            features = await self.prepare_features(df.copy(), symbol)
            if model_key in self.scalers:
                features_scaled = self.scalers[model_key].transform(features)
            else:
                features_scaled = features

            models = self.models[model_key]
            sequence_length = 60

            for model_name, model in models.items():
                try:
                    if model_name in ['lstm', 'gru', 'transformer', 'nbeats']:
                        if len(features_scaled) >= sequence_length:
                            X_seq = features_scaled[-sequence_length:].reshape(1, sequence_length, -1)
                            pred = model.predict(X_seq, verbose=0)[0][0]
                            predictions[model_name] = float(pred)
                    elif model_name == 'prophet':
                        future = model.make_future_dataframe(periods=1)
                        forecast = model.predict(future)
                        predictions[model_name] = float(forecast['yhat'].iloc[-1])
                    elif model_name == 'arima':
                        forecast = model.forecast(steps=1)
                        predictions[model_name] = float(forecast[0])
                    else:
                        X_flat = features_scaled[-1:].reshape(1, -1)
                        pred = model.predict(X_flat)[0]
                        predictions[model_name] = float(pred)
                except Exception as e:
                    logger.error(f"Error predicting with {model_name}: {e}")
                    continue
        except Exception as e:
            logger.error(f"Error generating predictions for {symbol} {timeframe}: {e}")
        return predictions

# Portfolio Optimization
class PortfolioOptimizer:
    @staticmethod
    def optimize_portfolio(df_dict: Dict[str, pd.DataFrame], symbols: List[str]) -> List[PortfolioMetrics]:
        try:
            prices = pd.DataFrame({symbol: df['close'] for symbol, df in df_dict.items()})
            prices = prices.dropna()
            
            mu = expected_returns.mean_historical_return(prices)
            S = risk_models.sample_cov(prices)
            
            ef = EfficientFrontier(mu, S)
            ef.max_sharpe()
            weights = ef.clean_weights()
            
            metrics = ef.portfolio_performance(verbose=False)
            
            portfolio_metrics = []
            for symbol in symbols:
                weight = weights.get(symbol, 0.0)
                if weight > 0:
                    portfolio_metrics.append(PortfolioMetrics(
                        symbol=symbol,
                        weight=weight,
                        expected_return=mu[symbol],
                        volatility=np.sqrt(S.loc[symbol, symbol]),
                        sharpe_ratio=metrics[2]
                    ))
            
            return portfolio_metrics
        except Exception as e:
            logger.error(f"Error optimizing portfolio: {e}")
            return []

# Backtesting Engine
class BacktestingEngine:
    def __init__(self, db: DatabaseManager, signal_generator):
        self.db = db
        self.signal_generator = signal_generator

    def run_backtest(self, symbol: str, timeframe: str, initial_capital: float = 100000) -> BacktestResult:
        try:
            data = self.db.get_market_data(symbol, timeframe, limit=config.BACKTEST_PERIODS)
            if len(data) < 100:
                return BacktestResult(symbol, timeframe, 0.0, 0.0, 0.0, 0.0, 0, datetime.now())

            df = pd.DataFrame([
                {
                    'timestamp': d.timestamp,
                    'open': d.open,
                    'high': d.high,
                    'low': d.low,
                    'close': d.close,
                    'volume': d.volume
                }
                for d in data
            ]).sort_values('timestamp')

            capital = initial_capital
            position = 0
            trades = []
            equity_curve = []

            for i in range(60, len(df)):
                window = df.iloc[:i]
                current_price = df.iloc[i]['close']
                signal = self.signal_generator.generate_signal(symbol, timeframe, window, current_price)

                if signal.signal_type == 'buy' and position == 0:
                    position_size = min(capital * config.MAX_POSITION_SIZE, capital * config.RISK_PER_TRADE / 
                                      (current_price - signal.stop_loss))
                    position = position_size / current_price
                    entry_price = current_price
                    trades.append({
                        'entry_price': entry_price,
                        'entry_time': df.iloc[i]['timestamp'],
                        'stop_loss': signal.stop_loss,
                        'take_profit': signal.take_profit
                    })
                elif position > 0:
                    current_trade = trades[-1]
                    if df.iloc[i]['low'] <= current_trade['stop_loss']:
                        capital += position * current_trade['stop_loss'] - position * current_trade['entry_price']
                        position = 0
                        trades[-1]['exit_price'] = current_trade['stop_loss']
                        trades[-1]['exit_time'] = df.iloc[i]['timestamp']
                    elif df.iloc[i]['high'] >= current_trade['take_profit']:
                        capital += position * current_trade['take_profit'] - position * current_trade['entry_price']
                        position = 0
                        trades[-1]['exit_price'] = current_trade['take_profit']
                        trades[-1]['exit_time'] = df.iloc[i]['timestamp']

                equity_curve.append(capital + position * current_price)

            total_return = (equity_curve[-1] - initial_capital) / initial_capital
            returns = pd.Series(equity_curve).pct_change().dropna()
            sharpe_ratio = np.sqrt(252) * returns.mean() / returns.std() if returns.std() != 0 else 0
            max_drawdown = max(1 - np.array(equity_curve) / pd.Series(equity_curve).cummax())
            win_trades = len([t for t in trades if 'exit_price' in t and t['exit_price'] > t['entry_price']])
            win_rate = win_trades / len(trades) if trades else 0

            return BacktestResult(
                symbol=symbol,
                timeframe=timeframe,
                total_return=total_return,
                sharpe_ratio=sharpe_ratio,
                max_drawdown=max_drawdown,
                win_rate=win_rate,
                trades=len(trades),
                timestamp=datetime.now()
            )
        except Exception as e:
            logger.error(f"Error running backtest for {symbol} {timeframe}: {e}")
            return BacktestResult(symbol, timeframe, 0.0, 0.0, 0.0, 0.0, 0, datetime.now())

# Data Fetcher
class DataFetcher:
    def __init__(self):
        self.binance = ccxt.binance({
            'apiKey': config.BINANCE_API_KEY,
            'secret': config.BINANCE_SECRET_KEY,
            'sandbox': False,
            'rateLimit': 1200,
            'options': {'defaultType': 'spot'}
        })

    async def fetch_symbols(self) -> List[str]:
        try:
            markets = self.binance.load_markets()
            symbols = [symbol for symbol in markets.keys() if symbol.endswith('USDT')]
            return symbols[:50]
        except Exception as e:
            logger.error(f"Error fetching symbols: {e}")
            return config.SUPPORTED_SYMBOLS

    async def fetch_historical_data(self, symbol: str, timeframe: str, limit: int = 1000) -> List[MarketData]:
        try:
            ohlcv = self.binance.fetch_ohlcv(symbol, timeframe, limit=limit)
            market_data = []
            for candle in ohlcv:
                market_data.append(MarketData(
                    symbol=symbol,
                    timestamp=datetime.fromtimestamp(candle[0] / 1000),
                    open=candle[1],
                    high=candle[2],
                    low=candle[3],
                    close=candle[4],
                    volume=candle[5],
                    timeframe=timeframe
                ))
            return market_data
        except Exception as e:
            logger.error(f"Error fetching historical data for {symbol} {timeframe}: {e}")
            return []

    async def fetch_live_price(self, symbol: str) -> Optional[float]:
        try:
            ticker = self.binance.fetch_ticker(symbol)
            return ticker['last']
        except Exception as e:
            logger.error(f"Error fetching live price for {symbol}: {e}")
            return None

# Signal Generator
class SignalGenerator:
    def __init__(self):
        self.ml_models = MLModelsManager()

    def generate_signal(self, symbol: str, timeframe: str, df: pd.DataFrame, 
                       current_price: float) -> TradingSignal:
        predictions = self.ml_models.predict(symbol, timeframe, df)
        indicators = AdvancedTechnicalIndicators.calculate_all_indicators(df)
        
        ensemble_prediction = np.mean(list(predictions.values())) if predictions else current_price
        confidence = self._calculate_confidence(predictions, indicators)
        signal_type = self._determine_signal_type(current_price, ensemble_prediction, indicators, confidence)
        stop_loss, take_profit = self._calculate_risk_levels(current_price, signal_type, indicators)
        risk_reward_ratio = abs((take_profit - current_price) / (current_price - stop_loss))
        position_size = self._calculate_position_size(current_price, stop_loss)
        expected_return = self._calculate_expected_return(current_price, ensemble_prediction, confidence)

        return TradingSignal(
            symbol=symbol,
            timeframe=timeframe,
            signal_type=signal_type,
            confidence=confidence,
            entry_price=current_price,
            stop_loss=stop_loss,
            take_profit=take_profit,
            timestamp=datetime.now(),
            model_predictions=predictions,
            indicators=indicators,
            risk_reward_ratio=risk_reward_ratio,
            position_size=position_size,
            expected_return=expected_return
        )

    def _calculate_confidence(self, predictions: Dict[str, float], indicators: Dict[str, float]) -> float:
        if not predictions:
            return 0.0

        pred_values = list(predictions.values())
        pred_variance = np.var(pred_values)
        confidence_from_variance = max(0, 1 - (pred_variance / 100))

        rsi = indicators.get('rsi_14', 50)
        macd_histogram = indicators.get('macd_histogram', 0)
        adx = indicators.get('adx', 25)
        sentiment_score = indicators.get('sentiment_score', 0)

        rsi_confidence = 0.5
        if rsi < 30 or rsi > 70:
            rsi_confidence = 0.8

        macd_confidence = 0.5
        if abs(macd_histogram) > 0.1:
            macd_confidence = 0.7

        adx_confidence = 0.5
        if adx > 25:
            adx_confidence = 0.8

        sentiment_confidence = min(1.0, max(0.0, 0.5 + config.SENTIMENT_WEIGHT * sentiment_score))

        total_confidence = (
            confidence_from_variance * 0.3 +
            rsi_confidence * 0.25 +
            macd_confidence * 0.25 +
            adx_confidence * 0.1 +
            sentiment_confidence * 0.1
        )

        return min(1.0, max(0.0, total_confidence))

    def _determine_signal_type(self, current_price: float, predicted_price: float,
                              indicators: Dict[str, float], confidence: float) -> str:
        price_change = (predicted_price - current_price) / current_price
        rsi = indicators.get('rsi_14', 50)
        macd_histogram = indicators.get('macd_histogram', 0)
        adx = indicators.get('adx', 25)
        sentiment_score = indicators.get('sentiment_score', 0)
        hurst = indicators.get('hurst', 0.5)

        bullish_conditions = [
            price_change > 0.02,
            rsi < 30,
            macd_histogram > 0,
            adx > 25,
            sentiment_score > 0.3,
            hurst > 0.5,
            confidence > 0.65
        ]

        bearish_conditions = [
            price_change < -0.02,
            rsi > 70,
            macd_histogram < 0,
            adx > 25,
            sentiment_score < -0.3,
            hurst > 0.5,
            confidence > 0.65
        ]

        bullish_score = sum(bullish_conditions)
        bearish_score = sum(bearish_conditions)

        if bullish_score >= 4:
            return 'buy'
        elif bearish_score >= 4:
            return 'sell'
        else:
            return 'hold'

    def _calculate_risk_levels(self, current_price: float, signal_type: str,
                              indicators: Dict[str, float]) -> Tuple[float, float]:
        atr = indicators.get('atr_14', current_price * 0.02)
        volatility = indicators.get('price_volatility', current_price * 0.01)

        if signal_type == 'buy':
            stop_loss = current_price - (2.5 * atr)
            take_profit = current_price + (4 * atr)
        elif signal_type == 'sell':
            stop_loss = current_price + (2.5 * atr)
            take_profit = current_price - (4 * atr)
        else:
            stop_loss = current_price - (1.5 * atr)
            take_profit = current_price + (1.5 * atr)

        return max(0, stop_loss), take_profit

    def _calculate_position_size(self, current_price: float, stop_loss: float) -> float:
        risk_amount = config.PORTFOLIO_VALUE * config.RISK_PER_TRADE
        risk_per_unit = abs(current_price - stop_loss)
        return risk_amount / risk_per_unit if risk_per_unit > 0 else 0

    def _calculate_expected_return(self, current_price: float, predicted_price: float, 
                                 confidence: float) -> float:
        expected_change = (predicted_price - current_price) / current_price
        return expected_change * confidence

# Connection Manager
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []
        self.connection_data: Dict[WebSocket, Dict] = {}

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        self.connection_data[websocket] = {
            'subscribed_symbols': set(),
            'subscribed_timeframes': set(),
            'last_heartbeat': datetime.now()
        }
        logger.info(f"WebSocket connected. Total connections: {len(self.active_connections)}")

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        if websocket in self.connection_data:
            del self.connection_data[websocket]
        logger.info(f"WebSocket disconnected. Total connections: {len(self.active_connections)}")

    async def send_personal_message(self, message: dict, websocket: WebSocket):
        try:
            await websocket.send_text(json.dumps(message))
        except Exception as e:
            logger.error(f"Error sending message to WebSocket: {e}")
            self.disconnect(websocket)

    async def broadcast(self, message: dict):
        disconnected = []
        for connection in self.active_connections:
            try:
                await connection.send_text(json.dumps(message))
            except Exception as e:
                logger.error(f"Error broadcasting to WebSocket: {e}")
                disconnected.append(connection)
        
        for conn in disconnected:
            self.disconnect(conn)

    async def send_to_subscribers(self, message: dict, symbol: str, timeframe: str = None):
        disconnected = []
        for connection in self.active_connections:
            try:
                conn_data = self.connection_data.get(connection, {})
                subscribed_symbols = conn_data.get('subscribed_symbols', set())
                subscribed_timeframes = conn_data.get('subscribed_timeframes', set())
                
                if symbol in subscribed_symbols and (timeframe is None or timeframe in subscribed_timeframes):
                    await connection.send_text(json.dumps(message))
            except Exception as e:
                logger.error(f"Error sending to subscriber: {e}")
                disconnected.append(connection)
        
        for conn in disconnected:
            self.disconnect(conn)

# Main Trading Engine
class TradingEngine:
    def __init__(self):
        self.db = DatabaseManager()
        self.data_fetcher = DataFetcher()
        self.signal_generator = SignalGenerator()
        self.connection_manager = ConnectionManager()
        self.backtesting_engine = BacktestingEngine(self.db, self.signal_generator)
        self.portfolio_optimizer = PortfolioOptimizer()
        self.is_running = False
        self.update_tasks = {}
        self.last_model_training = {}
        self.redis_client = None

        try:
            self.redis_client = redis.Redis(
                host=config.REDIS_HOST,
                port=config.REDIS_PORT,
                db=config.REDIS_DB,
                decode_responses=True
            )
            self.redis_client.ping()
            logger.info("Redis connection established")
        except Exception as e:
            logger.warning(f"Redis connection failed: {e}")

    async def start(self):
        self.is_running = True
        logger.info("Trading engine started")
        asyncio.create_task(self.initialize_data())
        asyncio.create_task(self.run_continuous_updates())
        asyncio.create_task(self.heartbeat_monitor())
        asyncio.create_task(self.run_portfolio_optimization())
        asyncio.create_task(self.run_backtesting())

    async def stop(self):
        self.is_running = False
        logger.info("Trading engine stopped")

    async def initialize_data(self):
        logger.info("Initializing data and training models...")
        symbols = await self.data_fetcher.fetch_symbols()
        
        for symbol in symbols[:15]:
            for timeframe in config.SUPPORTED_TIMEFRAMES:
                try:
                    historical_data = await self.data_fetcher.fetch_historical_data(symbol, timeframe, limit=1500)
                    if historical_data:
                        self.db.insert_market_data(historical_data)
                        df = pd.DataFrame([
                            {
                                'timestamp': d.timestamp,
                                'open': d.open,
                                'high': d.high,
                                'low': d.low,
                                'close': d.close,
                                'volume': d.volume
                            }
                            for d in historical_data
                        ])
                        await self.signal_generator.ml_models.train_models(symbol, timeframe, df)
                        self.last_model_training[f"{symbol}_{timeframe}"] = datetime.now()
                        logger.info(f"Initialized {symbol} {timeframe}")
                except Exception as e:
                    logger.error(f"Error initializing {symbol} {timeframe}: {e}")

    async def run_continuous_updates(self):
        while self.is_running:
            try:
                symbols = await self.data_fetcher.fetch_symbols()
                for symbol in symbols[:15]:
                    for timeframe in config.SUPPORTED_TIMEFRAMES:
                        await self.update_symbol_data(symbol, timeframe)
                await asyncio.sleep(60)
            except Exception as e:
                logger.error(f"Error in continuous updates: {e}")
                await asyncio.sleep(60)

    async def update_symbol_data(self, symbol: str, timeframe: str):
        try:
            latest_data = await self.data_fetcher.fetch_historical_data(symbol, timeframe, limit=100)
            if not latest_data:
                return

            self.db.insert_market_data(latest_data)
            historical_data = self.db.get_market_data(symbol, timeframe, limit=1500)
            
            if len(historical_data) < 100:
                return

            df = pd.DataFrame([
                {
                    'timestamp': d.timestamp,
                    'open': d.open,
                    'high': d.high,
                    'low': d.low,
                    'close': d.close,
                    'volume': d.volume
                }
                for d in historical_data
            ]).sort_values('timestamp')

            model_key = f"{symbol}_{timeframe}"
            last_training = self.last_model_training.get(model_key)
            
            if last_training is None or datetime.now() - last_training > timedelta(hours=config.MODEL_RETRAIN_HOURS):
                await self.signal_generator.ml_models.train_models(symbol, timeframe, df)
                self.last_model_training[model_key] = datetime.now()
                logger.info(f"Retrained models for {symbol} {timeframe}")

            current_price = latest_data[0].close
            signal = self.signal_generator.generate_signal(symbol, timeframe, df, current_price)
            self.db.insert_signal(signal)

            if self.redis_client:
                signal_key = f"signal:{symbol}:{timeframe}"
                signal_data = asdict(signal)
                signal_data['timestamp'] = signal.timestamp.isoformat()
                self.redis_client.setex(signal_key, 300, json.dumps(signal_data))

            await self.connection_manager.send_to_subscribers(
                {
                    'type': 'signal_update',
                    'data': {
                        'symbol': symbol,
                        'timeframe': timeframe,
                        'signal': asdict(signal),
                        'current_price': current_price,
                        'timestamp': datetime.now().isoformat()
                    }
                },
                symbol,
                timeframe
            )

            predictions = await self.signal_generator.ml_models.predict(symbol, timeframe, df)
            if predictions:
                ensemble_prediction = np.mean(list(predictions.values()))
                confidence = signal.confidence
                volatility = df['close'].rolling(window=20).std().iloc[-1]
                
                prediction_result = PredictionResult(
                    symbol=symbol,
                    timeframe=timeframe,
                    predicted_price=ensemble_prediction,
                    confidence=confidence,
                    direction='up' if ensemble_prediction > current_price else 'down',
                    timestamp=datetime.now(),
                    model_name='ensemble',
                    features_used=self.signal_generator.ml_models.feature_columns,
                    uncertainty=np.std(list(predictions.values())),
                    volatility=volatility
                )
                self.db.insert_prediction(prediction_result)

                await self.connection_manager.send_to_subscribers(
                    {
                        'type': 'prediction_update',
                        'data': {
                            'symbol': symbol,
                            'timeframe': timeframe,
                            'prediction': asdict(prediction_result),
                            'individual_predictions': predictions,
                            'timestamp': datetime.now().isoformat()
                        }
                    },
                    symbol,
                    timeframe
                )
        except Exception as e:
            logger.error(f"Error updating {symbol} {timeframe}: {e}")

    async def run_portfolio_optimization(self):
        while self.is_running:
            try:
                symbols = await self.data_fetcher.fetch_symbols()
                df_dict = {}
                for symbol in symbols[:15]:
                    historical_data = self.db.get_market_data(symbol, '1d', limit=252)
                    if historical_data:
                        df_dict[symbol] = pd.DataFrame([
                            {
                                'timestamp': d.timestamp,
                                'close': d.close
                            }
                            for d in historical_data
                        ]).set_index('timestamp')
                
                if df_dict:
                    portfolio_metrics = self.portfolio_optimizer.optimize_portfolio(df_dict, symbols[:15])
                    self.db.insert_portfolio_metrics(portfolio_metrics)
                    await self.connection_manager.broadcast({
                        'type': 'portfolio_update',
                        'data': {
                            'metrics': [asdict(metric) for metric in portfolio_metrics],
                            'timestamp': datetime.now().isoformat()
                        }
                    })
                await asyncio.sleep(3600)
            except Exception as e:
                logger.error(f"Error in portfolio optimization: {e}")
                await asyncio.sleep(3600)

    async def run_backtesting(self):
        while self.is_running:
            try:
                symbols = await self.data_fetcher.fetch_symbols()
                for symbol in symbols[:15]:
                    for timeframe in config.SUPPORTED_TIMEFRAMES:
                        result = self.backtesting_engine.run_backtest(symbol, timeframe)
                        self.db.insert_backtest_result(result)
                        await self.connection_manager.send_to_subscribers(
                            {
                                'type': 'backtest_update',
                                'data': asdict(result),
                                'timestamp': datetime.now().isoformat()
                            },
                            symbol,
                            timeframe
                        )
                await asyncio.sleep(86400)
            except Exception as e:
                logger.error(f"Error in backtesting: {e}")
                await asyncio.sleep(3600)

    async def heartbeat_monitor(self):
        while self.is_running:
            try:
                current_time = datetime.now()
                await self.connection_manager.broadcast({
                    'type': 'heartbeat',
                    'timestamp': current_time.isoformat(),
                    'server_status': 'healthy'
                })
                await asyncio.sleep(config.WS_HEARTBEAT_INTERVAL)
            except Exception as e:
                logger.error(f"Error in heartbeat monitor: {e}")
                await asyncio.sleep(30)

# FastAPI App
@asynccontextmanager
async def lifespan(app: FastAPI):
    await trading_engine.start()
    yield
    await trading_engine.stop()

app = FastAPI(
    title="Advanced Trading Backend",
    description="Professional-grade ML-powered trading platform with advanced analytics",
    version="2.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return {
        "message": "Advanced Trading Backend API",
        "version": "2.0.0",
        "status": "running",
        "supported_symbols": config.SUPPORTED_SYMBOLS,
        "supported_timeframes": config.SUPPORTED_TIMEFRAMES
    }

@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "active_connections": len(trading_engine.connection_manager.active_connections),
        "models_trained": len(trading_engine.signal_generator.ml_models.models)
    }

@app.get("/symbols")
async def get_symbols():
    try:
        symbols = await trading_engine.data_fetcher.fetch_symbols()
        return {"symbols": symbols}
    except Exception as e:
        logger.error(f"Error fetching symbols: {e}")
        return {"symbols": config.SUPPORTED_SYMBOLS}

@app.get("/market-data/{symbol}/{timeframe}")
async def get_market_data(symbol: str, timeframe: str, limit: int = 100):
    try:
        data = trading_engine.db.get_market_data(symbol, timeframe, limit)
        return {
            "symbol": symbol,
            "timeframe": timeframe,
            "data": [asdict(d) for d in data]
        }
    except Exception as e:
        logger.error(f"Error fetching market data: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/signal/{symbol}/{timeframe}")
async def get_signal(symbol: str, timeframe: str):
    try:
        if trading_engine.redis_client:
            signal_key = f"signal:{symbol}:{timeframe}"
            cached_signal = trading_engine.redis_client.get(signal_key)
            if cached_signal:
                return json.loads(cached_signal)

        historical_data = trading_engine.db.get_market_data(symbol, timeframe, limit=1500)
        if not historical_data:
            raise HTTPException(status_code=404, detail="No data available")

        df = pd.DataFrame([
            {
                'timestamp': d.timestamp,
                'open': d.open,
                'high': d.high,
                'low': d.low,
                'close': d.close,
                'volume': d.volume
            }
            for d in historical_data
        ])
        current_price = historical_data[0].close
        signal = trading_engine.signal_generator.generate_signal(symbol, timeframe, df, current_price)
        return asdict(signal)
    except Exception as e:
        logger.error(f"Error getting signal: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/predictions/{symbol}/{timeframe}")
async def get_predictions(symbol: str, timeframe: str):
    try:
        historical_data = trading_engine.db.get_market_data(symbol, timeframe, limit=1500)
        if not historical_data:
            raise HTTPException(status_code=404, detail="No data available")

        df = pd.DataFrame([
            {
                'timestamp': d.timestamp,
                'open': d.open,
                'high': d.high,
                'low': d.low,
                'close': d.close,
                'volume': d.volume
            }
            for d in historical_data
        ])
        predictions = await trading_engine.signal_generator.ml_models.predict(symbol, timeframe, df)
        if predictions:
            ensemble_prediction = np.mean(list(predictions.values()))
            current_price = historical_data[0].close
            volatility = df['close'].rolling(window=20).std().iloc[-1]
            return {
                "symbol": symbol,
                "timeframe": timeframe,
                "current_price": current_price,
                "ensemble_prediction": ensemble_prediction,
                "individual_predictions": predictions,
                "direction": "up" if ensemble_prediction > current_price else "down",
                "price_change_percent": ((ensemble_prediction - current_price) / current_price) * 100,
                "volatility": volatility,
                "timestamp": datetime.now().isoformat()
            }
        else:
            return {
                "symbol": symbol,
                "timeframe": timeframe,
                "error": "No predictions available"
            }
    except Exception as e:
        logger.error(f"Error getting predictions: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/indicators/{symbol}/{timeframe}")
async def get_indicators(symbol: str, timeframe: str):
    try:
        historical_data = trading_engine.db.get_market_data(symbol, timeframe, limit=200)
        if not historical_data:
            raise HTTPException(status_code=404, detail="No data available")

        df = pd.DataFrame([
            {
                'timestamp': d.timestamp,
                'open': d.open,
                'high': d.high,
                'low': d.low,
                'close': d.close,
                'volume': d.volume
            }
            for d in historical_data
        ])
        indicators = AdvancedTechnicalIndicators.calculate_all_indicators(df)
        return {
            "symbol": symbol,
            "timeframe": timeframe,
            "indicators": indicators,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error getting indicators: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/retrain-models/{symbol}/{timeframe}")
async def retrain_models(symbol: str, timeframe: str, background_tasks: BackgroundTasks):
    try:
        background_tasks.add_task(retrain_models_task, symbol, timeframe)
        return {
            "message": f"Model retraining started for {symbol} {timeframe}",
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error starting model retraining: {e}")
        raise HTTPException(status_code=500, detail=str(e))

async def retrain_models_task(symbol: str, timeframe: str):
    try:
        historical_data = trading_engine.db.get_market_data(symbol, timeframe, limit=1500)
        if not historical_data:
            return

        df = pd.DataFrame([
            {
                'timestamp': d.timestamp,
                'open': d.open,
                'high': d.high,
                'low': d.low,
                'close': d.close,
                'volume': d.volume
            }
            for d in historical_data
        ])
        await trading_engine.signal_generator.ml_models.train_models(symbol, timeframe, df)
        trading_engine.last_model_training[f"{symbol}_{timeframe}"] = datetime.now()
        logger.info(f"Completed model retraining for {symbol} {timeframe}")
    except Exception as e:
        logger.error(f"Error in model retraining task: {e}")

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await trading_engine.connection_manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            message = json.loads(data)
            
            if message.get('type') == 'subscribe':
                symbols = message.get('symbols', [])
                timeframes = message.get('timeframes', [])
                conn_data = trading_engine.connection_manager.connection_data[websocket]
                conn_data['subscribed_symbols'].update(symbols)
                conn_data['subscribed_timeframes'].update(timeframes)
                await trading_engine.connection_manager.send_personal_message(
                    {
                        'type': 'subscription_confirmed',
                        'symbols': list(conn_data['subscribed_symbols']),
                        'timeframes': list(conn_data['subscribed_timeframes'])
                    },
                    websocket
                )
            elif message.get('type') == 'unsubscribe':
                symbols = message.get('symbols', [])
                timeframes = message.get('timeframes', [])
                conn_data = trading_engine.connection_manager.connection_data[websocket]
                conn_data['subscribed_symbols'].difference_update(symbols)
                conn_data['subscribed_timeframes'].difference_update(timeframes)
                await trading_engine.connection_manager.send_personal_message(
                    {
                        'type': 'unsubscription_confirmed',
                        'symbols': list(conn_data['subscribed_symbols']),
                        'timeframes': list(conn_data['subscribed_timeframes'])
                    },
                    websocket
                )
            elif message.get('type') == 'heartbeat':
                conn_data = trading_engine.connection_manager.connection_data[websocket]
                conn_data['last_heartbeat'] = datetime.now()
                await trading_engine.connection_manager.send_personal_message(
                    {
                        'type': 'heartbeat_ack',
                        'timestamp': datetime.now().isoformat()
                    },
                    websocket
                )
    except WebSocketDisconnect:
        trading_engine.connection_manager.disconnect(websocket)
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        trading_engine.connection_manager.disconnect(websocket)

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=False,
        log_level="info"
    )