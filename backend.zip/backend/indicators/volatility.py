"""
Volatility indicators module for cryptocurrency price prediction.

This module implements various volatility indicators that help identify market volatility
and potential price range for financial instruments.
"""

import numpy as np
import pandas as pd


def average_true_range(high, low, close, window=14):
    """
    Calculate Average True Range (ATR).
    
    Parameters:
    -----------
    high : pd.Series or np.array
        High prices
    low : pd.Series or np.array
        Low prices
    close : pd.Series or np.array
        Close prices
    window : int, default=14
        Number of periods to consider for ATR calculation
        
    Returns:
    --------
    pd.Series
        ATR values
    """
    if isinstance(high, np.ndarray):
        high = pd.Series(high)
    if isinstance(low, np.ndarray):
        low = pd.Series(low)
    if isinstance(close, np.ndarray):
        close = pd.Series(close)
    
    # Calculate true range
    prev_close = close.shift(1)
    tr1 = high - low
    tr2 = abs(high - prev_close)
    tr3 = abs(low - prev_close)
    
    true_range = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    
    # Calculate ATR
    atr = true_range.rolling(window=window).mean()
    
    return atr


def bollinger_bands(data, window=20, num_std=2):
    """
    Calculate Bollinger Bands.
    
    Parameters:
    -----------
    data : pd.Series or np.array
        Price data for calculation (typically closing prices)
    window : int, default=20
        Number of periods to consider for moving average
    num_std : float, default=2
        Number of standard deviations for upper and lower bands
        
    Returns:
    --------
    dict
        'middle': Middle band (simple moving average)
        'upper': Upper band
        'lower': Lower band
        'width': Band width (volatility indicator)
    """
    if isinstance(data, np.ndarray):
        data = pd.Series(data)
    
    # Calculate middle band (SMA)
    middle_band = data.rolling(window=window).mean()
    
    # Calculate standard deviation
    std = data.rolling(window=window).std()
    
    # Calculate upper and lower bands
    upper_band = middle_band + (std * num_std)
    lower_band = middle_band - (std * num_std)
    
    # Calculate bandwidth
    bandwidth = (upper_band - lower_band) / middle_band
    
    return {
        'middle': middle_band,
        'upper': upper_band,
        'lower': lower_band,
        'width': bandwidth
    }


def keltner_channel(high, low, close, ema_window=20, atr_window=10, atr_multiplier=2):
    """
    Calculate Keltner Channel.
    
    Parameters:
    -----------
    high : pd.Series or np.array
        High prices
    low : pd.Series or np.array
        Low prices
    close : pd.Series or np.array
        Close prices
    ema_window : int, default=20
        Number of periods for EMA calculation
    atr_window : int, default=10
        Number of periods for ATR calculation
    atr_multiplier : float, default=2
        Multiplier for ATR to set channel width
        
    Returns:
    --------
    dict
        'middle': Middle line (EMA)
        'upper': Upper band
        'lower': Lower band
    """
    if isinstance(high, np.ndarray):
        high = pd.Series(high)
    if isinstance(low, np.ndarray):
        low = pd.Series(low)
    if isinstance(close, np.ndarray):
        close = pd.Series(close)
    
    # Calculate EMA for middle line
    middle_line = close.ewm(span=ema_window, adjust=False).mean()
    
    # Calculate ATR
    atr = average_true_range(high, low, close, window=atr_window)
    
    # Calculate upper and lower bands
    upper_band = middle_line + (atr_multiplier * atr)
    lower_band = middle_line - (atr_multiplier * atr)
    
    return {
        'middle': middle_line,
        'upper': upper_band,
        'lower': lower_band
    }


def donchian_channel(high, low, window=20):
    """
    Calculate Donchian Channel.
    
    Parameters:
    -----------
    high : pd.Series or np.array
        High prices
    low : pd.Series or np.array
        Low prices
    window : int, default=20
        Number of periods to consider
        
    Returns:
    --------
    dict
        'upper': Upper band (highest high)
        'middle': Middle band (average of upper and lower)
        'lower': Lower band (lowest low)
    """
    if isinstance(high, np.ndarray):
        high = pd.Series(high)
    if isinstance(low, np.ndarray):
        low = pd.Series(low)
    
    # Calculate upper and lower bands
    upper_band = high.rolling(window=window).max()
    lower_band = low.rolling(window=window).min()
    
    # Calculate middle band
    middle_band = (upper_band + lower_band) / 2
    
    return {
        'upper': upper_band,
        'middle': middle_band,
        'lower': lower_band
    }


def standard_deviation(data, window=20):
    """
    Calculate Rolling Standard Deviation.
    
    Parameters:
    -----------
    data : pd.Series or np.array
        Price data for calculation
    window : int, default=20
        Number of periods to consider
        
    Returns:
    --------
    pd.Series
        Standard deviation values
    """
    if isinstance(data, np.ndarray):
        data = pd.Series(data)
    
    return data.rolling(window=window).std()