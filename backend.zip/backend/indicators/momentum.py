"""
Momentum indicators module for cryptocurrency price prediction.

This module implements various momentum indicators that help identify the speed of price movements
and potential overbought/oversold conditions in financial markets.
"""

import numpy as np
import pandas as pd


def relative_strength_index(data, window=14):
    """
    Calculate Relative Strength Index (RSI).
    
    Parameters:
    -----------
    data : pd.Series or np.array
        Price data for calculation (typically closing prices)
    window : int, default=14
        Number of periods to consider for RSI calculation
        
    Returns:
    --------
    pd.Series
        RSI values ranging from 0 to 100
    """
    if isinstance(data, np.ndarray):
        data = pd.Series(data)
    
    # Calculate price changes
    delta = data.diff()
    
    # Separate gains and losses
    gains = delta.copy()
    losses = delta.copy()
    gains[gains < 0] = 0
    losses[losses > 0] = 0
    losses = abs(losses)
    
    # Calculate average gains and losses
    avg_gains = gains.rolling(window=window).mean()
    avg_losses = losses.rolling(window=window).mean()
    
    # Calculate RS and RSI
    rs = avg_gains / avg_losses
    rsi = 100 - (100 / (1 + rs))
    
    return rsi


def stochastic_oscillator(high, low, close, k_window=14, d_window=3):
    """
    Calculate Stochastic Oscillator.
    
    Parameters:
    -----------
    high : pd.Series or np.array
        High prices
    low : pd.Series or np.array
        Low prices
    close : pd.Series or np.array
        Close prices
    k_window : int, default=14
        Number of periods for %K calculation
    d_window : int, default=3
        Number of periods for %D calculation (moving average of %K)
        
    Returns:
    --------
    dict
        'k': %K values
        'd': %D values
    """
    if isinstance(high, np.ndarray):
        high = pd.Series(high)
    if isinstance(low, np.ndarray):
        low = pd.Series(low)
    if isinstance(close, np.ndarray):
        close = pd.Series(close)
    
    # Calculate %K
    lowest_low = low.rolling(window=k_window).min()
    highest_high = high.rolling(window=k_window).max()
    
    k = 100 * ((close - lowest_low) / (highest_high - lowest_low))
    
    # Calculate %D
    d = k.rolling(window=d_window).mean()
    
    return {
        'k': k,
        'd': d
    }


def commodity_channel_index(high, low, close, window=20):
    """
    Calculate Commodity Channel Index (CCI).
    
    Parameters:
    -----------
    high : pd.Series or np.array
        High prices
    low : pd.Series or np.array
        Low prices
    close : pd.Series or np.array
        Close prices
    window : int, default=20
        Number of periods to consider for CCI calculation
        
    Returns:
    --------
    pd.Series
        CCI values
    """
    if isinstance(high, np.ndarray):
        high = pd.Series(high)
    if isinstance(low, np.ndarray):
        low = pd.Series(low)
    if isinstance(close, np.ndarray):
        close = pd.Series(close)
    
    # Calculate typical price
    tp = (high + low + close) / 3
    
    # Calculate simple moving average of typical price
    tp_sma = tp.rolling(window=window).mean()
    
    # Calculate mean deviation
    mad = tp.rolling(window=window).apply(lambda x: np.mean(np.abs(x - np.mean(x))))
    
    # Calculate CCI
    cci = (tp - tp_sma) / (0.015 * mad)
    
    return cci


def williams_percent_r(high, low, close, window=14):
    """
    Calculate Williams %R.
    
    Parameters:
    -----------
    high : pd.Series or np.array
        High prices
    low : pd.Series or np.array
        Low prices
    close : pd.Series or np.array
        Close prices
    window : int, default=14
        Number of periods to consider for Williams %R calculation
        
    Returns:
    --------
    pd.Series
        Williams %R values ranging from -100 to 0
    """
    if isinstance(high, np.ndarray):
        high = pd.Series(high)
    if isinstance(low, np.ndarray):
        low = pd.Series(low)
    if isinstance(close, np.ndarray):
        close = pd.Series(close)
    
    # Calculate highest high and lowest low
    highest_high = high.rolling(window=window).max()
    lowest_low = low.rolling(window=window).min()
    
    # Calculate Williams %R
    wr = -100 * ((highest_high - close) / (highest_high - lowest_low))
    
    return wr


def rate_of_change(data, window=14):
    """
    Calculate Rate of Change (ROC).
    
    Parameters:
    -----------
    data : pd.Series or np.array
        Price data for calculation (typically closing prices)
    window : int, default=14
        Number of periods to consider for ROC calculation
        
    Returns:
    --------
    pd.Series
        Rate of Change values
    """
    if isinstance(data, np.ndarray):
        data = pd.Series(data)
    
    # Calculate ROC
    roc = ((data / data.shift(window)) - 1) * 100
    
    return roc


def awesome_oscillator(high, low, short_window=5, long_window=34):
    """
    Calculate Awesome Oscillator (AO).
    
    Parameters:
    -----------
    high : pd.Series or np.array
        High prices
    low : pd.Series or np.array
        Low prices
    short_window : int, default=5
        Short-term period
    long_window : int, default=34
        Long-term period
        
    Returns:
    --------
    pd.Series
        Awesome Oscillator values
    """
    if isinstance(high, np.ndarray):
        high = pd.Series(high)
    if isinstance(low, np.ndarray):
        low = pd.Series(low)
    
    # Calculate median price
    median_price = (high + low) / 2
    
    # Calculate simple moving averages
    short_sma = median_price.rolling(window=short_window).mean()
    long_sma = median_price.rolling(window=long_window).mean()
    
    # Calculate AO
    ao = short_sma - long_sma
    
    return ao