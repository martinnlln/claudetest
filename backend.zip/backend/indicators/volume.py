"""
Volume indicators module for cryptocurrency price prediction.

This module implements various volume indicators that help identify the strength
of price movements based on trading volume in financial markets.
"""

import numpy as np
import pandas as pd


def on_balance_volume(close, volume):
    """
    Calculate On-Balance Volume (OBV).
    
    Parameters:
    -----------
    close : pd.Series or np.array
        Close prices
    volume : pd.Series or np.array
        Volume data
        
    Returns:
    --------
    pd.Series
        OBV values
    """
    if isinstance(close, np.ndarray):
        close = pd.Series(close)
    if isinstance(volume, np.ndarray):
        volume = pd.Series(volume)
    
    # Ensure indices match
    close = close.reindex(volume.index)
    
    # Calculate price changes
    price_change = close.diff()
    
    # Initialize OBV series
    obv = pd.Series(0, index=close.index)
    
    # Calculate OBV
    for i in range(1, len(close)):
        if price_change[i] > 0:
            obv[i] = obv[i-1] + volume[i]
        elif price_change[i] < 0:
            obv[i] = obv[i-1] - volume[i]
        else:
            obv[i] = obv[i-1]
    
    return obv


def accumulation_distribution(high, low, close, volume):
    """
    Calculate Accumulation/Distribution Line.
    
    Parameters:
    -----------
    high : pd.Series or np.array
        High prices
    low : pd.Series or np.array
        Low prices
    close : pd.Series or np.array
        Close prices
    volume : pd.Series or np.array
        Volume data
        
    Returns:
    --------
    pd.Series
        Accumulation/Distribution values
    """
    if isinstance(high, np.ndarray):
        high = pd.Series(high)
    if isinstance(low, np.ndarray):
        low = pd.Series(low)
    if isinstance(close, np.ndarray):
        close = pd.Series(close)
    if isinstance(volume, np.ndarray):
        volume = pd.Series(volume)
    
    # Ensure indices match
    high = high.reindex(volume.index)
    low = low.reindex(volume.index)
    close = close.reindex(volume.index)
    
    # Calculate Money Flow Multiplier
    mfm = ((close - low) - (high - close)) / (high - low)
    mfm = mfm.replace([np.inf, -np.inf], 0)  # Handle division by zero
    
    # Calculate Money Flow Volume
    mfv = mfm * volume
    
    # Calculate Accumulation/Distribution Line
    ad = mfv.cumsum()
    
    return ad


def money_flow_index(high, low, close, volume, window=14):
    """
    Calculate Money Flow Index (MFI).
    
    Parameters:
    -----------
    high : pd.Series or np.array
        High prices
    low : pd.Series or np.array
        Low prices
    close : pd.Series or np.array
        Close prices
    volume : pd.Series or np.array
        Volume data
    window : int, default=14
        Number of periods to consider for MFI calculation
        
    Returns:
    --------
    pd.Series
        MFI values ranging from 0 to 100
    """
    if isinstance(high, np.ndarray):
        high = pd.Series(high)
    if isinstance(low, np.ndarray):
        low = pd.Series(low)
    if isinstance(close, np.ndarray):
        close = pd.Series(close)
    if isinstance(volume, np.ndarray):
        volume = pd.Series(volume)
    
    # Calculate typical price
    tp = (high + low + close) / 3
    
    # Calculate money flow
    money_flow = tp * volume
    
    # Get positive and negative money flow
    diff = tp.diff()
    positive_flow = pd.Series(np.where(diff > 0, money_flow, 0), index=money_flow.index)
    negative_flow = pd.Series(np.where(diff < 0, money_flow, 0), index=money_flow.index)
    
    # Calculate money ratio
    positive_sum = positive_flow.rolling(window=window).sum()
    negative_sum = negative_flow.rolling(window=window).sum()
    
    money_ratio = positive_sum / negative_sum
    
    # Calculate MFI
    mfi = 100 - (100 / (1 + money_ratio))
    
    return mfi


def volume_weighted_average_price(high, low, close, volume, window=14):
    """
    Calculate Volume Weighted Average Price (VWAP).
    
    Parameters:
    -----------
    high : pd.Series or np.array
        High prices
    low : pd.Series or np.array
        Low prices
    close : pd.Series or np.array
        Close prices
    volume : pd.Series or np.array
        Volume data
    window : int, default=14
        Number of periods to consider for VWAP calculation
        
    Returns:
    --------
    pd.Series
        VWAP values
    """
    if isinstance(high, np.ndarray):
        high = pd.Series(high)
    if isinstance(low, np.ndarray):
        low = pd.Series(low)
    if isinstance(close, np.ndarray):
        close = pd.Series(close)
    if isinstance(volume, np.ndarray):
        volume = pd.Series(volume)
    
    # Calculate typical price
    tp = (high + low + close) / 3
    
    # Calculate price * volume
    pv = tp * volume
    
    # Calculate VWAP
    vwap = pv.rolling(window=window).sum() / volume.rolling(window=window).sum()
    
    return vwap

def chaikin_money_flow(high, low, close, volume, window=20):
    """
    Calculate Chaikin Money Flow (CMF).
    
    Parameters:
    -----------
    high : pd.Series or np.array
        High prices
    low : pd.Series or np.array
        Low prices
    close : pd.Series or np.array
        Close prices
    volume : pd.Series or np.array
        Volume data
    window : int, default=20
        Number of periods to consider for CMF calculation
        
    Returns:
    --------
    pd.Series
        CMF values
    """
    if isinstance(high, np.ndarray):
        high = pd.Series(high)
    if isinstance(low, np.ndarray):
        low = pd.Series(low)
    if isinstance(close, np.ndarray):
        close = pd.Series(close)
    if isinstance(volume, np.ndarray):
        volume = pd.Series(volume)
    
    # Calculate Money Flow Multiplier
    mfm = ((close - low) - (high - close)) / (high - low)
    mfm = mfm.replace([np.inf, -np.inf], 0)  # Handle division by zero
    
    # Calculate Money Flow Volume
    mfv = mfm * volume
    
    # Calculate Chaikin Money Flow
    cmf = mfv.rolling(window=window).sum() / volume.rolling(window=window).sum()
    
    return cmf


def ease_of_movement(high, low, volume, window=14):
    """
    Calculate Ease of Movement (EOM).
    
    Parameters:
    -----------
    high : pd.Series or np.array
        High prices
    low : pd.Series or np.array
        Low prices
    volume : pd.Series or np.array
        Volume data
    window : int, default=14
        Number of periods to consider for EOM calculation
        
    Returns:
    --------
    pd.Series
        EOM values
    """
    if isinstance(high, np.ndarray):
        high = pd.Series(high)
    if isinstance(low, np.ndarray):
        low = pd.Series(low)
    if isinstance(volume, np.ndarray):
        volume = pd.Series(volume)
    
    # Calculate distance moved
    distance = ((high + low) / 2) - ((high.shift(1) + low.shift(1)) / 2)
    
    # Calculate box ratio
    box_ratio = (volume / 1000000) / (high - low)
    
    # Calculate single-period EOM
    eom = distance / box_ratio
    
    # Calculate EOM with specified period
    eom_ma = eom.rolling(window=window).mean()
    
    return eom_ma