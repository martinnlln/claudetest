"""
Sentiment indicators module for cryptocurrency price prediction.

This module implements various sentiment indicators that help identify market sentiment
based on external data sources and market characteristics.
"""

import numpy as np
import pandas as pd
import requests
from datetime import datetime, timedelta
import time
import json
import os
import logging

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def fear_and_greed_index(api_key=None, days=30):
    """
    Fetch Fear and Greed Index data for cryptocurrencies.
    
    Uses the Alternative.me API to fetch the crypto fear & greed index,
    which measures market sentiment from 0 (extreme fear) to 100 (extreme greed).
    
    Parameters:
    -----------
    api_key : str, optional
        API key for premium access (not required for basic access)
    days : int, default=30
        Number of days of historical data to fetch
        
    Returns:
    --------
    pd.DataFrame
        DataFrame with date and fear/greed index values
    """
    try:
        # API endpoint
        url = f"https://api.alternative.me/fng/?limit={days}"
        
        # Make request
        response = requests.get(url)
        response.raise_for_status()  # Raise exception for HTTP errors
        
        data = response.json()
        
        # Process data
        result = []
        for item in data['data']:
            date = datetime.fromtimestamp(int(item['timestamp']))
            value = int(item['value'])
            classification = item['value_classification']
            
            result.append({
                'date': date,
                'value': value,
                'classification': classification
            })
        
        # Convert to DataFrame
        df = pd.DataFrame(result)
        df.set_index('date', inplace=True)
        df.sort_index(inplace=True)  # Ensure chronological order
        
        return df
        
    except Exception as e:
        logger.error(f"Error fetching Fear and Greed Index: {e}")
        # Return empty DataFrame with expected columns
        return pd.DataFrame(columns=['value', 'classification'])


def twitter_sentiment(keyword, api_key=None, days=7):
    """
    Analyze Twitter sentiment for a cryptocurrency keyword.
    
    This is a placeholder function that would typically use a Twitter API
    or sentiment analysis service. Due to API access limitations, this function
    returns simulated data for demonstration purposes.
    
    Parameters:
    -----------
    keyword : str
        Cryptocurrency keyword to analyze (e.g., "bitcoin", "ethereum")
    api_key : str, optional
        API key for the sentiment analysis service
    days : int, default=7
        Number of days of historical data to simulate
        
    Returns:
    --------
    pd.DataFrame
        DataFrame with date, sentiment score, and tweet volume
    """
    # Simulate sentiment data
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=days)
    
    date_range = [start_date + timedelta(days=i) for i in range(days)]
    
    # Generate random sentiment scores between -1 (negative) and 1 (positive)
    np.random.seed(42)  # For reproducibility
    sentiment_scores = np.random.normal(0.2, 0.4, days)  # Slightly positive mean
    sentiment_scores = np.clip(sentiment_scores, -1, 1)  # Ensure range [-1, 1]
    
    # Generate random tweet volumes
    tweet_volumes = np.random.randint(500, 10000, days)
    
    # Create DataFrame
    df = pd.DataFrame({
        'date': date_range,
        'sentiment': sentiment_scores,
        'volume': tweet_volumes
    })
    
    df.set_index('date', inplace=True)
    
    # Add a note in the logs that this is simulated data
    logger.info("Note: Twitter sentiment analysis is using simulated data.")
    
    return df


def news_sentiment(keyword, api_key=None, days=7):
    """
    Analyze news sentiment for a cryptocurrency keyword.
    
    This is a placeholder function that would typically use a news API
    and sentiment analysis service. Due to API access limitations, this function
    returns simulated data for demonstration purposes.
    
    Parameters:
    -----------
    keyword : str
        Cryptocurrency keyword to analyze (e.g., "bitcoin", "ethereum")
    api_key : str, optional
        API key for the news/sentiment analysis service
    days : int, default=7
        Number of days of historical data to simulate
        
    Returns:
    --------
    pd.DataFrame
        DataFrame with date, sentiment score, and article count
    """
    # Simulate sentiment data
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=days)
    
    date_range = [start_date + timedelta(days=i) for i in range(days)]
    
    # Generate random sentiment scores between -1 (negative) and 1 (positive)
    np.random.seed(43)  # Different seed from Twitter sentiment
    sentiment_scores = np.random.normal(0.1, 0.5, days)  # Slightly positive mean
    sentiment_scores = np.clip(sentiment_scores, -1, 1)  # Ensure range [-1, 1]
    
    # Generate random article counts
    article_counts = np.random.randint(10, 100, days)
    
    # Create DataFrame
    df = pd.DataFrame({
        'date': date_range,
        'sentiment': sentiment_scores,
        'articles': article_counts
    })
    
    df.set_index('date', inplace=True)
    
    # Add a note in the logs that this is simulated data
    logger.info("Note: News sentiment analysis is using simulated data.")
    
    return df


def google_trends(keyword, days=90):
    """
    Fetch Google Trends data for a cryptocurrency keyword.
    
    This is a placeholder function that would typically use the Google Trends API
    or a service like PyTrends. Due to API access limitations, this function
    returns simulated data for demonstration purposes.
    
    Parameters:
    -----------
    keyword : str
        Cryptocurrency keyword to analyze (e.g., "bitcoin", "ethereum")
    days : int, default=90
        Number of days of historical data to simulate
        
    Returns:
    --------
    pd.DataFrame
        DataFrame with date and interest over time (0-100)
    """
    # Simulate Google Trends data
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=days)
    
    date_range = [start_date + timedelta(days=i) for i in range(days)]
    
    # Generate random interest values (0-100)
    np.random.seed(44)  # Different seed
    
    # Create a base trend with some seasonality and an upward trend
    x = np.linspace(0, 4*np.pi, days)
    base_trend = 50 + 20 * np.sin(x/7) + np.linspace(0, 15, days)
    
    # Add random noise
    noise = np.random.normal(0, 5, days)
    interest_values = base_trend + noise
    interest_values = np.clip(interest_values, 0, 100)  # Ensure range [0, 100]
    
    # Create DataFrame
    df = pd.DataFrame({
        'date': date_range,
        'interest': interest_values
    })
    
    df.set_index('date', inplace=True)
    
    # Add a note in the logs that this is simulated data
    logger.info("Note: Google Trends analysis is using simulated data.")
    
    return df


def funding_rate(symbol='BTCUSDT', exchange='binance', days=30):
    """
    Fetch funding rate data for a cryptocurrency perpetual futures contract.
    
    This is a placeholder function that would typically use an exchange API.
    Due to API access limitations, this function returns simulated data for
    demonstration purposes.
    
    Parameters:
    -----------
    symbol : str, default='BTCUSDT'
        Trading pair symbol
    exchange : str, default='binance'
        Exchange name
    days : int, default=30
        Number of days of historical data to simulate
        
    Returns:
    --------
    pd.DataFrame
        DataFrame with date and funding rate values
    """
    # Generate hourly timestamps for the specified number of days
    hours = 24 * days
    end_time = int(time.time())
    start_time = end_time - (3600 * hours)
    
    timestamps = [start_time + (i * 3600) for i in range(hours)]
    dates = [datetime.fromtimestamp(ts) for ts in timestamps]
    
    # Generate funding rates with mean around 0.01% (0.0001) with some volatility
    np.random.seed(45)
    base_rate = 0.0001  # 0.01% base rate
    
    # Create some patterns in the funding rate
    x = np.linspace(0, 8*np.pi, hours)
    pattern = base_rate * np.sin(x/24)  # Daily cycle
    
    # Add random noise
    noise = np.random.normal(0, 0.0002, hours)
    funding_rates = pattern + noise
    
    # Create DataFrame
    df = pd.DataFrame({
        'date': dates,
        'funding_rate': funding_rates
    })
    
    df.set_index('date', inplace=True)
    
    # Add a note in the logs that this is simulated data
    logger.info(f"Note: Funding rate data for {symbol} on {exchange} is using simulated data.")
    
    return df


def long_short_ratio(symbol='BTCUSDT', exchange='binance', days=30):
    """
    Fetch long/short ratio data for a cryptocurrency.
    
    This is a placeholder function that would typically use an exchange API.
    Due to API access limitations, this function returns simulated data for
    demonstration purposes.
    
    Parameters:
    -----------
    symbol : str, default='BTCUSDT'
        Trading pair symbol
    exchange : str, default='binance'
        Exchange name
    days : int, default=30
        Number of days of historical data to simulate
        
    Returns:
    --------
    pd.DataFrame
        DataFrame with date, long percentage, short percentage, and long/short ratio
    """
    # Generate daily timestamps for the specified number of days
    end_time = int(time.time())
    start_time = end_time - (86400 * days)
    
    timestamps = [start_time + (i * 86400) for i in range(days)]
    dates = [datetime.fromtimestamp(ts) for ts in timestamps]
    
    # Generate long percentages with mean around 55%
    np.random.seed(46)
    
    # Create some patterns in the ratio
    x = np.linspace(0, 4*np.pi, days)
    long_pct_base = 55 + 10 * np.sin(x/14)  # 2-week cycle
    
    # Add random noise
    noise = np.random.normal(0, 3, days)
    long_pct = long_pct_base + noise
    long_pct = np.clip(long_pct, 25, 75)  # Ensure reasonable range
    
    # Calculate short percentage
    short_pct = 100 - long_pct
    
    # Calculate long/short ratio
    ls_ratio = long_pct / short_pct
    
    # Create DataFrame
    df = pd.DataFrame({
        'date': dates,
        'long_percentage': long_pct,
        'short_percentage': short_pct,
        'long_short_ratio': ls_ratio
    })
    
    df.set_index('date', inplace=True)
    
    # Add a note in the logs that this is simulated data
    logger.info(f"Note: Long/short ratio data for {symbol} on {exchange} is using simulated data.")
    
    return df