"""
Trend indicators module for cryptocurrency price prediction.

This module implements various trend indicators that help identify the direction
of price movements in financial markets.
"""

import numpy as np
import pandas as pd


def simple_moving_average(data, window):
    """
    Calculate Simple Moving Average (SMA).
    
    Parameters:
    -----------
    data : pd.Series or np.array
        Price data for calculation
    window : int
        Number of periods to consider for moving average
        
    Returns:
    --------
    pd.Series
        Simple Moving Average values
    """
    if isinstance(data, np.ndarray):
        data = pd.Series(data)
    
    return data.rolling(window=window).mean()


def exponential_moving_average(data, window):
    """
    Calculate Exponential Moving Average (EMA).
    
    Parameters:
    -----------
    data : pd.Series or np.array
        Price data for calculation
    window : int
        Number of periods to consider for moving average
        
    Returns:
    --------
    pd.Series
        Exponential Moving Average values
    """
    if isinstance(data, np.ndarray):
        data = pd.Series(data)
    
    return data.ewm(span=window, adjust=False).mean()


def weighted_moving_average(data, window):
    """
    Calculate Weighted Moving Average (WMA).
    
    Parameters:
    -----------
    data : pd.Series or np.array
        Price data for calculation
    window : int
        Number of periods to consider for moving average
        
    Returns:
    --------
    pd.Series
        Weighted Moving Average values
    """
    if isinstance(data, np.ndarray):
        data = pd.Series(data)
    
    weights = np.arange(1, window + 1)
    return data.rolling(window).apply(lambda x: np.sum(weights * x) / weights.sum(), raw=True)


def moving_average_convergence_divergence(data, fast_window=12, slow_window=26, signal_window=9):
    """
    Calculate Moving Average Convergence Divergence (MACD).
    
    Parameters:
    -----------
    data : pd.Series or np.array
        Price data for calculation
    fast_window : int, default=12
        Fast EMA window
    slow_window : int, default=26
        Slow EMA window
    signal_window : int, default=9
        Signal line window
        
    Returns:
    --------
    dict
        'macd': MACD line
        'signal': Signal line
        'histogram': MACD histogram
    """
    if isinstance(data, np.ndarray):
        data = pd.Series(data)
    
    fast_ema = exponential_moving_average(data, fast_window)
    slow_ema = exponential_moving_average(data, slow_window)
    
    macd_line = fast_ema - slow_ema
    signal_line = exponential_moving_average(macd_line, signal_window)
    histogram = macd_line - signal_line
    
    return {
        'macd': macd_line,
        'signal': signal_line,
        'histogram': histogram
    }


def parabolic_sar(high, low, close, af_start=0.02, af_step=0.02, af_max=0.2):
    """
    Calculate Parabolic SAR indicator.
    
    Parameters:
    -----------
    high : pd.Series
        High prices
    low : pd.Series
        Low prices
    close : pd.Series
        Close prices
    af_start : float, default=0.02
        Starting acceleration factor
    af_step : float, default=0.02
        Acceleration factor step
    af_max : float, default=0.2
        Maximum acceleration factor
        
    Returns:
    --------
    pd.Series
        Parabolic SAR values
    """
    if isinstance(high, np.ndarray):
        high = pd.Series(high)
    if isinstance(low, np.ndarray):
        low = pd.Series(low)
    if isinstance(close, np.ndarray):
        close = pd.Series(close)
    
    # Initialize outputs
    sar = pd.Series(index=close.index)
    trend = pd.Series(index=close.index)
    ep = pd.Series(index=close.index)  # Extreme point
    af = pd.Series(index=close.index)  # Acceleration factor
    
    # Set initial values
    trend[0] = 1 if close[1] > close[0] else -1
    sar[0] = high[0] if trend[0] < 0 else low[0]
    ep[0] = high[0] if trend[0] > 0 else low[0]
    af[0] = af_start
    
    # Calculate SAR values
    for i in range(1, len(close)):
        # Previous values
        prev_sar = sar[i-1]
        prev_af = af[i-1]
        prev_ep = ep[i-1]
        prev_trend = trend[i-1]
        
        # Current SAR
        if prev_trend > 0:
            sar[i] = prev_sar + prev_af * (prev_ep - prev_sar)
            # Ensure SAR is not higher than the previous two lows
            if i >= 2:
                sar[i] = min(sar[i], low[i-1], low[i-2])
                
            # Check for trend reversal
            if sar[i] > low[i]:
                trend[i] = -1
                sar[i] = max(high[i-1], high[i])
                ep[i] = low[i]
                af[i] = af_start
            else:
                trend[i] = 1
                # Update EP and AF
                if high[i] > prev_ep:
                    ep[i] = high[i]
                    af[i] = min(prev_af + af_step, af_max)
                else:
                    ep[i] = prev_ep
                    af[i] = prev_af
        else:  # Downtrend
            sar[i] = prev_sar - prev_af * (prev_sar - prev_ep)
            # Ensure SAR is not lower than the previous two highs
            if i >= 2:
                sar[i] = max(sar[i], high[i-1], high[i-2])
                
            # Check for trend reversal
            if sar[i] < high[i]:
                trend[i] = 1
                sar[i] = min(low[i-1], low[i])
                ep[i] = high[i]
                af[i] = af_start
            else:
                trend[i] = -1
                # Update EP and AF
                if low[i] < prev_ep:
                    ep[i] = low[i]
                    af[i] = min(prev_af + af_step, af_max)
                else:
                    ep[i] = prev_ep
                    af[i] = prev_af
    
    return sar


def supertrend(high, low, close, period=10, multiplier=3):
    """
    Calculate SuperTrend indicator.
    
    Parameters:
    -----------
    high : pd.Series
        High prices
    low : pd.Series
        Low prices
    close : pd.Series
        Close prices
    period : int, default=10
        ATR period
    multiplier : float, default=3
        ATR multiplier
        
    Returns:
    --------
    dict
        'supertrend': SuperTrend values
        'trend': Trend direction (1 for bullish, -1 for bearish)
    """
    from .volatility import average_true_range
    
    if isinstance(high, np.ndarray):
        high = pd.Series(high)
    if isinstance(low, np.ndarray):
        low = pd.Series(low)
    if isinstance(close, np.ndarray):
        close = pd.Series(close)
    
    # Calculate ATR
    atr = average_true_range(high, low, close, period)
    
    # Calculate basic upper and lower bands
    hl2 = (high + low) / 2
    basic_upper_band = hl2 + (multiplier * atr)
    basic_lower_band = hl2 - (multiplier * atr)
    
    # Initialize final bands and trend
    final_upper_band = pd.Series(index=close.index)
    final_lower_band = pd.Series(index=close.index)
    supertrend = pd.Series(index=close.index)
    trend = pd.Series(index=close.index)
    
    # Set initial values
    final_upper_band[0] = basic_upper_band[0]
    final_lower_band[0] = basic_lower_band[0]
    supertrend[0] = (final_upper_band[0] + final_lower_band[0]) / 2
    trend[0] = 1 if close[0] > supertrend[0] else -1
    
    # Calculate SuperTrend
    for i in range(1, len(close)):
        # Calculate final upper band
        if (basic_upper_band[i] < final_upper_band[i-1]) or (close[i-1] > final_upper_band[i-1]):
            final_upper_band[i] = basic_upper_band[i]
        else:
            final_upper_band[i] = final_upper_band[i-1]
            
        # Calculate final lower band
        if (basic_lower_band[i] > final_lower_band[i-1]) or (close[i-1] < final_lower_band[i-1]):
            final_lower_band[i] = basic_lower_band[i]
        else:
            final_lower_band[i] = final_lower_band[i-1]
            
        # Determine trend and supertrend value
        if trend[i-1] == 1:
            if close[i] <= final_lower_band[i]:
                supertrend[i] = final_upper_band[i]
                trend[i] = -1
            else:
                supertrend[i] = final_lower_band[i]
                trend[i] = 1
        else:  # Previous trend was down
            if close[i] >= final_upper_band[i]:
                supertrend[i] = final_lower_band[i]
                trend[i] = 1
            else:
                supertrend[i] = final_upper_band[i]
                trend[i] = -1
    
    return {
        'supertrend': supertrend,
        'trend': trend
    }