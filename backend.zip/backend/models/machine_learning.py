# backend/models/machine_learning.py
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression, Lasso, Ridge
from sklearn.svm import SVR
from xgboost import XGBRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.model_selection import TimeSeriesSplit, GridSearchCV


class MLModels:
    """Class containing machine learning models for price prediction."""
    
    @staticmethod
    def create_model(model_type='random_forest', **kwargs):
        """
        Create a machine learning model.
        
        Args:
            model_type (str): Type of model to create
            **kwargs: Additional parameters for the model
            
        Returns:
            model: Created model instance
        """
        models = {
            'random_forest': RandomForestRegressor,
            'gradient_boosting': GradientBoostingRegressor,
            'linear': LinearRegression,
            'lasso': Lasso,
            'ridge': Ridge,
            'svr': SVR,
            'xgboost': XGBRegressor
        }
        
        if model_type not in models:
            raise ValueError(f"Model type '{model_type}' not supported")
        
        return models[model_type](**kwargs)
    
    @staticmethod
    def train_model(model, X_train, y_train):
        """
        Train a machine learning model.
        
        Args:
            model: Model instance
            X_train (pd.DataFrame/np.array): Training features
            y_train (pd.Series/np.array): Training targets
            
        Returns:
            model: Trained model
        """
        try:
            model.fit(X_train, y_train)
            return model
        except Exception as e:
            print(f"Error training model: {e}")
            return None
    
    @staticmethod
    def predict(model, X):
        """
        Make predictions using a trained model.
        
        Args:
            model: Trained model
            X (pd.DataFrame/np.array): Features to predict on
            
        Returns:
            np.array: Predicted values
        """
        if model is None:
            return None
        
        return model.predict(X)
    
    @staticmethod
    def create_pipeline(model_type='random_forest', scale=True, **kwargs):
        """
        Create a pipeline with preprocessing and model.
        
        Args:
            model_type (str): Type of model
            scale (bool): Whether to include scaling
            **kwargs: Additional parameters for the model
            
        Returns:
            Pipeline: Scikit-learn pipeline
        """
        steps = []
        
        if scale:
            steps.append(('scaler', StandardScaler()))
            
        steps.append(('model', MLModels.create_model(model_type, **kwargs)))
        
        return Pipeline(steps)
    
    @staticmethod
    def optimize_hyperparameters(X, y, model_type='random_forest', param_grid=None, cv=5):
        """
        Optimize hyperparameters for a model using time series cross-validation.
        
        Args:
            X (pd.DataFrame): Features
            y (pd.Series): Target
            model_type (str): Type of model
            param_grid (dict): Parameters to search
            cv (int): Number of cross-validation folds
            
        Returns:
            GridSearchCV: Fitted grid search object with optimal parameters
        """
        if param_grid is None:
            # Default parameter grids based on model type
            param_grids = {
                'random_forest': {
                    'model__n_estimators': [50, 100, 200],
                    'model__max_depth': [None, 10, 20, 30]
                },
                'xgboost': {
                    'model__n_estimators': [50, 100, 200],
                    'model__learning_rate': [0.01, 0.1, 0.2],
                    'model__max_depth': [3, 5, 7]
                },
                'linear': {},  # Linear regression has no hyperparameters to tune
                'ridge': {
                    'model__alpha': [0.1, 1.0, 10.0]
                }
            }
            param_grid = param_grids.get(model_type, {})
        
        # Create time series cross-validation splitter
        tscv = TimeSeriesSplit(n_splits=cv)
        
        # Create pipeline with scaling
        pipeline = MLModels.create_pipeline(model_type=model_type)
        
        # Create and fit grid search
        grid_search = GridSearchCV(pipeline, param_grid, cv=tscv, scoring='neg_mean_squared_error')
        grid_search.fit(X, y)
        
        return grid_search