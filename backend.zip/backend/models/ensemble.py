# backend/models/ensemble.py
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import VotingRegressor, StackingRegressor
from sklearn.model_selection import TimeSeriesSplit


class EnsembleModels:
    """Class containing ensemble methods for combining multiple models."""
    
    @staticmethod
    def simple_average(predictions):
        """
        Average predictions from multiple models.
        
        Args:
            predictions (list): List of prediction arrays
            
        Returns:
            np.array: Averaged predictions
        """
        return np.mean(predictions, axis=0)
    
    @staticmethod
    def weighted_average(predictions, weights):
        """
        Compute weighted average of predictions.
        
        Args:
            predictions (list): List of prediction arrays
            weights (list): List of weights for each model
            
        Returns:
            np.array: Weighted average predictions
        """
        if len(predictions) != len(weights):
            raise ValueError("Number of prediction arrays must match number of weights")
            
        weighted_sum = np.zeros_like(predictions[0])
        for pred, weight in zip(predictions, weights):
            weighted_sum += pred * weight
            
        return weighted_sum / np.sum(weights)
    
    @staticmethod
    def create_voting_ensemble(models, weights=None):
        """
        Create a voting ensemble of models.
        
        Args:
            models (list): List of (name, model) tuples
            weights (list): Optional weights for models
            
        Returns:
            VotingRegressor: Voting ensemble model
        """
        return VotingRegressor(estimators=models, weights=weights)
    
    @staticmethod
    def create_stacking_ensemble(models, meta_model=None):
        """
        Create a stacking ensemble of models.
        
        Args:
            models (list): List of (name, model) tuples
            meta_model: Model to use as meta-learner (default: LinearRegression)
            
        Returns:
            StackingRegressor: Stacking ensemble model
        """
        if meta_model is None:
            meta_model = LinearRegression()
            
        # Use time series cross-validation
        cv = TimeSeriesSplit(n_splits=5)
        
        return StackingRegressor(estimators=models, final_estimator=meta_model, cv=cv)
    
    @staticmethod
    def evaluate_ensemble_members(models, X_test, y_test, metric_func):
        """
        Evaluate individual models in the ensemble.
        
        Args:
            models (list): List of trained models
            X_test (pd.DataFrame/np.array): Test features
            y_test (pd.Series/np.array): Test targets
            metric_func (callable): Function to compute error metric
            
        Returns:
            dict: Dictionary with model names and their error metrics
        """
        results = {}
        
        for name, model in models:
            predictions = model.predict(X_test)
            error = metric_func(y_test, predictions)
            results[name] = error
            
        return results
    
    @staticmethod
    def optimize_weights(models, X_val, y_val, method='grid_search', grid_size=10):
        """
        Optimize ensemble weights using validation data.
        
        Args:
            models (list): List of trained models
            X_val (pd.DataFrame/np.array): Validation features
            y_val (pd.Series/np.array): Validation targets
            method (str): Method for weight optimization
            grid_size (int): Size of grid for grid search
            
        Returns:
            list: Optimized weights
        """
        if method == 'grid_search' and len(models) == 2:
            # For two models, we can do a simple grid search
            predictions = [model.predict(X_val) for _, model in models]
            
            best_score = float('inf')
            best_weight = 0
            
            # Try different weights
            for i in range(grid_size + 1):
                weight = i / grid_size
                weighted_pred = weight * predictions[0] + (1 - weight) * predictions[1]
                mse = np.mean((y_val - weighted_pred) ** 2)
                
                if mse < best_score:
                    best_score = mse
                    best_weight = weight
                    
            return [best_weight, 1 - best_weight]
        
        # For more than two models, use inverse error weighting
        errors = []
        for _, model in models:
            pred = model.predict(X_val)
            mse = np.mean((y_val - pred) ** 2)
            errors.append(mse)
            
        # Inverse error weighting
        weights = 1 / np.array(errors)
        weights = weights / np.sum(weights)  # Normalize to sum to 1
        
        return weights.tolist()
    
    @staticmethod
    def combine_predictions(predictions, method='average', weights=None):
        """
        Combine predictions using various methods.
        
        Args:
            predictions (list): List of prediction arrays
            method (str): Method for combining ('average', 'weighted_average', etc.)
            weights (list): Weights for weighted averaging
            
        Returns:
            np.array: Combined predictions
        """
        if method == 'average':
            return EnsembleModels.simple_average(predictions)
        elif method == 'weighted_average':
            if weights is None:
                raise ValueError("Weights must be provided for weighted averaging")
            return EnsembleModels.weighted_average(predictions, weights)
        else:
            raise ValueError(f"Combining method '{method}' not supported")