# backend/models/deep_learning.py
import numpy as np
import pandas as pd
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout, GRU, Bidirectional
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.optimizers import Adam
from sklearn.preprocessing import MinMaxScaler


class DeepLearningModels:
    """Class containing deep learning models for price prediction."""
    
    @staticmethod
    def create_lstm_model(input_shape, units=50, dropout=0.2, layers=1, output_dim=1):
        """
        Create an LSTM model.
        
        Args:
            input_shape (tuple): Shape of input data (timesteps, features)
            units (int): Number of LSTM units
            dropout (float): Dropout rate
            layers (int): Number of LSTM layers
            output_dim (int): Dimension of output
            
        Returns:
            model: LSTM model
        """
        model = Sequential()
        
        # First LSTM layer
        if layers == 1:
            model.add(LSTM(units=units, input_shape=input_shape))
        else:
            model.add(LSTM(units=units, input_shape=input_shape, return_sequences=True))
        model.add(Dropout(dropout))
        
        # Additional LSTM layers
        for i in range(layers - 1):
            return_sequences = i < layers - 2  # Only last layer has return_sequences=False
            model.add(LSTM(units=units, return_sequences=return_sequences))
            model.add(Dropout(dropout))
        
        # Output layer
        model.add(Dense(units=output_dim))
        
        # Compile model
        model.compile(optimizer=Adam(), loss='mean_squared_error')
        
        return model
    
    @staticmethod
    def create_gru_model(input_shape, units=50, dropout=0.2, layers=1, output_dim=1):
        """
        Create a GRU model.
        
        Args:
            input_shape (tuple): Shape of input data (timesteps, features)
            units (int): Number of GRU units
            dropout (float): Dropout rate
            layers (int): Number of GRU layers
            output_dim (int): Dimension of output
            
        Returns:
            model: GRU model
        """
        model = Sequential()
        
        # First GRU layer
        if layers == 1:
            model.add(GRU(units=units, input_shape=input_shape))
        else:
            model.add(GRU(units=units, input_shape=input_shape, return_sequences=True))
        model.add(Dropout(dropout))
        
        # Additional GRU layers
        for i in range(layers - 1):
            return_sequences = i < layers - 2  # Only last layer has return_sequences=False
            model.add(GRU(units=units, return_sequences=return_sequences))
            model.add(Dropout(dropout))
        
        # Output layer
        model.add(Dense(units=output_dim))
        
        # Compile model
        model.compile(optimizer=Adam(), loss='mean_squared_error')
        
        return model
    
    @staticmethod
    def create_bidirectional_lstm(input_shape, units=50, dropout=0.2, layers=1, output_dim=1):
        """
        Create a Bidirectional LSTM model.
        
        Args:
            input_shape (tuple): Shape of input data (timesteps, features)
            units (int): Number of LSTM units
            dropout (float): Dropout rate
            layers (int): Number of LSTM layers
            output_dim (int): Dimension of output
            
        Returns:
            model: Bidirectional LSTM model
        """
        model = Sequential()
        
        # First Bidirectional LSTM layer
        if layers == 1:
            model.add(Bidirectional(LSTM(units=units), input_shape=input_shape))
        else:
            model.add(Bidirectional(LSTM(units=units, return_sequences=True), input_shape=input_shape))
        model.add(Dropout(dropout))
        
        # Additional Bidirectional LSTM layers
        for i in range(layers - 1):
            return_sequences = i < layers - 2  # Only last layer has return_sequences=False
            model.add(Bidirectional(LSTM(units=units, return_sequences=return_sequences)))
            model.add(Dropout(dropout))
        
        # Output layer
        model.add(Dense(units=output_dim))
        
        # Compile model
        model.compile(optimizer=Adam(), loss='mean_squared_error')
        
        return model
    
    @staticmethod
    def prepare_sequence_data(data, lookback=60):
        """
        Prepare sequence data for training RNN models.
        
        Args:
            data (np.array): Input time series data
            lookback (int): Number of timesteps to look back
            
        Returns:
            tuple: (X, y) prepared sequence data
        """
        X, y = [], []
        for i in range(len(data) - lookback):
            X.append(data[i:i+lookback])
            y.append(data[i+lookback])
        return np.array(X), np.array(y)
    
    @staticmethod
    def train_model(model, X_train, y_train, epochs=50, batch_size=32, validation_split=0.2):
        """
        Train a deep learning model.
        
        Args:
            model: Keras model
            X_train (np.array): Training features
            y_train (np.array): Training targets
            epochs (int): Number of training epochs
            batch_size (int): Batch size
            validation_split (float): Validation split ratio
            
        Returns:
            model: Trained model
            history: Training history
        """
        try:
            # Early stopping callback
            early_stopping = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
            
            # Train model
            history = model.fit(
                X_train, y_train,
                epochs=epochs,
                batch_size=batch_size,
                validation_split=validation_split,
                callbacks=[early_stopping],
                verbose=1
            )
            
            return model, history
        except Exception as e:
            print(f"Error training deep learning model: {e}")
            return None, None
    
    @staticmethod
    def predict(model, X):
        """
        Make predictions using a trained deep learning model.
        
        Args:
            model: Trained model
            X (np.array): Features to predict on
            
        Returns:
            np.array: Predicted values
        """
        if model is None:
            return None
        
        return model.predict(X)