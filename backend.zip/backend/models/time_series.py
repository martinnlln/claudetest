# backend/models/time_series.py
import pandas as pd
import numpy as np
from statsmodels.tsa.arima.model import ARIMA
from prophet import Prophet
from statsmodels.tsa.statespace.sarimax import SARIMAX


class TimeSeriesModels:
    """Class containing time series forecasting models for price prediction."""
    
    @staticmethod
    def train_arima(data, p=1, d=1, q=0):
        """
        Train an ARIMA model.
        
        Args:
            data (pd.Series): Time series data to train on
            p (int): AR order
            d (int): Differencing order
            q (int): MA order
            
        Returns:
            model: Trained ARIMA model
        """
        try:
            model = ARIMA(data, order=(p, d, q))
            model_fit = model.fit()
            return model_fit
        except Exception as e:
            print(f"Error training ARIMA model: {e}")
            return None
    
    @staticmethod
    def predict_arima(model, steps=5):
        """
        Make predictions using a trained ARIMA model.
        
        Args:
            model: Trained ARIMA model
            steps (int): Number of steps to forecast
            
        Returns:
            np.array: Predicted values
        """
        if model is None:
            return None
        
        forecast = model.forecast(steps=steps)
        return forecast
    
    @staticmethod
    def train_prophet(data, changepoint_prior_scale=0.05, seasonality_mode='multiplicative'):
        """
        Train a Prophet model.
        
        Args:
            data (pd.DataFrame): DataFrame with 'ds' (datetime) and 'y' (target) columns
            changepoint_prior_scale (float): Flexibility in detecting changepoints
            seasonality_mode (str): 'additive' or 'multiplicative'
            
        Returns:
            model: Trained Prophet model
        """
        try:
            # Prophet requires specific column names: 'ds' for dates and 'y' for values
            if not {'ds', 'y'}.issubset(data.columns):
                if len(data.columns) == 2:
                    # Rename columns if there are exactly two columns
                    data = data.copy()
                    data.columns = ['ds', 'y']
                else:
                    raise ValueError("Data must have 'ds' and 'y' columns or exactly two columns")
            
            model = Prophet(changepoint_prior_scale=changepoint_prior_scale,
                          seasonality_mode=seasonality_mode)
            model.fit(data)
            return model
        except Exception as e:
            print(f"Error training Prophet model: {e}")
            return None
    
    @staticmethod
    def predict_prophet(model, periods=5, freq='D'):
        """
        Make predictions using a trained Prophet model.
        
        Args:
            model: Trained Prophet model
            periods (int): Number of periods to forecast
            freq (str): Frequency of predictions ('D' for daily, etc.)
            
        Returns:
            pd.DataFrame: Forecast including predicted values and intervals
        """
        if model is None:
            return None
        
        future = model.make_future_dataframe(periods=periods, freq=freq)
        forecast = model.predict(future)
        return forecast
    
    @staticmethod
    def train_sarima(data, order=(1, 1, 1), seasonal_order=(1, 1, 1, 12)):
        """
        Train a SARIMA model.
        
        Args:
            data (pd.Series): Time series data to train on
            order (tuple): (p, d, q) order
            seasonal_order (tuple): (P, D, Q, S) seasonal order
            
        Returns:
            model: Trained SARIMA model
        """
        try:
            model = SARIMAX(data, order=order, seasonal_order=seasonal_order)
            model_fit = model.fit(disp=False)
            return model_fit
        except Exception as e:
            print(f"Error training SARIMA model: {e}")
            return None
    
    @staticmethod
    def predict_sarima(model, steps=5):
        """
        Make predictions using a trained SARIMA model.
        
        Args:
            model: Trained SARIMA model
            steps (int): Number of steps to forecast
            
        Returns:
            np.array: Predicted values
        """
        if model is None:
            return None
        
        forecast = model.forecast(steps=steps)
        return forecast