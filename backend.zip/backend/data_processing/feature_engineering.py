import pandas as pd
import numpy as np
from typing import List, Optional, Union, Dict, Any
import logging
import talib
from sklearn.decomposition import PCA
from scipy import stats
import joblib
import os

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('feature_engineering')

class FeatureEngineer:
    """
    Create and transform features for price prediction models.
    """
    
    def __init__(self, model_dir: str = './feature_models'):
        """
        Initialize the FeatureEngineer.
        
        Args:
            model_dir: Directory to store feature transformation models
        """
        self.model_dir = model_dir
        os.makedirs(model_dir, exist_ok=True)
        self.transformers = {}
        logger.info("Initialized FeatureEngineer")
    
    def add_price_features(self, 
                         df: pd.DataFrame,
                         ohlc_columns: Dict[str, str] = None) -> pd.DataFrame:
        """
        Add basic price-derived features.
        
        Args:
            df: Input dataframe with price data
            ohlc_columns: Dictionary mapping standard names to actual column names
                         {'open': 'Open', 'high': 'High', 'low': 'Low', 'close': 'Close', 'volume': 'Volume'}
                         
        Returns:
            DataFrame with additional price features
        """
        df_copy = df.copy()
        
        # Default column mapping
        if ohlc_columns is None:
            ohlc_columns = {
                'open': 'Open', 
                'high': 'High', 
                'low': 'Low', 
                'close': 'Close', 
                'volume': 'Volume'
            }
        
        # Get actual column names
        close_col = ohlc_columns.get('close', 'Close')
        open_col = ohlc_columns.get('open', 'Open')
        high_col = ohlc_columns.get('high', 'High')
        low_col = ohlc_columns.get('low', 'Low')
        volume_col = ohlc_columns.get('volume', 'Volume')
        
        # Ensure required columns exist
        required_cols = [close_col]
        missing_cols = [col for col in required_cols if col not in df_copy.columns]
        if missing_cols:
            logger.warning(f"Missing required columns: {missing_cols}")
            return df_copy
        
        logger.info("Adding price-derived features")
        
        # Returns
        df_copy['return_1d'] = df_copy[close_col].pct_change()
        df_copy['return_5d'] = df_copy[close_col].pct_change(5)
        df_copy['return_10d'] = df_copy[close_col].pct_change(10)
        df_copy['return_20d'] = df_copy[close_col].pct_change(20)
        
        # Log returns
        df_copy['log_return_1d'] = np.log(df_copy[close_col] / df_copy[close_col].shift(1))
        
        # Moving averages
        df_copy['ma_5'] = df_copy[close_col].rolling(window=5).mean()
        df_copy['ma_10'] = df_copy[close_col].rolling(window=10).mean()
        df_copy['ma_20'] = df_copy[close_col].rolling(window=20).mean()
        df_copy['ma_50'] = df_copy[close_col].rolling(window=50).mean()
        df_copy['ma_200'] = df_copy[close_col].rolling(window=200).mean()
        
        # Relative price levels
        df_copy['price_ma5_ratio'] = df_copy[close_col] / df_copy['ma_5']
        df_copy['price_ma20_ratio'] = df_copy[close_col] / df_copy['ma_20']
        df_copy['price_ma50_ratio'] = df_copy[close_col] / df_copy['ma_50']
        
        # Price channels
        if high_col in df_copy.columns and low_col in df_copy.columns:
            df_copy['high_low_diff'] = df_copy[high_col] - df_copy[low_col]
            df_copy['high_close_ratio'] = df_copy[high_col] / df_copy[close_col]
            df_copy['low_close_ratio'] = df_copy[low_col] / df_copy[close_col]
            
            # Price channel metrics
            df_copy['high_20d'] = df_copy[high_col].rolling(window=20).max()
            df_copy['low_20d'] = df_copy[low_col].rolling(window=20).min()
            df_copy['price_channel_pos'] = (df_copy[close_col] - df_copy['low_20d']) / (df_copy['high_20d'] - df_copy['low_20d'])
        
        # Open-Close features
        if open_col in df_copy.columns:
            df_copy['open_close_diff'] = df_copy[close_col] - df_copy[open_col]
            df_copy['open_close_ratio'] = df_copy[close_col] / df_copy[open_col]
            
        # Volatility features
        df_copy['volatility_5d'] = df_copy['return_1d'].rolling(window=5).std()
        df_copy['volatility_10d'] = df_copy['return_1d'].rolling(window=10).std()
        df_copy['volatility_20d'] = df_copy['return_1d'].rolling(window=20).std()
        
        # Volume-based features if volume column exists
        if volume_col in df_copy.columns:
            df_copy['volume_ma5'] = df_copy[volume_col].rolling(window=5).mean()
            df_copy['volume_ma20'] = df_copy[volume_col].rolling(window=20).mean()
            df_copy['volume_ratio'] = df_copy[volume_col] / df_copy['volume_ma20']
            
            # Money flow
            if high_col in df_copy.columns and low_col in df_copy.columns:
                typical_price = (df_copy[high_col] + df_copy[low_col] + df_copy[close_col]) / 3
                df_copy['money_flow'] = typical_price * df_copy[volume_col]
                
                # Accumulation/Distribution
                high_low_range = df_copy[high_col] - df_copy[low_col]
                close_loc = ((df_copy[close_col] - df_copy[low_col]) - (df_copy[high_col] - df_copy[close_col])) / high_low_range
                close_loc = close_loc.replace([np.inf, -np.inf], 0)
                df_copy['mf_multiplier'] = close_loc
                df_copy['money_flow_volume'] = df_copy['mf_multiplier'] * df_copy[volume_col]
        
        return df_copy
    
    def add_technical_indicators(self, 
                              df: pd.DataFrame,
                              ohlc_columns: Dict[str, str] = None) -> pd.DataFrame:
        """
        Add technical indicators using TA-Lib.
        
        Args:
            df: Input dataframe with price data
            ohlc_columns: Dictionary mapping standard names to actual column names
            
        Returns:
            DataFrame with technical indicators
        """
        df_copy = df.copy()
        
        # Default column mapping
        if ohlc_columns is None:
            ohlc_columns = {
                'open': 'Open', 
                'high': 'High', 
                'low': 'Low', 
                'close': 'Close', 
                'volume': 'Volume'
            }
            
        # Get actual column names
        close_col = ohlc_columns.get('close', 'Close')
        open_col = ohlc_columns.get('open', 'Open')
        high_col = ohlc_columns.get('high', 'High')
        low_col = ohlc_columns.get('low', 'Low')
        volume_col = ohlc_columns.get('volume', 'Volume')
        
        # Check for required columns
        required_cols = [close_col]
        all_required = True
        momentum_indicators = True
        volume_indicators = True
        
        # Check if we have OHLCV data
        for col in [high_col, low_col]:
            if col not in df_copy.columns:
                all_required = False
        
        if volume_col not in df_copy.columns:
            volume_indicators = False
        
        if not all_required:
            logger.warning("Some columns missing for comprehensive technical indicators")
        
        logger.info("Adding technical indicators")
        
        try:
            # Trend indicators
            df_copy['sma_5'] = talib.SMA(df_copy[close_col], timeperiod=5)
            df_copy['sma_10'] = talib.SMA(df_copy[close_col], timeperiod=10)
            df_copy['sma_20'] = talib.SMA(df_copy[close_col], timeperiod=20)
            df_copy['sma_50'] = talib.SMA(df_copy[close_col], timeperiod=50)
            df_copy['sma_200'] = talib.SMA(df_copy[close_col], timeperiod=200)
            
            df_copy['ema_5'] = talib.EMA(df_copy[close_col], timeperiod=5)
            df_copy['ema_10'] = talib.EMA(df_copy[close_col], timeperiod=10)
            df_copy['ema_20'] = talib.EMA(df_copy[close_col], timeperiod=20)
            df_copy['ema_50'] = talib.EMA(df_copy[close_col], timeperiod=50)
            df_copy['ema_200'] = talib.EMA(df_copy[close_col], timeperiod=200)
            
            # MACD
            df_copy['macd'], df_copy['macd_signal'], df_copy['macd_hist'] = talib.MACD(
                df_copy[close_col],
                fastperiod=12,
                slowperiod=26,
                signalperiod=9
            )
            
            if all_required:
                # Add indicators that require OHLC data
                
                # Parabolic SAR
                df_copy['sar'] = talib.SAR(
                    df_copy[high_col],
                    df_copy[low_col],
                    acceleration=0.02,
                    maximum=0.2
                )
                
                # Bollinger Bands
                df_copy['bb_upper'], df_copy['bb_middle'], df_copy['bb_lower'] = talib.BBANDS(
                    df_copy[close_col],
                    timeperiod=20,
                    nbdevup=2,
                    nbdevdn=2
                )
                
                # Position relative to Bollinger Bands
                df_copy['bb_width'] = (df_copy['bb_upper'] - df_copy['bb_lower']) / df_copy['bb_middle']
                df_copy['bb_position'] = (df_copy[close_col] - df_copy['bb_lower']) / (df_copy['bb_upper'] - df_copy['bb_lower'])
                
                # ADX - Trend strength
                df_copy['adx'] = talib.ADX(
                    df_copy[high_col],
                    df_copy[low_col],
                    df_copy[close_col],
                    timeperiod=14
                )
                
                # Ichimoku Cloud
                df_copy['tenkan_sen'] = talib.SMA(
                    (df_copy[high_col].rolling(window=9).max() + df_copy[low_col].rolling(window=9).min()) / 2,
                    timeperiod=9
                )
                
                df_copy['kijun_sen'] = talib.SMA(
                    (df_copy[high_col].rolling(window=26).max() + df_copy[low_col].rolling(window=26).min()) / 2,
                    timeperiod=26
                )
                
            if momentum_indicators:
                # RSI
                df_copy['rsi_14'] = talib.RSI(df_copy[close_col], timeperiod=14)
                
                # Stochastic Oscillator
                if all_required:
                    df_copy['slowk'], df_copy['slowd'] = talib.STOCH(
                        df_copy[high_col],
                        df_copy[low_col],
                        df_copy[close_col],
                        fastk_period=5,
                        slowk_period=3,
                        slowk_matype=0,
                        slowd_period=3,
                        slowd_matype=0
                    )
                
                # CCI - Commodity Channel Index
                if all_required:
                    df_copy['cci'] = talib.CCI(
                        df_copy[high_col],
                        df_copy[low_col],
                        df_copy[close_col],
                        timeperiod=14
                    )
                
                # Rate of Change
                df_copy['roc'] = talib.ROC(df_copy[close_col], timeperiod=10)
                
            if volume_indicators and volume_col in df_copy.columns:
                # OBV - On Balance Volume
                df_copy['obv'] = talib.OBV(df_copy[close_col], df_copy[volume_col])
                
                # Chaikin A/D Line
                if all_required:
                    df_copy['ad'] = talib.AD(
                        df_copy[high_col],
                        df_copy[low_col],
                        df_copy[close_col],
                        df_copy[volume_col]
                    )
                
                # Chaikin Money Flow
                if all_required:
                    mfm = ((df_copy[close_col] - df_copy[low_col]) - (df_copy[high_col] - df_copy[close_col])) / (df_copy[high_col] - df_copy[low_col])
                    mfm = mfm.replace([np.inf, -np.inf], 0)
                    mfv = mfm * df_copy[volume_col]
                    df_copy['cmf'] = mfv.rolling(20).sum() / df_copy[volume_col].rolling(20).sum()
                    
                # Volume Weighted Average Price (VWAP)
                if open_col in df_copy.columns and all_required:
                    typical_price = (df_copy[high_col] + df_copy[low_col] + df_copy[close_col]) / 3
                    df_copy['vwap'] = (typical_price * df_copy[volume_col]).cumsum() / df_copy[volume_col].cumsum()
        
        except Exception as e:
            logger.error(f"Error calculating technical indicators: {str(e)}")
            
        return df_copy
    
    def add_lagged_features(self, 
                         df: pd.DataFrame, 
                         columns: List[str],
                         lags: List[int] = [1, 5, 10]) -> pd.DataFrame:
        """
        Add lagged versions of specified columns.
        
        Args:
            df: Input dataframe
            columns: List of columns to create lags for
            lags: List of lag periods to create
            
        Returns:
            DataFrame with lagged features
        """
        df_copy = df.copy()
        
        logger.info(f"Adding lagged features for {len(columns)} columns with lags {lags}")
        
        for col in columns:
            if col not in df_copy.columns:
                logger.warning(f"Column '{col}' not found in dataframe")
                continue
                
            for lag in lags:
                df_copy[f'{col}_lag_{lag}'] = df_copy[col].shift(lag)
                
        return df_copy
    
    def add_rolling_features(self, 
                          df: pd.DataFrame, 
                          columns: List[str],
                          windows: List[int] = [5, 10, 20],
                          functions: List[str] = ['mean', 'std', 'min', 'max']) -> pd.DataFrame:
        """
        Add rolling window calculations for specified columns.
        
        Args:
            df: Input dataframe
            columns: List of columns to create rolling features for
            windows: List of window sizes
            functions: List of aggregation functions to apply
            
        Returns:
            DataFrame with rolling features
        """
        df_copy = df.copy()
        
        logger.info(f"Adding rolling features for {len(columns)} columns")
        
        for col in columns:
            if col not in df_copy.columns:
                logger.warning(f"Column '{col}' not found in dataframe")
                continue
                
            for window in windows:
                for func in functions:
                    if func == 'mean':
                        df_copy[f'{col}_roll_{window}_mean'] = df_copy[col].rolling(window=window).mean()
                    elif func == 'std':
                        df_copy[f'{col}_roll_{window}_std'] = df_copy[col].rolling(window=window).std()
                    elif func == 'min':
                        df_copy[f'{col}_roll_{window}_min'] = df_copy[col].rolling(window=window).min()
                    elif func == 'max':
                        df_copy[f'{col}_roll_{window}_max'] = df_copy[col].rolling(window=window).max()
                    elif func == 'sum':
                        df_copy[f'{col}_roll_{window}_sum'] = df_copy[col].rolling(window=window).sum()
                    elif func == 'median':
                        df_copy[f'{col}_roll_{window}_median'] = df_copy[col].rolling(window=window).median()
                    elif func == 'skew':
                        df_copy[f'{col}_roll_{window}_skew'] = df_copy[col].rolling(window=window).skew()
                    elif func == 'kurt':
                        df_copy[f'{col}_roll_{window}_kurt'] = df_copy[col].rolling(window=window).kurt()
                        
        return df_copy
    
    def add_seasonal_features(self, 
                           df: pd.DataFrame,
                           date_column: Optional[str] = None) -> pd.DataFrame:
        """
        Add seasonal features based on time patterns.
        
        Args:
            df: Input dataframe
            date_column: Name of date column (None to use index)
            
        Returns:
            DataFrame with seasonal features
        """
        df_copy = df.copy()
        
        # Get datetime series from index or column
        if date_column is None:
            if not isinstance(df_copy.index, pd.DatetimeIndex):
                logger.warning("Index is not DatetimeIndex and no date_column provided")
                return df_copy
            dt = df_copy.index
        else:
            if date_column not in df_copy.columns:
                logger.warning(f"Date column '{date_column}' not found in dataframe")
                return df_copy
            dt = pd.to_datetime(df_copy[date_column])
        
        logger.info("Adding seasonal features")
        
        # Cyclical encoding for day of week (0-6)
        df_copy['day_of_week_sin'] = np.sin(2 * np.pi * dt.dayofweek / 7)
        df_copy['day_of_week_cos'] = np.cos(2 * np.pi * dt.dayofweek / 7)
        
        # Cyclical encoding for month (1-12)
        df_copy['month_sin'] = np.sin(2 * np.pi * dt.month / 12)
        df_copy['month_cos'] = np.cos(2 * np.pi * dt.month / 12)
        
        # Cyclical encoding for day of month (1-31)
        max_days = 31
        df_copy['day_of_month_sin'] = np.sin(2 * np.pi * dt.day / max_days)
        df_copy['day_of_month_cos'] = np.cos(2 * np.pi * dt.day / max_days)
        
        # Quarter
        df_copy['quarter'] = dt.quarter
        
        # Year
        df_copy['year'] = dt.year
        
        # Is month start/end
        df_copy['is_month_start'] = dt.is_month_start.astype(int)
        df_copy['is_month_end'] = dt.is_month_end.astype(int)
        
        # Is quarter start/end
        df_copy['is_quarter_start'] = dt.is_quarter_start.astype(int)
        df_copy['is_quarter_end'] = dt.is_quarter_end.astype(int)
        
        # Is year start/end
        df_copy['is_year_start'] = dt.is_year_start.astype(int)
        df_copy['is_year_end'] = dt.is_year_end.astype(int)
        
        # Is business day (weekday)
        df_copy['is_business_day'] = (dt.dayofweek < 5).astype(int)
        
        # For intraday data, add time-of-day features
        if hasattr(dt, 'hour') and not (dt.hour == 0).all():
            # Cyclical encoding for hour (0-23)
            df_copy['hour_sin'] = np.sin(2 * np.pi * dt.hour / 24)
            df_copy['hour_cos'] = np.cos(2 * np.pi * dt.hour / 24)
            
            # Market session flags (approximate)
            df_copy['is_market_open'] = ((dt.hour >= 9) & (dt.hour < 16)).astype(int)
            df_copy['is_pre_market'] = ((dt.hour >= 4) & (dt.hour < 9)).astype(int)
            df_copy['is_post_market'] = ((dt.hour >= 16) & (dt.hour < 20)).astype(int)
        
        return df_copy
    
    def perform_pca(self, 
                  df: pd.DataFrame, 
                  columns: List[str],
                  n_components: int = 5,
                  fit: bool = True) -> pd.DataFrame:
        """
        Perform PCA on selected columns.
        
        Args:
            df: Input dataframe
            columns: List of columns to use for PCA
            n_components: Number of components to retain
            fit: Whether to fit a new PCA transformer or use an existing one
            
        Returns:
            DataFrame with PCA components added
        """
        df_copy = df.copy()
        
        # Check if all columns are available
        missing_cols = [col for col in columns if col not in df_copy.columns]
        if missing_cols:
            logger.warning(f"Columns not found for PCA: {missing_cols}")
            return df_copy
        
        # Remove rows with NaN values for PCA calculation
        df_na_free = df_copy.dropna(subset=columns)
        if len(df_na_free) < 10:
            logger.warning("Too few complete rows for PCA")
            return df_copy
        
        # Standardize the data
        data = df_na_free[columns].values
        data_mean = data.mean(axis=0)
        data_std = data.std(axis=0)
        data_scaled = (data - data_mean) / data_std
        
        logger.info(f"Performing PCA on {len(columns)} columns to get {n_components} components")
        
        transformer_name = 'pca'
        if fit or transformer_name not in self.transformers:
            # Fit new PCA
            self.transformers[transformer_name] = PCA(n_components=n_components)
            self.transformers[transformer_name].fit(data_scaled)
            
            # Save the transformer
            joblib.dump(
                {
                    'pca': self.transformers[transformer_name],
                    'mean': data_mean,
                    'std': data_std,
                    'columns': columns
                },
                os.path.join(self.model_dir, 'pca_transformer.pkl')
            )
        
        # Apply PCA to get components
        pca_result = np.zeros((len(df_copy), n_components))
        pca_result[:] = np.nan
        
        # Get row indices in the original dataframe
        indices = df_na_free.index
        
        # Transform the data
        data_scaled = (df_na_free[columns].values - data_mean) / data_std
        transformed = self.transformers[transformer_name].transform(data_scaled)
        
        # Put transformed values back into result array at correct indices
        for i, idx in enumerate(indices):
            df_idx = df_copy.index.get_loc(idx)
            pca_result[df_idx] = transformed[i]
        
        # Add PCA components to dataframe
        for i in range(n_components):
            df_copy[f'pca_{i+1}'] = pca_result[:, i]
        
        return df_copy
    
    def add_interaction_features(self, 
                              df: pd.DataFrame, 
                              feature_pairs: List[tuple]) -> pd.DataFrame:
        """
        Add interaction features between pairs of columns.
        
        Args:
            df: Input dataframe
            feature_pairs: List of (col1, col2) tuples for interaction
            
        Returns:
            DataFrame with interaction features
        """
        df_copy = df.copy()
        
        logger.info(f"Adding interaction features for {len(feature_pairs)} pairs")
        
        for col1, col2 in feature_pairs:
            # Check if columns exist
            if col1 not in df_copy.columns or col2 not in df_copy.columns:
                logger.warning(f"Columns not found for interaction: {col1}, {col2}")
                continue
            
            # Product interaction
            df_copy[f'{col1}_times_{col2}'] = df_copy[col1] * df_copy[col2]
            
            # Ratio interaction (with safeguard against division by zero)
            denominator = df_copy[col2].replace(0, np.nan)
            df_copy[f'{col1}_div_{col2}'] = df_copy[col1] / denominator
            
            # Sum interaction
            df_copy[f'{col1}_plus_{col2}'] = df_copy[col1] + df_copy[col2]
            
            # Difference interaction
            df_copy[f'{col1}_minus_{col2}'] = df_copy[col1] - df_copy[col2]
        
        return df_copy