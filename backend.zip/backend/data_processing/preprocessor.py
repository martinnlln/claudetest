import pandas as pd
import numpy as np
from typing import Union, List, Optional, Dict, Any, Tuple
from sklearn.preprocessing import StandardScaler, MinMaxScaler, RobustScaler
from sklearn.impute import SimpleImputer, KNNImputer
import logging

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('preprocessor')

class DataPreprocessor:
    """
    Handles data cleaning, normalization, and preparation for modeling.
    """
    
    def __init__(self):
        """Initialize the preprocessor"""
        self.scalers = {}
        self.imputers = {}
        logger.info("Initialized DataPreprocessor")
    
    def handle_missing_values(self, 
                             df: pd.DataFrame, 
                             strategy: str = 'ffill',
                             columns: Optional[List[str]] = None) -> pd.DataFrame:
        """
        Handle missing values in the dataframe.
        
        Args:
            df: Input dataframe
            strategy: Strategy for handling missing values 
                     ('ffill', 'bfill', 'mean', 'median', 'knn', 'zero')
            columns: List of columns to process (None for all)
            
        Returns:
            DataFrame with imputed values
        """
        df_copy = df.copy()
        cols_to_process = columns if columns is not None else df.columns
        
        logger.info(f"Handling missing values using strategy: {strategy}")
        
        if strategy in ['ffill', 'bfill']:
            # Forward or backward fill
            df_copy[cols_to_process] = df_copy[cols_to_process].fillna(method=strategy)
            # Handle edges that might still have NaN
            df_copy[cols_to_process] = df_copy[cols_to_process].fillna(method='bfill' if strategy == 'ffill' else 'ffill')
        
        elif strategy in ['mean', 'median', 'most_frequent', 'zero']:
            actual_strategy = 'constant' if strategy == 'zero' else strategy
            fill_value = 0 if strategy == 'zero' else None
            
            for col in cols_to_process:
                if col not in self.imputers:
                    self.imputers[col] = SimpleImputer(
                        strategy=actual_strategy,
                        fill_value=fill_value
                    )
                    self.imputers[col].fit(df_copy[[col]])
                
                imputed_values = self.imputers[col].transform(df_copy[[col]])
                df_copy[col] = imputed_values
        
        elif strategy == 'knn':
            # Group all columns to process for KNN imputer
            if 'knn_imputer' not in self.imputers:
                self.imputers['knn_imputer'] = KNNImputer(n_neighbors=5)
                self.imputers['knn_imputer'].fit(df_copy[cols_to_process])
            
            imputed_values = self.imputers['knn_imputer'].transform(df_copy[cols_to_process])
            df_copy[cols_to_process] = imputed_values
        
        else:
            raise ValueError(f"Unsupported missing value handling strategy: {strategy}")
        
        # Check if we still have missing values
        if df_copy[cols_to_process].isna().any().any():
            logger.warning("Some missing values could not be imputed - filling with column means")
            df_copy[cols_to_process] = df_copy[cols_to_process].fillna(df_copy[cols_to_process].mean())
            
        return df_copy
    
    def remove_outliers(self, 
                      df: pd.DataFrame, 
                      method: str = 'iqr',
                      threshold: float = 1.5,
                      columns: Optional[List[str]] = None) -> pd.DataFrame:
        """
        Detect and handle outliers in the dataframe.
        
        Args:
            df: Input dataframe
            method: Method for outlier detection ('iqr', 'zscore')
            threshold: Threshold for outlier detection
            columns: List of columns to process (None for all numeric columns)
            
        Returns:
            DataFrame with outliers handled
        """
        df_copy = df.copy()
        
        # Select numeric columns if columns is None
        if columns is None:
            cols = df_copy.select_dtypes(include=np.number).columns.tolist()
        else:
            cols = columns
            
        logger.info(f"Detecting outliers using method: {method}")
        
        if method == 'iqr':
            for col in cols:
                Q1 = df_copy[col].quantile(0.25)
                Q3 = df_copy[col].quantile(0.75)
                IQR = Q3 - Q1
                
                lower_bound = Q1 - threshold * IQR
                upper_bound = Q3 + threshold * IQR
                
                # Instead of removing, winsorize the outliers
                df_copy[col] = np.where(df_copy[col] < lower_bound, lower_bound, df_copy[col])
                df_copy[col] = np.where(df_copy[col] > upper_bound, upper_bound, df_copy[col])
                
        elif method == 'zscore':
            for col in cols:
                mean = df_copy[col].mean()
                std = df_copy[col].std()
                
                # Winsorize values that are `threshold` standard deviations away from mean
                df_copy[col] = np.where(
                    abs(df_copy[col] - mean) > threshold * std,
                    np.sign(df_copy[col] - mean) * threshold * std + mean,
                    df_copy[col]
                )
        else:
            raise ValueError(f"Unsupported outlier detection method: {method}")
            
        return df_copy
    
    def scale_features(self, 
                     df: pd.DataFrame, 
                     method: str = 'standard',
                     columns: Optional[List[str]] = None,
                     fit: bool = True) -> pd.DataFrame:
        """
        Scale features in the dataframe.
        
        Args:
            df: Input dataframe
            method: Scaling method ('standard', 'minmax', 'robust')
            columns: List of columns to scale (None for all numeric columns)
            fit: Whether to fit the scaler or use previously fitted one
            
        Returns:
            DataFrame with scaled features
        """
        df_copy = df.copy()
        
        # Select numeric columns if columns is None
        if columns is None:
            cols = df_copy.select_dtypes(include=np.number).columns.tolist()
        else:
            cols = columns
            
        if not cols:
            logger.warning("No columns selected for scaling")
            return df_copy
            
        logger.info(f"Scaling features using method: {method}")
        
        # Initialize scaler based on method
        if method == 'standard':
            scaler_class = StandardScaler
        elif method == 'minmax':
            scaler_class = MinMaxScaler
        elif method == 'robust':
            scaler_class = RobustScaler
        else:
            raise ValueError(f"Unsupported scaling method: {method}")
        
        # Group all columns to use one scaler
        scaler_key = f"{method}_scaler"
        
        if fit or scaler_key not in self.scalers:
            self.scalers[scaler_key] = scaler_class()
            self.scalers[scaler_key].fit(df_copy[cols])
        
        # Transform the data
        scaled_data = self.scalers[scaler_key].transform(df_copy[cols])
        df_copy[cols] = scaled_data
        
        return df_copy
    
    def create_timeseries_features(self, 
                                 df: pd.DataFrame,
                                 date_column: Optional[str] = None) -> pd.DataFrame:
        """
        Create time series features from a date/datetime index or column.
        
        Args:
            df: Input dataframe
            date_column: Name of date column (None to use index)
            
        Returns:
            DataFrame with additional time features
        """
        df_copy = df.copy()
        
        # Get datetime series from index or column
        if date_column is None:
            if not isinstance(df_copy.index, pd.DatetimeIndex):
                logger.warning("Index is not DatetimeIndex and no date_column provided")
                return df_copy
            dt = df_copy.index
        else:
            if date_column not in df_copy.columns:
                logger.warning(f"Date column '{date_column}' not found in dataframe")
                return df_copy
            dt = pd.to_datetime(df_copy[date_column])
        
        logger.info("Creating time series features")
        
        # Create time features
        df_copy['day'] = dt.day
        df_copy['month'] = dt.month
        df_copy['year'] = dt.year
        df_copy['day_of_week'] = dt.dayofweek
        df_copy['week_of_year'] = dt.isocalendar().week
        df_copy['is_month_start'] = dt.is_month_start.astype(int)
        df_copy['is_month_end'] = dt.is_month_end.astype(int)
        df_copy['quarter'] = dt.quarter
        
        # Business day indicator (Mon-Fri are 0-4)
        df_copy['is_business_day'] = (dt.dayofweek < 5).astype(int)
        
        # Hour features for intraday data if present
        if hasattr(dt, 'hour') and not (dt.hour == 0).all():
            df_copy['hour'] = dt.hour
            df_copy['is_market_open'] = ((dt.hour >= 9) & (dt.hour < 16)).astype(int)
        
        return df_copy
    
    def prepare_train_test_data(self,
                              df: pd.DataFrame, 
                              target_column: str,
                              feature_columns: Optional[List[str]] = None,
                              test_size: float = 0.2,
                              val_size: float = 0.1,
                              sequence_length: Optional[int] = None) -> Dict[str, Any]:
        """
        Prepare data for training, validation, and testing.
        
        Args:
            df: Input dataframe
            target_column: Target variable column name
            feature_columns: List of feature columns (None for all except target)
            test_size: Proportion of data for testing
            val_size: Proportion of remaining data for validation
            sequence_length: Length of sequences for time series models
            
        Returns:
            Dictionary containing X_train, y_train, X_val, y_val, X_test, y_test
        """
        # Make a copy
        df_copy = df.copy()
        
        # Use all columns except target if feature_columns is None
        if feature_columns is None:
            feature_columns = [col for col in df_copy.columns if col != target_column]
        
        # Ensure target column exists
        if target_column not in df_copy.columns:
            raise ValueError(f"Target column '{target_column}' not found in dataframe")
        
        # Split indices by time (assuming data is time-ordered)
        n = len(df_copy)
        test_idx = int(n * (1 - test_size))
        val_idx = int(test_idx * (1 - val_size))
        
        # Regular train/val/test split (without sequences)
        if sequence_length is None:
            train_data = df_copy.iloc[:val_idx]
            val_data = df_copy.iloc[val_idx:test_idx]
            test_data = df_copy.iloc[test_idx:]
            
            X_train = train_data[feature_columns]
            y_train = train_data[target_column]
            
            X_val = val_data[feature_columns]
            y_val = val_data[target_column]
            
            X_test = test_data[feature_columns]
            y_test = test_data[target_column]
            
            result = {
                'X_train': X_train,
                'y_train': y_train,
                'X_val': X_val,
                'y_val': y_val,
                'X_test': X_test,
                'y_test': y_test,
                'feature_columns': feature_columns,
                'target_column': target_column
            }
        
        # Create sequences for time series models
        else:
            X_train_seq, y_train_seq = self._create_sequences(
                df_copy.iloc[:val_idx], 
                sequence_length, 
                feature_columns, 
                target_column
            )
            
            X_val_seq, y_val_seq = self._create_sequences(
                df_copy.iloc[val_idx-sequence_length:test_idx],  # Include overlap for correct sequences
                sequence_length, 
                feature_columns, 
                target_column
            )
            
            X_test_seq, y_test_seq = self._create_sequences(
                df_copy.iloc[test_idx-sequence_length:],  # Include overlap for correct sequences
                sequence_length, 
                feature_columns, 
                target_column
            )
            
            result = {
                'X_train': X_train_seq,
                'y_train': y_train_seq,
                'X_val': X_val_seq,
                'y_val': y_val_seq,
                'X_test': X_test_seq,
                'y_test': y_test_seq,
                'feature_columns': feature_columns,
                'target_column': target_column
            }
        
        logger.info(f"Data split - Train: {len(result['X_train'])}, Val: {len(result['X_val'])}, Test: {len(result['X_test'])}")
        return result
    
    def _create_sequences(self, 
                        df: pd.DataFrame, 
                        sequence_length: int,
                        feature_columns: List[str],
                        target_column: str) -> Tuple[np.ndarray, np.ndarray]:
        """
        Create sequences for time series prediction.
        
        Args:
            df: Input dataframe
            sequence_length: Length of input sequences
            feature_columns: Feature column names
            target_column: Target column name
            
        Returns:
            Tuple of (X, y) where X has shape (samples, sequence_length, features)
            and y has shape (samples,)
        """
        X, y = [], []
        
        for i in range(len(df) - sequence_length):
            X.append(df[feature_columns].iloc[i:i+sequence_length].values)
            y.append(df[target_column].iloc[i+sequence_length])
            
        return np.array(X), np.array(y)