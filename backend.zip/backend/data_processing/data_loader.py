import pandas as pd
import yfinance as yf
import ccxt
import os
import logging
from typing import Optional, Union, List, Dict, Any
from datetime import datetime, timedelta

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('data_loader')

class DataLoader:
    """
    Handles data acquisition from various sources like Yahoo Finance, crypto exchanges,
    CSV files, and databases.
    """
    
    def __init__(self, cache_dir: str = './data_cache'):
        """
        Initialize the DataLoader with optional cache directory.
        
        Args:
            cache_dir: Directory to store cached data
        """
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)
        logger.info(f"Initialized DataLoader with cache directory: {cache_dir}")
    
    def load_stock_data(self, 
                      ticker: str, 
                      start_date: Union[str, datetime],
                      end_date: Union[str, datetime] = None,
                      interval: str = '1d',
                      use_cache: bool = True) -> pd.DataFrame:
        """
        Load stock data from Yahoo Finance.
        
        Args:
            ticker: Stock ticker symbol
            start_date: Start date for data range
            end_date: End date for data range (defaults to today)
            interval: Data frequency ('1d', '1h', etc.)
            use_cache: Whether to use cached data if available
            
        Returns:
            DataFrame with OHLCV data
        """
        if end_date is None:
            end_date = datetime.now()
            
        cache_file = os.path.join(
            self.cache_dir, 
            f"{ticker}_{interval}_{pd.to_datetime(start_date).strftime('%Y%m%d')}_{pd.to_datetime(end_date).strftime('%Y%m%d')}.parquet"
        )
        
        # Check cache first if enabled
        if use_cache and os.path.exists(cache_file):
            logger.info(f"Loading cached data for {ticker} from {cache_file}")
            return pd.read_parquet(cache_file)
        
        logger.info(f"Fetching {ticker} data from Yahoo Finance from {start_date} to {end_date}")
        try:
            data = yf.download(
                ticker,
                start=start_date,
                end=end_date,
                interval=interval,
                progress=False
            )
            
            # Handle empty data
            if data.empty:
                logger.warning(f"No data found for {ticker} in specified date range")
                return pd.DataFrame()
            
            # Save to cache
            if use_cache:
                data.to_parquet(cache_file)
                logger.info(f"Saved data to cache: {cache_file}")
                
            return data
        except Exception as e:
            logger.error(f"Error fetching data for {ticker}: {str(e)}")
            raise
    
    def load_crypto_data(self,
                        symbol: str,
                        exchange: str = 'binance',
                        start_date: Union[str, datetime] = None,
                        end_date: Union[str, datetime] = None,
                        timeframe: str = '1d',
                        use_cache: bool = True) -> pd.DataFrame:
        """
        Load cryptocurrency data from exchanges using ccxt.
        
        Args:
            symbol: Cryptocurrency pair (e.g., 'BTC/USDT')
            exchange: Exchange name (e.g., 'binance', 'coinbase')
            start_date: Start date for data range
            end_date: End date for data range (defaults to today)
            timeframe: Data frequency ('1d', '1h', etc.)
            use_cache: Whether to use cached data if available
            
        Returns:
            DataFrame with OHLCV data
        """
        if end_date is None:
            end_date = datetime.now()
        if start_date is None:
            start_date = end_date - timedelta(days=365)
        
        cache_file = os.path.join(
            self.cache_dir, 
            f"{exchange}_{symbol.replace('/', '_')}_{timeframe}_{pd.to_datetime(start_date).strftime('%Y%m%d')}_{pd.to_datetime(end_date).strftime('%Y%m%d')}.parquet"
        )
        
        # Check cache first if enabled
        if use_cache and os.path.exists(cache_file):
            logger.info(f"Loading cached data for {symbol} from {cache_file}")
            return pd.read_parquet(cache_file)
        
        logger.info(f"Fetching {symbol} data from {exchange}")
        try:
            # Initialize exchange
            exchange_class = getattr(ccxt, exchange)
            exchange_instance = exchange_class({
                'enableRateLimit': True,
            })
            
            # Convert dates to timestamps
            since = int(pd.to_datetime(start_date).timestamp() * 1000)
            until = int(pd.to_datetime(end_date).timestamp() * 1000)
            
            # Fetch OHLCV data
            ohlcv = []
            while since < until:
                batch = exchange_instance.fetch_ohlcv(symbol, timeframe, since)
                if not batch:
                    break
                
                ohlcv.extend(batch)
                since = batch[-1][0] + 1  # Last timestamp + 1ms
                
            # Convert to DataFrame
            if not ohlcv:
                logger.warning(f"No data found for {symbol} on {exchange}")
                return pd.DataFrame()
                
            df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            df.set_index('timestamp', inplace=True)
            
            # Save to cache
            if use_cache:
                df.to_parquet(cache_file)
                logger.info(f"Saved data to cache: {cache_file}")
                
            return df
        except Exception as e:
            logger.error(f"Error fetching data for {symbol} from {exchange}: {str(e)}")
            raise
    
    def load_csv_data(self, 
                    filepath: str, 
                    parse_dates: Union[bool, List[str]] = True,
                    index_col: Optional[Union[str, int]] = 0,
                    date_format: Optional[str] = None) -> pd.DataFrame:
        """
        Load data from a CSV file.
        
        Args:
            filepath: Path to CSV file
            parse_dates: Column(s) to parse as dates
            index_col: Column to use as index
            date_format: Format string for date parsing
            
        Returns:
            DataFrame with data from CSV
        """
        logger.info(f"Loading data from CSV: {filepath}")
        try:
            df = pd.read_csv(
                filepath,
                parse_dates=parse_dates,
                index_col=index_col,
                date_format=date_format
            )
            return df
        except Exception as e:
            logger.error(f"Error loading CSV data from {filepath}: {str(e)}")
            raise
    
    def load_database_data(self, 
                         query: str,
                         connection_string: str,
                         params: Optional[Dict[str, Any]] = None) -> pd.DataFrame:
        """
        Load data from a database using SQL query.
        
        Args:
            query: SQL query string
            connection_string: Database connection string
            params: Parameters for the SQL query
            
        Returns:
            DataFrame with query results
        """
        logger.info(f"Executing database query")
        try:
            return pd.read_sql(query, connection_string, params=params)
        except Exception as e:
            logger.error(f"Error executing database query: {str(e)}")
            raise