from fastapi import FastAPI, HTTPException, Query, Depends
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Dict, Any, Optional
import asyncio
import pandas as pd
from datetime import datetime, timedelta
import os
import logging
from dotenv import load_dotenv

# Import your modules
from .data_processing.data_loader import DataLoader
from .data_processing.preprocessor import Preprocessor
from .data_processing.feature_engineering import FeatureEngineer
from .models.time_series import TimeSeriesModels
from .models.machine_learning import MLModels
from .models.deep_learning import DLModels
from .models.ensemble import EnsembleModels
from .utils.evaluation import ModelEvaluator
from .utils.visualization import DataVisualizer

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Price Prediction API",
    description="API for financial price prediction using multiple data sources",
    version="1.0.0"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For production, specify your frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize data sources
data_sources = {
    "alpha_vantage": {
        "api_key": os.getenv("ALPHA_VANTAGE_API_KEY"),
        "base_url": "https://www.alphavantage.co/query",
        "enabled": True
    },
    "yahoo_finance": {
        "api_key": os.getenv("YAHOO_FINANCE_API_KEY"),
        "base_url": "https://yfapi.net",
        "enabled": True
    }, 
    "finnhub": {
        "api_key": os.getenv("FINNHUB_API_KEY"),
        "base_url": "https://finnhub.io/api/v1",
        "enabled": True
    },
    "coingecko": {
        "base_url": "https://api.coingecko.com/api/v3",
        "enabled": True
    },
    "fred": {
        "api_key": os.getenv("FRED_API_KEY"),
        "base_url": "https://api.stlouisfed.org/fred",
        "enabled": True
    }
}

# Initialize data loader with multiple sources
data_loader = DataLoader(data_sources)
preprocessor = Preprocessor()
feature_engineer = FeatureEngineer()

# Initialize models
time_series_models = TimeSeriesModels()
ml_models = MLModels()
dl_models = DLModels()
ensemble_models = EnsembleModels()
model_evaluator = ModelEvaluator()
data_visualizer = DataVisualizer()

# Data cache
data_cache = {}

# Helper function to get enabled data sources
def get_enabled_sources():
    return [name for name, config in data_sources.items() if config.get("enabled", False)]

@app.get("/")
async def root():
    return {"message": "Welcome to the Price Prediction API", "version": "1.0.0"}

@app.get("/api/sources")
async def list_data_sources():
    """List all available data sources and their status"""
    return {
        "enabled_sources": get_enabled_sources(),
        "all_sources": [{"name": name, "enabled": config.get("enabled", False)} 
                         for name, config in data_sources.items()]
    }

@app.post("/api/sources/{source_name}/toggle")
async def toggle_data_source(source_name: str, enable: bool = True):
    """Enable or disable a data source"""
    if source_name not in data_sources:
        raise HTTPException(status_code=404, detail=f"Data source {source_name} not found")
    
    data_sources[source_name]["enabled"] = enable
    return {"name": source_name, "enabled": enable}

@app.get("/api/symbols")
async def get_available_symbols(source: Optional[str] = None):
    """Get available symbols from all enabled sources or a specific source"""
    sources_to_query = [source] if source else get_enabled_sources()
    
    symbols = {}
    for src in sources_to_query:
        if src not in data_sources or not data_sources[src].get("enabled", False):
            continue
        try:
            symbols[src] = await data_loader.get_symbols(src)
        except Exception as e:
            logger.error(f"Failed to get symbols from {src}: {str(e)}")
            symbols[src] = {"error": str(e)}
    
    return {"symbols": symbols}

@app.get("/api/historical-data/{symbol}")
async def get_historical_data(
    symbol: str,
    sources: List[str] = Query(None),
    start_date: str = None,
    end_date: str = None,
    interval: str = "1d"
):
    """
    Get historical price data for a symbol from specified sources
    - interval options: 1m, 5m, 15m, 30m, 1h, 1d, 1wk, 1mo
    """
    if not sources:
        sources = get_enabled_sources()
    
    # Convert dates
    if not start_date:
        start_date = (datetime.now() - timedelta(days=365)).strftime("%Y-%m-%d")
    if not end_date:
        end_date = datetime.now().strftime("%Y-%m-%d")
    
    results = {}
    for source in sources:
        if source not in data_sources or not data_sources[source].get("enabled", False):
            continue
        
        try:
            data = await data_loader.fetch_historical_data(
                source, symbol, start_date, end_date, interval
            )
            if data is not None:
                # Preprocess the data
                data = preprocessor.clean_data(data)
                results[source] = data.to_dict(orient="records") if isinstance(data, pd.DataFrame) else data
        except Exception as e:
            logger.error(f"Error fetching data from {source} for {symbol}: {str(e)}")
            results[source] = {"error": str(e)}
    
    # Cache the combined data for later use
    cache_key = f"{symbol}_{start_date}_{end_date}_{interval}"
    combined_data = pd.DataFrame()
    
    for source, data in results.items():
        if isinstance(data, list) and len(data) > 0:
            source_df = pd.DataFrame(data)
            source_df['source'] = source
            combined_data = pd.concat([combined_data, source_df])
    
    if not combined_data.empty:
        data_cache[cache_key] = combined_data
    
    return {
        "symbol": symbol,
        "start_date": start_date,
        "end_date": end_date,
        "interval": interval,
        "data": results
    }

@app.get("/api/indicators/{symbol}")
async def calculate_indicators(
    symbol: str,
    sources: List[str] = Query(None),
    indicator_types: List[str] = Query(["trend", "momentum", "volatility", "volume"]),
    start_date: str = None,
    end_date: str = None,
    interval: str = "1d"
):
    """Calculate technical indicators for the specified symbol"""
    # First retrieve the historical data
    historical_data = await get_historical_data(symbol, sources, start_date, end_date, interval)
    
    results = {}
    cache_key = f"{symbol}_{start_date}_{end_date}_{interval}"
    
    if cache_key in data_cache:
        df = data_cache[cache_key]
        
        # Apply indicators based on types requested
        for indicator_type in indicator_types:
            try:
                if indicator_type == "trend":
                    from .indicators.trend import calculate_trend_indicators
                    results["trend"] = calculate_trend_indicators(df)
                elif indicator_type == "momentum":
                    from .indicators.momentum import calculate_momentum_indicators
                    results["momentum"] = calculate_momentum_indicators(df)
                elif indicator_type == "volatility":
                    from .indicators.volatility import calculate_volatility_indicators
                    results["volatility"] = calculate_volatility_indicators(df)
                elif indicator_type == "volume":
                    from .indicators.volume import calculate_volume_indicators
                    results["volume"] = calculate_volume_indicators(df)
                elif indicator_type == "sentiment":
                    from .indicators.sentiment import calculate_sentiment_indicators
                    results["sentiment"] = calculate_sentiment_indicators(df)
            except Exception as e:
                logger.error(f"Error calculating {indicator_type} indicators: {str(e)}")
                results[indicator_type] = {"error": str(e)}
    
    return {
        "symbol": symbol,
        "indicators": results,
        "raw_data": historical_data
    }

@app.get("/api/feature-engineering/{symbol}")
async def engineer_features(
    symbol: str,
    sources: List[str] = Query(None),
    start_date: str = None,
    end_date: str = None,
    interval: str = "1d",
    include_indicators: bool = True
):
    """Apply feature engineering to the data"""
    # First get indicators if requested
    if include_indicators:
        indicator_data = await calculate_indicators(
            symbol, sources, ["trend", "momentum", "volatility", "volume", "sentiment"],
            start_date, end_date, interval
        )
    else:
        historical_data = await get_historical_data(symbol, sources, start_date, end_date, interval)
        indicator_data = historical_data
    
    cache_key = f"{symbol}_{start_date}_{end_date}_{interval}"
    
    if cache_key in data_cache:
        df = data_cache[cache_key]
        try:
            # Apply feature engineering
            engineered_df = feature_engineer.create_features(df)
            # Update cache with engineered features
            data_cache[cache_key] = engineered_df
            result = engineered_df.to_dict(orient="records")
        except Exception as e:
            logger.error(f"Error in feature engineering: {str(e)}")
            result = {"error": str(e)}
    else:
        result = {"error": "No data available for feature engineering"}
    
    return {
        "symbol": symbol,
        "engineered_features": result
    }

@app.post("/api/train/{model_type}")
async def train_model(
    model_type: str,
    symbol: str,
    sources: List[str] = Query(None),
    start_date: str = None,
    end_date: str = None,
    features: List[str] = Query(None),
    target: str = "close",
    test_size: float = 0.2,
    params: Dict[str, Any] = None
):
    """
    Train a prediction model
    - model_type: time_series, ml, dl, or ensemble
    """
    # Get engineered features first
    feature_data = await engineer_features(symbol, sources, start_date, end_date)
    
    cache_key = f"{symbol}_{start_date}_{end_date}_1d"
    
    if cache_key not in data_cache:
        return {"error": "No data available for training"}
    
    df = data_cache[cache_key]
    
    # If specific features not provided, use all available numeric features
    if not features:
        features = df.select_dtypes(include=['number']).columns.tolist()
        # Remove the target from features if it exists
        if target in features:
            features.remove(target)
    
    try:
        # Split data into training and testing sets
        train_data, test_data = preprocessor.train_test_split(df, test_size)
        
        model_results = {}
        
        if model_type == "time_series":
            model, predictions = time_series_models.train_predict(
                train_data, test_data, target, params
            )
            model_results = {"model": str(model), "predictions": predictions.tolist()}
            
        elif model_type == "ml":
            model, predictions = ml_models.train_predict(
                train_data, test_data, features, target, params
            )
            model_results = {"model": str(model), "predictions": predictions.tolist()}
            
        elif model_type == "dl":
            model, predictions = dl_models.train_predict(
                train_data, test_data, features, target, params
            )
            model_results = {"model": str(model), "predictions": predictions.tolist()}
            
        elif model_type == "ensemble":
            model, predictions = ensemble_models.train_predict(
                train_data, test_data, features, target, params
            )
            model_results = {"model": str(model), "predictions": predictions.tolist()}
            
        else:
            return {"error": f"Unknown model type: {model_type}"}
        
        # Evaluate the model
        evaluation_metrics = model_evaluator.evaluate(test_data[target], predictions)
        
        return {
            "symbol": symbol,
            "model_type": model_type,
            "features": features,
            "target": target,
            "evaluation": evaluation_metrics,
            "results": model_results
        }
        
    except Exception as e:
        logger.error(f"Error training {model_type} model: {str(e)}")
        return {"error": f"Training failed: {str(e)}"}

@app.post("/api/predict/{model_type}")
async def predict_future(
    model_type: str,
    symbol: str,
    days_ahead: int = 7,
    trained_model_id: str = None,
    features: List[str] = Query(None),
    params: Dict[str, Any] = None
):
    """
    Generate price predictions for future dates
    """
    # This endpoint would use a previously trained model or train a new one
    # For simplicity, we'll train a new model in this example
    
    # Get the latest data
    end_date = datetime.now().strftime("%Y-%m-%d")
    start_date = (datetime.now() - timedelta(days=365)).strftime("%Y-%m-%d")
    
    # Train the model if no model ID is provided
    if not trained_model_id:
        training_result = await train_model(
            model_type, symbol, None, start_date, end_date, features, "close", 0.2, params
        )
        
        if "error" in training_result:
            return {"error": f"Failed to train model: {training_result['error']}"}
    
    # In a real implementation, you would load the saved model by ID
    # For this example, we'll just generate some mock predictions
    
    future_dates = [(datetime.now() + timedelta(days=i)).strftime("%Y-%m-%d") 
                    for i in range(1, days_ahead + 1)]
    
    # Mock predictions - in a real implementation this would use the actual model
    import numpy as np
    last_price = 100  # This would be extracted from the actual data
    predictions = last_price + np.cumsum(np.random.normal(0, 2, days_ahead))
    
    return {
        "symbol": symbol,
        "model_type": model_type,
        "prediction_dates": future_dates,
        "predicted_prices": predictions.tolist(),
        "confidence_intervals": {
            "lower": [p - p*0.05 for p in predictions.tolist()],
            "upper": [p + p*0.05 for p in predictions.tolist()]
        }
    }

@app.get("/api/visualization/{symbol}")
async def generate_visualization(
    symbol: str,
    viz_type: str = "price_history",  # price_history, indicators, prediction
    start_date: str = None,
    end_date: str = None
):
    """
    Generate visualization data for the frontend
    """
    # Get the data
    historical_data = await get_historical_data(symbol, None, start_date, end_date)
    
    cache_key = f"{symbol}_{start_date}_{end_date}_1d"
    
    if cache_key not in data_cache:
        return {"error": "No data available for visualization"}
    
    df = data_cache[cache_key]
    
    try:
        if viz_type == "price_history":
            viz_data = data_visualizer.price_history_chart(df)
        elif viz_type == "indicators":
            indicators_data = await calculate_indicators(symbol, None, ["trend", "momentum"], start_date, end_date)
            viz_data = data_visualizer.indicators_chart(df)
        elif viz_type == "prediction":
            # Get predictions first
            prediction_data = await predict_future("ensemble", symbol, 30)
            viz_data = data_visualizer.prediction_chart(df, prediction_data)
        else:
            viz_data = {"error": f"Unknown visualization type: {viz_type}"}
            
        return {
            "symbol": symbol,
            "visualization_type": viz_type,
            "data": viz_data
        }
    except Exception as e:
        logger.error(f"Error generating visualization: {str(e)}")
        return {"error": f"Visualization failed: {str(e)}"}

# Get news and sentiment data
@app.get("/api/news/{symbol}")
async def get_news(
    symbol: str,
    days: int = 7,
    limit: int = 20
):
    """Get recent news for a symbol"""
    try:
        from datetime import datetime, timedelta
        
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        news_data = await data_loader.fetch_news(
            symbol, start_date.strftime("%Y-%m-%d"), end_date.strftime("%Y-%m-%d"), limit
        )
        
        # If we have sentiment analysis capabilities
        from .indicators.sentiment import analyze_news_sentiment
        sentiment_results = analyze_news_sentiment(news_data)
        
        return {
            "symbol": symbol,
            "period": f"{days} days",
            "news": news_data,
            "sentiment": sentiment_results
        }
    except Exception as e:
        logger.error(f"Error fetching news for {symbol}: {str(e)}")
        return {"error": f"Failed to fetch news: {str(e)}"}

# Economic indicators endpoint
@app.get("/api/economic-indicators")
async def get_economic_indicators(
    indicators: List[str] = Query(["GDP", "UNRATE", "CPIAUCSL"]),  # Default FRED codes
    start_date: str = None,
    end_date: str = None
):
    """Get economic indicators from FRED"""
    if not start_date:
        start_date = (datetime.now() - timedelta(days=365)).strftime("%Y-%m-%d")
    if not end_date:
        end_date = datetime.now().strftime("%Y-%m-%d")
        
    results = {}
    
    try:
        for indicator in indicators:
            indicator_data = await data_loader.fetch_economic_data(
                "fred", indicator, start_date, end_date
            )
            results[indicator] = indicator_data
            
        return {
            "period": f"{start_date} to {end_date}",
            "indicators": results
        }
    except Exception as e:
        logger.error(f"Error fetching economic indicators: {str(e)}")
        return {"error": f"Failed to fetch economic data: {str(e)}"}

# Health check endpoint
@app.get("/health")
async def health_check():
    """API health check"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "data_sources": {name: {"enabled": config["enabled"]} 
                         for name, config in data_sources.items()}
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.api:app", host="0.0.0.0", port=8000, reload=True)