# backend/utils/visualization.py
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
from matplotlib.ticker import MaxNLocator
import plotly.graph_objects as go
from plotly.subplots import make_subplots


class DataVisualization:
    """Class containing methods for data visualization and plotting."""
    
    @staticmethod
    def plot_time_series(data, columns=None, title='Time Series Plot', figsize=(12, 6)):
        """
        Plot time series data.
        
        Args:
            data (pd.DataFrame): Time series data
            columns (list): Columns to plot (default: all)
            title (str): Plot title
            figsize (tuple): Figure size
            
        Returns:
            tuple: Figure and axes objects
        """
        fig, ax = plt.subplots(figsize=figsize)
        
        if columns is None:
            if isinstance(data, pd.DataFrame):
                columns = data.columns
            else:
                columns = ['Series']
                data = pd.DataFrame({columns[0]: data})
        
        for col in columns:
            ax.plot(data.index, data[col], label=col)
            
        ax.set_title(title)
        ax.set_xlabel('Date')
        ax.set_ylabel('Value')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        return fig, ax
    
    @staticmethod
    def plot_prediction_vs_actual(dates, y_true, y_pred, title='Prediction vs Actual', figsize=(12, 6)):
        """
        Plot prediction vs actual values.
        
        Args:
            dates (np.array/pd.Series): Dates or x-axis values
            y_true (np.array): True values
            y_pred (np.array): Predicted values
            title (str): Plot title
            figsize (tuple): Figure size
            
        Returns:
            tuple: Figure and axes objects
        """
        fig, ax = plt.subplots(figsize=figsize)
        
        ax.plot(dates, y_true, label='Actual', marker='o', alpha=0.7)
        ax.plot(dates, y_pred, label='Prediction', marker='x', alpha=0.7)
        
        ax.set_title(title)
        ax.set_xlabel('Date')
        ax.set_ylabel('Value')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        return fig, ax
    
    @staticmethod
    def plot_forecast(dates, historical, forecast, confidence_intervals=None, title='Forecast', figsize=(12, 6)):
        """
        Plot forecast with historical data and confidence intervals.
        
        Args:
            dates (list): List of dates [historical_dates, forecast_dates]
            historical (np.array): Historical values
            forecast (np.array): Forecast values
            confidence_intervals (tuple): Lower and upper bounds (optional)
            title (str): Plot title
            figsize (tuple): Figure size
            
        Returns:
            tuple: Figure and axes objects
        """
        historical_dates, forecast_dates = dates
        
        fig, ax = plt.subplots(figsize=figsize)
        
        # Plot historical data
        ax.plot(historical_dates, historical, label='Historical', color='blue')
        
        # Plot forecast
        ax.plot(forecast_dates, forecast, label='Forecast', color='red', linestyle='--')
        
        # Plot confidence intervals if provided
        if confidence_intervals is not None:
            lower_bound, upper_bound = confidence_intervals
            ax.fill_between(forecast_dates, lower_bound, upper_bound, 
                           color='red', alpha=0.2, label='Confidence Interval')
        
        ax.set_title(title)
        ax.set_xlabel('Date')
        ax.set_ylabel('Value')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        return fig, ax
    
    @staticmethod
    def plot_feature_importance(feature_names, importances, title='Feature Importance', figsize=(10, 8)):
        """
        Plot feature importance.
        
        Args:
            feature_names (list): List of feature names
            importances (np.array): Feature importance values
            title (str): Plot title
            figsize (tuple): Figure size
            
        Returns:
            tuple: Figure and axes objects
        """
        # Sort features by importance
        indices = np.argsort(importances)
        
        fig, ax = plt.subplots(figsize=figsize)
        
        # Create horizontal bar plot
        ax.barh(range(len(indices)), importances[indices], align='center')
        ax.set_yticks(range(len(indices)))
        ax.set_yticklabels([feature_names[i] for i in indices])
        ax.set_xlabel('Importance')
        ax.set_title(title)
        
        plt.tight_layout()
        return fig, ax
    
    @staticmethod
    def plot_correlation_matrix(data, title='Correlation Matrix', figsize=(12, 10)):
        """
        Plot correlation matrix.
        
        Args:
            data (pd.DataFrame): Input data
            title (str): Plot title
            figsize (tuple): Figure size
            
        Returns:
            tuple: Figure and axes objects
        """
        # Calculate correlation matrix
        corr_matrix = data.corr()
        
        # Create heatmap
        fig, ax = plt.subplots(figsize=figsize)
        sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', ax=ax, 
                   vmin=-1, vmax=1, center=0, fmt='.2f')
        
        ax.set_title(title)
        plt.tight_layout()
        
        return fig, ax
    
    @staticmethod
    def plot_roc_curve(fpr, tpr, auc_score, title='ROC Curve', figsize=(8, 6)):
        """
        Plot ROC curve for classification tasks.
        
        Args:
            fpr (np.array): False positive rates
            tpr (np.array): True positive rates
            auc_score (float): Area under the curve
            title (str): Plot title
            figsize (tuple): Figure size
            
        Returns:
            tuple: Figure and axes objects
        """
        fig, ax = plt.subplots(figsize=figsize)
        
        ax.plot(fpr, tpr, label=f'AUC = {auc_score:.3f}')
        ax.plot([0, 1], [0, 1], 'k--')  # Diagonal line
        
        ax.set_xlabel('False Positive Rate')
        ax.set_ylabel('True Positive Rate')
        ax.set_title(title)
        ax.legend()
        
        plt.tight_layout()
        return fig, ax
    
    @staticmethod
    def plot_learning_curve(train_sizes, train_scores, val_scores, title='Learning Curve', figsize=(10, 6)):
        """
        Plot learning curve to diagnose overfitting/underfitting.
        
        Args:
            train_sizes (np.array): Training set sizes
            train_scores (np.array): Training scores
            val_scores (np.array): Validation scores
            title (str): Plot title
            figsize (tuple): Figure size
            
        Returns:
            tuple: Figure and axes objects
        """
        train_mean = np.mean(train_scores, axis=1)
        train_std = np.std(train_scores, axis=1)
        val_mean = np.mean(val_scores, axis=1)
        val_std = np.std(val_scores, axis=1)
        
        fig, ax = plt.subplots(figsize=figsize)
        
        ax.plot(train_sizes, train_mean, label='Training score', color='blue', marker='o')
        ax.fill_between(train_sizes, train_mean - train_std, train_mean + train_std, color='blue', alpha=0.15)
        
        ax.plot(train_sizes, val_mean, label='Validation score', color='red', marker='o')
        ax.fill_between(train_sizes, val_mean - val_std, val_mean + val_std, color='red', alpha=0.15)
        
        ax.set_xlabel('Training Set Size')
        ax.set_ylabel('Score')
        ax.set_title(title)
        ax.legend(loc='best')
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        return fig, ax
    
    @staticmethod
    def plot_interactive_time_series(dates, series_dict, title='Interactive Time Series'):
        """
        Create an interactive time series plot using Plotly.
        
        Args:
            dates (np.array/list): Dates for x-axis
            series_dict (dict): Dictionary of series name to values
            title (str): Plot title
            
        Returns:
            plotly.graph_objects.Figure: Plotly figure object
        """
        fig = go.Figure()
        
        for name, values in series_dict.items():
            fig.add_trace(go.Scatter(
                x=dates,
                y=values,
                mode='lines+markers',
                name=name
            ))
            
        fig.update_layout(
            title=title,
            xaxis_title='Date',
            yaxis_title='Value',
            legend_title='Series',
            hovermode='x unified'
        )
        
        return fig
    
    @staticmethod
    def plot_candlestick(dates, open_prices, high_prices, low_prices, close_prices, 
                         volume=None, title='Candlestick Chart'):
        """
        Create a candlestick chart with optional volume subplot.
        
        Args:
            dates (list): List of dates
            open_prices (list): List of opening prices
            high_prices (list): List of high prices
            low_prices (list): List of low prices
            close_prices (list): List of closing prices
            volume (list): List of volumes (optional)
            title (str): Chart title
            
        Returns:
            plotly.graph_objects.Figure: Plotly figure object
        """
        if volume is not None:
            # Create figure with secondary y-axis (for volume)
            fig = make_subplots(rows=2, cols=1, shared_xaxes=True, 
                              vertical_spacing=0.1, row_heights=[0.7, 0.3])
                              
            # Add candlestick chart
            fig.add_trace(go.Candlestick(
                x=dates,
                open=open_prices,
                high=high_prices,
                low=low_prices,
                close=close_prices,
                name='Price'
            ), row=1, col=1)
            
            # Add volume bar chart
            fig.add_trace(go.Bar(
                x=dates,
                y=volume,
                name='Volume'
            ), row=2, col=1)
            
            # Update layout
            fig.update_layout(
                title=title,
                yaxis_title='Price',
                yaxis2_title='Volume',
                xaxis_rangeslider_visible=False
            )
        else:
            # Create figure without volume
            fig = go.Figure()
            
            # Add candlestick chart
            fig.add_trace(go.Candlestick(
                x=dates,
                open=open_prices,
                high=high_prices,
                low=low_prices,
                close=close_prices,
                name='Price'
            ))
            
            # Update layout
            fig.update_layout(
                title=title,
                yaxis_title='Price',
                xaxis_rangeslider_visible=True
            )
            
        return fig
    
    @staticmethod
    def plot_multiple_metrics(dates, metrics_dict, title='Performance Metrics Over Time', figsize=(14, 8)):
        """
        Plot multiple performance metrics over time.
        
        Args:
            dates (list): List of dates
            metrics_dict (dict): Dictionary of metric names to values
            title (str): Plot title
            figsize (tuple): Figure size
            
        Returns:
            tuple: Figure and axes objects
        """
        n_metrics = len(metrics_dict)
        fig, axes = plt.subplots(n_metrics, 1, figsize=figsize, sharex=True)
        
        # If there's only one metric, axes is not a list
        if n_metrics == 1:
            axes = [axes]
            
        for i, (metric_name, values) in enumerate(metrics_dict.items()):
            axes[i].plot(dates, values, marker='.', linestyle='-')
            axes[i].set_ylabel(metric_name)
            axes[i].grid(True, alpha=0.3)
            
        axes[-1].set_xlabel('Date')
        plt.suptitle(title)
        plt.tight_layout(rect=[0, 0, 1, 0.95])
        
        return fig, axes