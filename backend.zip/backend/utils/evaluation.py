# backend/utils/evaluation.py
import numpy as np
import pandas as pd
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import matplotlib.pyplot as plt
from scipy.stats import pearsonr


class ModelEvaluation:
    """Class containing methods for model evaluation and performance metrics."""
    
    @staticmethod
    def calculate_metrics(y_true, y_pred):
        """
        Calculate regression metrics for model evaluation.
        
        Args:
            y_true (np.array): True values
            y_pred (np.array): Predicted values
            
        Returns:
            dict: Dictionary of evaluation metrics
        """
        metrics = {}
        
        # Basic metrics
        metrics['mse'] = mean_squared_error(y_true, y_pred)
        metrics['rmse'] = np.sqrt(metrics['mse'])
        metrics['mae'] = mean_absolute_error(y_true, y_pred)
        metrics['r2'] = r2_score(y_true, y_pred)
        
        # Mean absolute percentage error
        metrics['mape'] = np.mean(np.abs((y_true - y_pred) / y_true)) * 100
        
        # Correlation coefficient
        metrics['corr'], _ = pearsonr(y_true, y_pred)
        
        # Direction accuracy
        y_true_dir = np.sign(np.diff(y_true))
        y_pred_dir = np.sign(np.diff(y_pred))
        metrics['direction_accuracy'] = np.mean(y_true_dir == y_pred_dir) * 100
        
        # Theil's U statistic (closer to 0 indicates better performance)
        numerator = np.sqrt(np.mean(np.square(y_true - y_pred)))
        denominator = np.sqrt(np.mean(np.square(y_true))) + np.sqrt(np.mean(np.square(y_pred)))
        metrics['theils_u'] = numerator / denominator
        
        return metrics
    
    @staticmethod
    def print_metrics(metrics, model_name="Model"):
        """
        Print evaluation metrics in a formatted way.
        
        Args:
            metrics (dict): Dictionary of evaluation metrics
            model_name (str): Name of the model
        """
        print(f"Performance Metrics for {model_name}:")
        print(f"RMSE: {metrics['rmse']:.4f}")
        print(f"MAE: {metrics['mae']:.4f}")
        print(f"MAPE: {metrics['mape']:.2f}%")
        print(f"R²: {metrics['r2']:.4f}")
        print(f"Correlation: {metrics['corr']:.4f}")
        print(f"Direction Accuracy: {metrics['direction_accuracy']:.2f}%")
        print(f"Theil's U: {metrics['theils_u']:.4f}")
        print("-" * 50)
    
    @staticmethod
    def compare_models(model_metrics, metric_names=None):
        """
        Compare multiple models based on selected metrics.
        
        Args:
            model_metrics (dict): Dictionary with model names as keys and metric dicts as values
            metric_names (list): List of metric names to compare
            
        Returns:
            pd.DataFrame: DataFrame with comparison results
        """
        if metric_names is None:
            metric_names = ['rmse', 'mae', 'r2', 'direction_accuracy']
            
        # Create DataFrame for comparison
        comparison = {}
        for model_name, metrics in model_metrics.items():
            comparison[model_name] = {metric: metrics[metric] for metric in metric_names}
            
        return pd.DataFrame(comparison).T
    
    @staticmethod
    def plot_residuals(y_true, y_pred, model_name="Model"):
        """
        Plot residuals analysis.
        
        Args:
            y_true (np.array): True values
            y_pred (np.array): Predicted values
            model_name (str): Name of the model
            
        Returns:
            tuple: Figure and axes objects
        """
        residuals = y_true - y_pred
        
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))
        
        # Residuals vs. Fitted values
        axes[0, 0].scatter(y_pred, residuals, alpha=0.5)
        axes[0, 0].axhline(y=0, color='r', linestyle='-')
        axes[0, 0].set_xlabel('Predicted values')
        axes[0, 0].set_ylabel('Residuals')
        axes[0, 0].set_title('Residuals vs. Predicted')
        
        # Residual histogram
        axes[0, 1].hist(residuals, bins=30, alpha=0.7)
        axes[0, 1].set_xlabel('Residual value')
        axes[0, 1].set_ylabel('Frequency')
        axes[0, 1].set_title('Residual Histogram')
        
        # QQ plot of residuals
        from scipy.stats import probplot
        probplot(residuals, plot=axes[1, 0])
        axes[1, 0].set_title('Normal Q-Q Plot')
        
        # Time series plot of residuals
        axes[1, 1].plot(residuals, marker='o', linestyle='', alpha=0.5)
        axes[1, 1].axhline(y=0, color='r', linestyle='-')
        axes[1, 1].set_xlabel('Observation')
        axes[1, 1].set_ylabel('Residual')
        axes[1, 1].set_title('Residuals vs. Order')
        
        plt.suptitle(f'Residual Analysis - {model_name}', fontsize=16)
        plt.tight_layout(rect=[0, 0, 1, 0.96])
        
        return fig, axes
    
    @staticmethod
    def rolling_window_evaluation(model, X, y, window_size, step_size=1, train_func=None, predict_func=None):
        """
        Evaluate model using a rolling window approach.
        
        Args:
            model: Model object
            X (np.array/pd.DataFrame): Feature data
            y (np.array/pd.Series): Target data
            window_size (int): Size of the rolling window
            step_size (int): Number of steps to advance window
            train_func (callable): Custom training function if needed
            predict_func (callable): Custom prediction function if needed
            
        Returns:
            dict: Dictionary with predictions and metrics for each window
        """
        results = {
            'predictions': [],
            'true_values': [],
            'window_metrics': []
        }
        
        # Default training and prediction functions
        if train_func is None:
            train_func = lambda m, X, y: m.fit(X, y)
            
        if predict_func is None:
            predict_func = lambda m, X: m.predict(X)
        
        # Rolling window evaluation
        for i in range(0, len(X) - window_size, step_size):
            # Split data for this window
            X_train = X[i:i+window_size]
            y_train = y[i:i+window_size]
            
            if i + window_size < len(X):
                X_test = X[i+window_size:i+window_size+1]
                y_test = y[i+window_size:i+window_size+1]
            else:
                break
            
            # Train model
            train_func(model, X_train, y_train)
            
            # Make prediction
            y_pred = predict_func(model, X_test)
            
            # Store results
            results['predictions'].append(y_pred[0])
            results['true_values'].append(y_test[0])
            
            # Calculate metrics for this window if we have enough predictions
            if len(results['predictions']) > 1:
                window_y_true = np.array(results['true_values'][-10:])
                window_y_pred = np.array(results['predictions'][-10:])
                metrics = ModelEvaluation.calculate_metrics(window_y_true, window_y_pred)
                results['window_metrics'].append(metrics)
        
        # Convert lists to arrays
        results['predictions'] = np.array(results['predictions'])
        results['true_values'] = np.array(results['true_values'])
        
        # Calculate overall metrics
        results['overall_metrics'] = ModelEvaluation.calculate_metrics(
            results['true_values'], results['predictions']
        )
        
        return results
    
    @staticmethod
    def cross_validation_time_series(model, X, y, n_splits=5, train_func=None, predict_func=None):
        """
        Perform time series cross-validation.
        
        Args:
            model: Model object
            X (np.array/pd.DataFrame): Feature data
            y (np.array/pd.Series): Target data
            n_splits (int): Number of splits for cross-validation
            train_func (callable): Custom training function if needed
            predict_func (callable): Custom prediction function if needed
            
        Returns:
            dict: Dictionary with cross-validation results
        """
        from sklearn.model_selection import TimeSeriesSplit
        
        # Default training and prediction functions
        if train_func is None:
            train_func = lambda m, X, y: m.fit(X, y)
            
        if predict_func is None:
            predict_func = lambda m, X: m.predict(X)
        
        # Create time series splitter
        tscv = TimeSeriesSplit(n_splits=n_splits)
        
        # Store results
        results = {
            'fold_metrics': [],
            'predictions': [],
            'true_values': []
        }
        
        # Perform cross-validation
        for i, (train_idx, test_idx) in enumerate(tscv.split(X)):
            X_train, X_test = X[train_idx], X[test_idx]
            y_train, y_test = y[train_idx], y[test_idx]
            
            # Train model
            train_func(model, X_train, y_train)
            
            # Make predictions
            y_pred = predict_func(model, X_test)
            
            # Calculate metrics
            metrics = ModelEvaluation.calculate_metrics(y_test, y_pred)
            results['fold_metrics'].append(metrics)
            
            # Store predictions and true values
            results['predictions'].append(y_pred)
            results['true_values'].append(y_test)
            
        # Concatenate all predictions and true values
        results['predictions'] = np.concatenate(results['predictions'])
        results['true_values'] = np.concatenate(results['true_values'])
        
        # Calculate overall metrics
        results['overall_metrics'] = ModelEvaluation.calculate_metrics(
            results['true_values'], results['predictions']
        )
        
        return results
    
    @staticmethod
    def confidence_intervals(y_pred, interval_width=0.95, std_dev=None):
        """
        Calculate confidence intervals for predictions.
        
        Args:
            y_pred (np.array): Predicted values
            interval_width (float): Width of confidence interval (0-1)
            std_dev (float): Standard deviation of predictions
            
        Returns:
            tuple: (lower_bound, upper_bound) arrays
        """
        if std_dev is None:
            # Estimate standard deviation from predictions
            std_dev = np.std(y_pred) * 1.5
            
        # Calculate z-score for the given interval width
        from scipy.stats import norm
        z_score = norm.ppf(1 - (1 - interval_width) / 2)
        
        # Calculate interval bounds
        lower_bound = y_pred - z_score * std_dev
        upper_bound = y_pred + z_score * std_dev
        
        return lower_bound, upper_bound