
# ===== data/data_aggregator.py =====
from typing import Dict, List, Optional
import asyncio
import pandas as pd
import numpy as np

class DataAggregator:
    """Aggregates data from multiple sources"""
    
    def __init__(self, providers: List[DataProvider]):
        self.providers = providers
        self.alternative_data = AlternativeDataProvider()
        self.cache = {}
        
    async def get_comprehensive_data(self, symbol: str, timeframe: str = '5m') -> Dict:
        """Fetch and aggregate all data sources"""
        
        tasks = [
            self._fetch_market_data(symbol, timeframe),
            self._fetch_alternative_data(symbol),
            self._fetch_market_depth(symbol)
        ]
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Combine results
        comprehensive_data = {
            'market_data': results[0] if not isinstance(results[0], Exception) else None,
            'alternative_data': results[1] if not isinstance(results[1], Exception) else {},
            'market_depth': results[2] if not isinstance(results[2], Exception) else {}
        }
        
        return comprehensive_data
    
    async def _fetch_market_data(self, symbol: str, timeframe: str) -> pd.DataFrame:
        """Fetch OHLCV from multiple exchanges and combine"""
        
        dfs = []
        for provider in self.providers:
            try:
                df = await provider.fetch_ohlcv(symbol, timeframe, 1000)
                df['source'] = provider.__class__.__name__
                dfs.append(df)
            except:
                continue
        
        if not dfs:
            raise DataFetchError("No data available from any provider")
        
        # Combine and validate data
        combined_df = pd.concat(dfs).groupby(level=0).mean()
        return self._validate_data(combined_df)
    
    async def _fetch_alternative_data(self, symbol: str) -> Dict:
        """Fetch all alternative data sources"""
        
        tasks = [
            self.alternative_data.fetch_fear_greed_index(),
            self.alternative_data.fetch_social_sentiment(symbol),
            self.alternative_data.fetch_on_chain_metrics(symbol)
        ]
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        return {
            'fear_greed': results[0] if not isinstance(results[0], Exception) else 50,
            'social_sentiment': results[1] if not isinstance(results[1], Exception) else {},
            'on_chain': results[2] if not isinstance(results[2], Exception) else {}
        }
    
    async def _fetch_market_depth(self, symbol: str) -> Dict:
        """Analyze market depth across exchanges"""
        
        orderbooks = []
        for provider in self.providers:
            try:
                ob = await provider.fetch_orderbook(symbol)
                orderbooks.append(ob)
            except:
                continue
        
        if not orderbooks:
            return {}
        
        # Aggregate orderbook data
        return self._analyze_market_depth(orderbooks)
    
    def _analyze_market_depth(self, orderbooks: List[Dict]) -> Dict:
        """Analyze aggregated orderbook data"""
        
        all_bids = []
        all_asks = []
        
        for ob in orderbooks:
            all_bids.extend(ob['bids'])
            all_asks.extend(ob['asks'])
        
        # Sort and analyze
        all_bids.sort(key=lambda x: x[0], reverse=True)
        all_asks.sort(key=lambda x: x[0])
        
        # Calculate metrics
        bid_volume = sum(bid[1] for bid in all_bids[:100])
        ask_volume = sum(ask[1] for ask in all_asks[:100])
        
        spread = all_asks[0][0] - all_bids[0][0] if all_asks and all_bids else 0
        mid_price = (all_asks[0][0] + all_bids[0][0]) / 2 if all_asks and all_bids else 0
        
        # Detect walls
        bid_walls = self._detect_walls(all_bids)
        ask_walls = self._detect_walls(all_asks)
        
        return {
            'bid_volume': bid_volume,
            'ask_volume': ask_volume,
            'volume_imbalance': (bid_volume - ask_volume) / (bid_volume + ask_volume) if bid_volume + ask_volume > 0 else 0,
            'spread': spread,
            'spread_percentage': (spread / mid_price * 100) if mid_price > 0 else 0,
            'bid_walls': bid_walls,
            'ask_walls': ask_walls,
            'aggregated_orderbook': {
                'bids': all_bids[:50],
                'asks': all_asks[:50]
            }
        }
    
    def _detect_walls(self, orders: List) -> List[Dict]:
        """Detect order walls"""
        
        if len(orders) < 10:
            return []
        
        volumes = [order[1] for order in orders[:50]]
        mean_volume = np.mean(volumes)
        std_volume = np.std(volumes)
        
        walls = []
        for i, order in enumerate(orders[:50]):
            if order[1] > mean_volume + 2 * std_volume:
                walls.append({
                    'price': order[0],
                    'volume': order[1],
                    'strength': (order[1] - mean_volume) / std_volume
                })
        
        return walls
    
    def _validate_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Validate and clean data"""
        
        # Remove outliers
        for col in ['open', 'high', 'low', 'close']:
            q1 = df[col].quantile(0.01)
            q99 = df[col].quantile(0.99)
            df[col] = df[col].clip(lower=q1, upper=q99)
        
        # Forward fill missing values
        df.fillna(method='ffill', inplace=True)
        
        return df
