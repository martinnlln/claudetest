
# ===== data/market_data.py =====
import asyncio
import aiohttp
import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import ccxt.async_support as ccxt
from abc import ABC, abstractmethod
import websockets
import json

class DataProvider(ABC):
    @abstractmethod
    async def fetch_ohlcv(self, symbol: str, timeframe: str, limit: int) -> pd.DataFrame:
        pass
    
    @abstractmethod
    async def fetch_orderbook(self, symbol: str) -> Dict:
        pass
    
    @abstractmethod
    async def stream_trades(self, symbol: str, callback):
        pass

class BinanceProvider(DataProvider):
    def __init__(self):
        self.exchange = ccxt.binance({
            'enableRateLimit': True,
            'options': {'defaultType': 'spot'}
        })
        self.ws_connections = {}
        
    async def fetch_ohlcv(self, symbol: str, timeframe: str, limit: int) -> pd.DataFrame:
        try:
            ohlcv = await self.exchange.fetch_ohlcv(symbol, timeframe, limit=limit)
            df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            df.set_index('timestamp', inplace=True)
            return df
        except Exception as e:
            raise DataFetchError(f"Failed to fetch OHLCV data: {e}")
    
    async def fetch_orderbook(self, symbol: str) -> Dict:
        try:
            return await self.exchange.fetch_order_book(symbol, limit=50)
        except Exception as e:
            raise DataFetchError(f"Failed to fetch orderbook: {e}")
    
    async def stream_trades(self, symbol: str, callback):
        symbol_ws = symbol.lower().replace('/', '')
        url = f"wss://stream.binance.com:9443/ws/{symbol_ws}@aggTrade"
        
        async with websockets.connect(url) as websocket:
            self.ws_connections[symbol] = websocket
            while True:
                try:
                    message = await websocket.recv()
                    data = json.loads(message)
                    await callback(self._parse_trade(data))
                except Exception as e:
                    print(f"WebSocket error: {e}")
                    break
    
    def _parse_trade(self, data: Dict) -> Dict:
        return {
            'price': float(data['p']),
            'amount': float(data['q']),
            'side': 'buy' if data['m'] else 'sell',
            'timestamp': data['T']
        }

class AlternativeDataProvider:
    """Fetches alternative data sources"""
    
    def __init__(self):
        self.session = aiohttp.ClientSession()
    
    async def fetch_fear_greed_index(self) -> float:
        """Fetch crypto fear and greed index"""
        try:
            url = "https://api.alternative.me/fng/"
            async with self.session.get(url) as response:
                data = await response.json()
                return float(data['data'][0]['value'])
        except:
            return 50.0  # Neutral
    
    async def fetch_social_sentiment(self, symbol: str) -> Dict:
        """Aggregate social media sentiment"""
        # This would integrate with Twitter API, Reddit API, etc.
        # For production, implement real APIs
        return {
            'twitter_sentiment': np.random.uniform(0.3, 0.7),
            'reddit_mentions': np.random.randint(100, 1000),
            'news_sentiment': np.random.uniform(0.4, 0.6)
        }
    
    async def fetch_on_chain_metrics(self, symbol: str) -> Dict:
        """Fetch on-chain analytics"""
        # This would integrate with Glassnode, Santiment, etc.
        return {
            'active_addresses': np.random.randint(10000, 100000),
            'transaction_volume': np.random.uniform(1e8, 1e10),
            'exchange_inflow': np.random.uniform(-1e7, 1e7),
            'whale_transactions': np.random.randint(0, 50)
        }
