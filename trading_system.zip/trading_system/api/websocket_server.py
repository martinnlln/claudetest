
# ===== api/websocket_server.py =====
from flask_socketio import emit
import asyncio
from typing import Dict, List, Set
import json

class WebSocketServer:
    """Real-time WebSocket server for streaming data"""
    
    def __init__(self, socketio, data_aggregator, prediction_engine, signal_generator, risk_manager):
        self.socketio = socketio
        self.data_aggregator = data_aggregator
        self.prediction_engine = prediction_engine
        self.signal_generator = signal_generator
        self.risk_manager = risk_manager
        self.subscriptions = {}
        self.active_streams = {}
        
        # Register handlers
        self._register_handlers()
    
    def _register_handlers(self):
        """Register WebSocket event handlers"""
        
        @self.socketio.on('connect')
        def handle_connect():
            print(f"Client connected: {request.sid}")
            emit('connected', {
                'message': 'Connected to Quantum Trading System',
                'features': [
                    'real-time-predictions',
                    'microstructure-analysis',
                    'multi-model-ensemble',
                    'risk-management',
                    'sentiment-analysis'
                ]
            })
        
        @self.socketio.on('disconnect')
        def handle_disconnect():
            print(f"Client disconnected: {request.sid}")
            self._cleanup_subscriptions(request.sid)
        
        @self.socketio.on('subscribe')
        def handle_subscribe(data):
            symbol = data.get('symbol')
            features = data.get('features', ['all'])
            
            self.subscriptions[request.sid] = {
                'symbol': symbol,
                'features': features
            }
            
            # Start streaming
            asyncio.create_task(self._start_streaming(request.sid, symbol, features))
        
        @self.socketio.on('unsubscribe')
        def handle_unsubscribe():
            self._cleanup_subscriptions(request.sid)
        
        @self.socketio.on('update_risk_params')
        def handle_update_risk(data):
            # Update risk parameters
            if 'max_position_size' in data:
                self.risk_manager.config.max_position_size = data['max_position_size']
            
            emit('risk_params_updated', {'status': 'success'})
    
    async def _start_streaming(self, client_id: str, symbol: str, features: List[str]):
        """Start streaming data to client"""
        
        stream_key = f"{client_id}_{symbol}"
        self.active_streams[stream_key] = True
        
        while stream_key in self.active_streams and self.active_streams[stream_key]:
            try:
                # Gather all data
                data = await self._gather_streaming_data(symbol, features)
                
                # Emit to specific client
                self.socketio.emit('market_update', data, room=client_id)
                
                # Wait before next update
                await asyncio.sleep(1)  # 1 second updates
                
            except Exception as e:
                print(f"Streaming error: {e}")
                self.socketio.emit('error', {'message': str(e)}, room=client_id)
                break
    
    async def _gather_streaming_data(self, symbol: str, features: List[str]) -> Dict:
        """Gather all requested data for streaming"""
        
        data = {
            'timestamp': datetime.now().isoformat(),
            'symbol': symbol
        }
        
        # Get comprehensive market data
        market_data = await self.data_aggregator.get_comprehensive_data(symbol, '1m')
        
        if 'all' in features or 'price' in features:
            if market_data['market_data'] is not None:
                latest = market_data['market_data'].iloc[-1]
                data['price'] = {
                    'current': latest['close'],
                    'open': latest['open'],
                    'high': latest['high'],
                    'low': latest['low'],
                    'volume': latest['volume'],
                    'change': latest['close'] - market_data['market_data'].iloc[-2]['close'],
                    'change_percent': (latest['close'] - market_data['market_data'].iloc[-2]['close']) / 
                                    market_data['market_data'].iloc[-2]['close'] * 100
                }
        
        if 'all' in features or 'predictions' in features:
            # Get predictions
            predictions = self.prediction_engine.predict_multi_horizon(
                market_data['market_data'], symbol
            )
            data['predictions'] = predictions
        
        if 'all' in features or 'microstructure' in features:
            # Get orderbook and analyze
            orderbook = await self.data_aggregator.providers[0].fetch_orderbook(symbol)
            microstructure = MarketMicrostructureAnalyzer().analyze_order_book(orderbook)
            data['microstructure'] = microstructure
            data['orderbook'] = {
                'bids': orderbook['bids'][:20],
                'asks': orderbook['asks'][:20]
            }
        
        if 'all' in features or 'signals' in features:
            # Generate trading signal
            signal = self.signal_generator.generate_signal(
                market_data['market_data'],
                data.get('predictions', {}),
                data.get('microstructure', {}),
                market_data['alternative_data'].get('sentiment', {})
            )
            
            # Risk evaluation
            approved, risk_info = self.risk_manager.evaluate_signal(
                signal, 
                self.risk_manager.equity_curve[-1]
            )
            
            data['signal'] = {
                'type': signal.signal_type.value,
                'confidence': signal.confidence,
                'entry_price': signal.entry_price,
                'stop_loss': signal.stop_loss,
                'take_profit': signal.take_profit_levels,
                'position_size': signal.position_size,
                'risk_reward': signal.risk_reward_ratio,
                'approved': approved,
                'risk_info': risk_info,
                'reasons': signal.reasons,
                'metadata': signal.metadata
            }
        
        if 'all' in features or 'indicators' in features:
            # Technical indicators
            if market_data['market_data'] is not None:
                latest = market_data['market_data'].iloc[-1]
                data['indicators'] = {
                    'rsi': latest.get('rsi_14', 50),
                    'macd': latest.get('macd', 0),
                    'macd_signal': latest.get('macd_signal', 0),
                    'atr': latest.get('atr_14', 0),
                    'adx': latest.get('adx', 0),
                    'bb_upper': latest.get('bb_upper_20', 0),
                    'bb_lower': latest.get('bb_lower_20', 0),
                    'volume_ratio': latest.get('volume_ratio', 1)
                }
        
        if 'all' in features or 'sentiment' in features:
            data['sentiment'] = market_data['alternative_data'].get('sentiment', {})
        
        if 'all' in features or 'risk' in features:
            # Portfolio risk metrics
            risk_metrics = self.risk_manager.calculate_portfolio_metrics(
                {symbol: data.get('price', {}).get('current', 0)}
            )
            data['risk'] = {
                'portfolio_var': risk_metrics.portfolio_var,
                'sharpe_ratio': risk_metrics.sharpe_ratio,
                'current_drawdown': risk_metrics.current_drawdown,
                'risk_limits_usage': self.risk_manager._calculate_risk_limits_usage()
            }
        
        return data
    
    def _cleanup_subscriptions(self, client_id: str):
        """Clean up client subscriptions"""
        
        if client_id in self.subscriptions:
            symbol = self.subscriptions[client_id]['symbol']
            stream_key = f"{client_id}_{symbol}"
            
            if stream_key in self.active_streams:
                self.active_streams[stream_key] = False
                del self.active_streams[stream_key]
            
            del self.subscriptions[client_id]
