
# ===== api/rest_api.py =====
from flask import Blueprint, jsonify, request
from typing import Dict, List
import pandas as pd

class RestAPI:
    """RESTful API endpoints"""
    
    def __init__(self, app, data_aggregator, prediction_engine, signal_generator, risk_manager):
        self.app = app
        self.data_aggregator = data_aggregator
        self.prediction_engine = prediction_engine
        self.signal_generator = signal_generator
        self.risk_manager = risk_manager
        
        # Create blueprint
        self.api = Blueprint('api', __name__, url_prefix='/api/v1')
        
        # Register routes
        self._register_routes()
        
        # Register blueprint
        app.register_blueprint(self.api)
    
    def _register_routes(self):
        """Register all API routes"""
        
        @self.api.route('/symbols', methods=['GET'])
        async def get_symbols():
            """Get available trading symbols"""
            
            try:
                symbols = []
                for provider in self.data_aggregator.providers:
                    exchange_symbols = await provider.exchange.load_markets()
                    symbols.extend([s for s in exchange_symbols if s.endswith('/USDT')])
                
                unique_symbols = list(set(symbols))
                
                return jsonify({
                    'status': 'success',
                    'data': {
                        'symbols': sorted(unique_symbols)[:100],
                        'total': len(unique_symbols)
                    }
                })
            except Exception as e:
                return jsonify({
                    'status': 'error',
                    'message': str(e)
                }), 500
        
        @self.api.route('/market/<symbol>', methods=['GET'])
        async def get_market_data(symbol):
            """Get comprehensive market data"""
            
            try:
                timeframe = request.args.get('timeframe', '5m')
                
                data = await self.data_aggregator.get_comprehensive_data(symbol, timeframe)
                
                if data['market_data'] is not None:
                    # Convert DataFrame to JSON
                    market_data = data['market_data'].tail(500).reset_index().to_dict('records')
                else:
                    market_data = []
                
                return jsonify({
                    'status': 'success',
                    'data': {
                        'market_data': market_data,
                        'alternative_data': data['alternative_data'],
                        'market_depth': data['market_depth']
                    }
                })
            except Exception as e:
                return jsonify({
                    'status': 'error',
                    'message': str(e)
                }), 500
        
        @self.api.route('/predict/<symbol>', methods=['GET'])
        async def get_predictions(symbol):
            """Get AI predictions"""
            
            try:
                # Get market data
                data = await self.data_aggregator.get_comprehensive_data(symbol)
                
                if data['market_data'] is None:
                    return jsonify({
                        'status': 'error',
                        'message': 'No market data available'
                    }), 400
                
                # Generate predictions
                predictions = self.prediction_engine.predict_multi_horizon(
                    data['market_data'], symbol
                )
                
                return jsonify({
                    'status': 'success',
                    'data': predictions
                })
            except Exception as e:
                return jsonify({
                    'status': 'error',
                    'message': str(e)
                }), 500
        
        @self.api.route('/signal/<symbol>', methods=['GET'])
        async def get_signal(symbol):
            """Get trading signal"""
            
            try:
                # Get all required data
                market_data = await self.data_aggregator.get_comprehensive_data(symbol)
                
                if market_data['market_data'] is None:
                    return jsonify({
                        'status': 'error',
                        'message': 'No market data available'
                    }), 400
                
                # Get predictions
                predictions = self.prediction_engine.predict_multi_horizon(
                    market_data['market_data'], symbol
                )
                
                # Analyze microstructure
                orderbook = await self.data_aggregator.providers[0].fetch_orderbook(symbol)
                microstructure = MarketMicrostructureAnalyzer().analyze_order_book(orderbook)
                
                # Generate signal
                signal = self.signal_generator.generate_signal(
                    market_data['market_data'],
                    predictions,
                    microstructure,
                    market_data['alternative_data'].get('sentiment', {})
                )
                
                # Risk evaluation
                approved, risk_info = self.risk_manager.evaluate_signal(
                    signal,
                    self.risk_manager.equity_curve[-1]
                )
                
                # Adjust position size
                final_size = self.risk_manager.calculate_position_size_with_risk(
                    signal,
                    self.risk_manager.equity_curve[-1]
                )
                
                return jsonify({
                    'status': 'success',
                    'data': {
                        'signal': {
                            'type': signal.signal_type.value,
                            'confidence': signal.confidence,
                            'entry_price': signal.entry_price,
                            'stop_loss': signal.stop_loss,
                            'take_profit': signal.take_profit_levels,
                            'position_size': final_size,
                            'risk_reward': signal.risk_reward_ratio,
                            'expected_return': signal.expected_return,
                            'time_horizon': signal.time_horizon,
                            'reasons': signal.reasons,
                            'risk_factors': signal.risk_factors
                        },
                        'risk_approval': approved,
                        'risk_evaluation': risk_info
                    }
                })
            except Exception as e:
                return jsonify({
                    'status': 'error',
                    'message': str(e)
                }), 500
        
        @self.api.route('/portfolio/risk', methods=['GET'])
        def get_portfolio_risk():
            """Get portfolio risk metrics"""
            
            try:
                report = self.risk_manager.generate_risk_report()
                
                return jsonify({
                    'status': 'success',
                    'data': report
                })
            except Exception as e:
                return jsonify({
                    'status': 'error',
                    'message': str(e)
                }), 500
        
        @self.api.route('/backtest', methods=['POST'])
        async def run_backtest():
            """Run backtesting simulation"""
            
            try:
                params = request.json
                symbol = params.get('symbol')
                start_date = params.get('start_date')
                end_date = params.get('end_date')
                
                # This would run comprehensive backtesting
                # Placeholder for now
                
                results = {
                    'total_return': 125.5,
                    'sharpe_ratio': 2.1,
                    'max_drawdown': -15.3,
                    'win_rate': 68.5,
                    'total_trades': 342,
                    'profit_factor': 2.3
                }
                
                return jsonify({
                    'status': 'success',
                    'data': results
                })
            except Exception as e:
                return jsonify({
                    'status': 'error',
                    'message': str(e)
                }), 500