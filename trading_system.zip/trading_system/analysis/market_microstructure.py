
# ===== analysis/market_microstructure.py =====
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional
from scipy import stats
from collections import deque

class MarketMicrostructureAnalyzer:
    """Advanced market microstructure analysis"""
    
    def __init__(self):
        self.trade_flow = deque(maxlen=1000)
        self.order_book_history = deque(maxlen=100)
        self.liquidity_metrics = {}
        
    def analyze_order_book(self, orderbook: Dict) -> Dict:
        """Comprehensive orderbook analysis"""
        
        bids = np.array(orderbook['bids'])
        asks = np.array(orderbook['asks'])
        
        if len(bids) == 0 or len(asks) == 0:
            return {}
        
        # Basic metrics
        best_bid = bids[0][0]
        best_ask = asks[0][0]
        spread = best_ask - best_bid
        mid_price = (best_ask + best_bid) / 2
        
        # Depth analysis
        depth_levels = [1, 5, 10, 20]
        bid_depth = {}
        ask_depth = {}
        
        for level in depth_levels:
            bid_depth[f'level_{level}'] = bids[:level, 1].sum() if len(bids) >= level else bids[:, 1].sum()
            ask_depth[f'level_{level}'] = asks[:level, 1].sum() if len(asks) >= level else asks[:, 1].sum()
        
        # Imbalance metrics
        total_bid_volume = bids[:20, 1].sum()
        total_ask_volume = asks[:20, 1].sum()
        volume_imbalance = (total_bid_volume - total_ask_volume) / (total_bid_volume + total_ask_volume)
        
        # Weighted mid price
        weighted_mid = (best_bid * asks[0][1] + best_ask * bids[0][1]) / (bids[0][1] + asks[0][1])
        
        # Shape metrics
        bid_shape = self._calculate_book_shape(bids[:20])
        ask_shape = self._calculate_book_shape(asks[:20])
        
        # Liquidity cost
        liquidity_cost = self._calculate_liquidity_cost(bids, asks, mid_price)
        
        # Market quality metrics
        results = {
            'spread': spread,
            'spread_bps': spread / mid_price * 10000,
            'mid_price': mid_price,
            'weighted_mid_price': weighted_mid,
            'bid_ask_imbalance': volume_imbalance,
            'bid_depth': bid_depth,
            'ask_depth': ask_depth,
            'bid_shape': bid_shape,
            'ask_shape': ask_shape,
            'liquidity_cost': liquidity_cost,
            'effective_spread': self._calculate_effective_spread(bids, asks),
            'realized_spread': self._calculate_realized_spread(mid_price),
            'price_impact': self._estimate_price_impact(bids, asks),
            'market_depth_ratio': total_bid_volume / total_ask_volume if total_ask_volume > 0 else 0
        }
        
        # Detect special conditions
        results.update(self._detect_market_conditions(bids, asks, results))
        
        return results
    
    def _calculate_book_shape(self, orders: np.ndarray) -> Dict:
        """Analyze the shape of order book side"""
        
        if len(orders) < 2:
            return {'slope': 0, 'convexity': 0, 'concentration': 0}
        
        prices = orders[:, 0]
        volumes = orders[:, 1]
        cumulative_volume = np.cumsum(volumes)
        
        # Linear regression for slope
        slope, intercept, r_value, _, _ = stats.linregress(prices, cumulative_volume)
        
        # Convexity (second derivative approximation)
        if len(prices) >= 3:
            first_diff = np.diff(cumulative_volume)
            second_diff = np.diff(first_diff)
            convexity = np.mean(second_diff)
        else:
            convexity = 0
        
        # Concentration (Herfindahl index)
        volume_shares = volumes / volumes.sum()
        concentration = np.sum(volume_shares ** 2)
        
        return {
            'slope': slope,
            'convexity': convexity,
            'concentration': concentration,
            'r_squared': r_value ** 2
        }
    
    def _calculate_liquidity_cost(self, bids: np.ndarray, asks: np.ndarray, mid_price: float) -> Dict:
        """Calculate cost of executing various order sizes"""
        
        sizes = [10000, 50000, 100000, 500000]  # USD values
        costs = {}
        
        for size in sizes:
            # Buy cost
            buy_cost = self._calculate_execution_cost(asks, size / mid_price, 'buy')
            # Sell cost
            sell_cost = self._calculate_execution_cost(bids, size / mid_price, 'sell')
            
            costs[f'size_{size}'] = {
                'buy_cost_bps': buy_cost * 10000,
                'sell_cost_bps': sell_cost * 10000,
                'round_trip_bps': (buy_cost + sell_cost) * 10000
            }
        
        return costs
    
    def _calculate_execution_cost(self, orders: np.ndarray, target_volume: float, side: str) -> float:
        """Calculate cost of executing a specific volume"""
        
        if len(orders) == 0:
            return float('inf')
        
        cumulative_volume = 0
        weighted_price = 0
        
        for price, volume in orders:
            if cumulative_volume >= target_volume:
                break
            
            fill_volume = min(volume, target_volume - cumulative_volume)
            weighted_price += price * fill_volume
            cumulative_volume += fill_volume
        
        if cumulative_volume == 0:
            return float('inf')
        
        avg_execution_price = weighted_price / cumulative_volume
        
        if side == 'buy':
            return (avg_execution_price - orders[0][0]) / orders[0][0]
        else:
            return (orders[0][0] - avg_execution_price) / orders[0][0]
    
    def _calculate_effective_spread(self, bids: np.ndarray, asks: np.ndarray) -> float:
        """Calculate effective spread based on probable execution"""
        
        if len(bids) == 0 or len(asks) == 0:
            return 0
        
        # Weight by inverse of level (closer levels more important)
        weights = 1 / np.arange(1, min(len(bids), len(asks), 5) + 1)
        weights = weights / weights.sum()
        
        weighted_spread = 0
        for i, w in enumerate(weights):
            weighted_spread += w * (asks[i][0] - bids[i][0])
        
        return weighted_spread
    
    def _calculate_realized_spread(self, mid_price: float) -> float:
        """Calculate realized spread from recent trades"""
        
        if len(self.trade_flow) < 10:
            return 0
        
        recent_trades = list(self.trade_flow)[-10:]
        realized_spreads = []
        
        for trade in recent_trades:
            if trade['side'] == 'buy':
                realized = 2 * (trade['price'] - mid_price) / mid_price
            else:
                realized = 2 * (mid_price - trade['price']) / mid_price
            realized_spreads.append(abs(realized))
        
        return np.mean(realized_spreads) * 10000  # in bps
    
    def _estimate_price_impact(self, bids: np.ndarray, asks: np.ndarray) -> Dict:
        """Estimate price impact function"""
        
        if len(bids) < 5 or len(asks) < 5:
            return {'linear': 0, 'sqrt': 0}
        
        # Kyle's lambda (linear impact)
        bid_volumes = bids[:10, 1]
        ask_volumes = asks[:10, 1]
        bid_prices = bids[:10, 0]
        ask_prices = asks[:10, 0]
        
        # Linear impact coefficient
        total_volume = bid_volumes.sum() + ask_volumes.sum()
        price_range = ask_prices[-1] - bid_prices[-1]
        linear_impact = price_range / total_volume if total_volume > 0 else 0
        
        # Square-root impact (Almgren)
        avg_volume = total_volume / 20
        sqrt_impact = price_range / np.sqrt(total_volume) if total_volume > 0 else 0
        
        return {
            'linear': linear_impact * 1e6,  # per million units
            'sqrt': sqrt_impact * 1000,     # per thousand units
            'instantaneous': (asks[0][0] - bids[0][0]) / (bids[0][0] + asks[0][0]) * 2
        }
    
    def _detect_market_conditions(self, bids: np.ndarray, asks: np.ndarray, metrics: Dict) -> Dict:
        """Detect special market conditions"""
        
        conditions = {
            'thin_market': metrics['spread_bps'] > 10,
            'one_sided_market': abs(metrics['bid_ask_imbalance']) > 0.7,
            'stressed_market': metrics['spread_bps'] > 20 and abs(metrics['bid_ask_imbalance']) > 0.5,
            'locked_market': metrics['spread'] <= 0,
            'crossed_market': metrics['spread'] < 0
        }
        
        # Detect potential spoofing
        if len(bids) > 10 and len(asks) > 10:
            bid_concentration = np.std(bids[1:10, 1]) / np.mean(bids[1:10, 1])
            ask_concentration = np.std(asks[1:10, 1]) / np.mean(asks[1:10, 1])
            
            conditions['potential_spoofing'] = (
                (bid_concentration > 2 and bids[1][1] > 3 * bids[0][1]) or
                (ask_concentration > 2 and asks[1][1] > 3 * asks[0][1])
            )
        
        # Detect walls
        conditions['bid_wall'] = self._detect_wall(bids)
        conditions['ask_wall'] = self._detect_wall(asks)
        
        return {'market_conditions': conditions}
    
    def _detect_wall(self, orders: np.ndarray, threshold: float = 3.0) -> bool:
        """Detect order walls"""
        
        if len(orders) < 10:
            return False
        
        volumes = orders[:10, 1]
        mean_volume = np.mean(volumes)
        std_volume = np.std(volumes)
        
        return np.any(volumes > mean_volume + threshold * std_volume)
    
    def analyze_trade_flow(self, trades: List[Dict]) -> Dict:
        """Analyze trade flow patterns"""
        
        if not trades:
            return {}
        
        # Update trade flow history
        self.trade_flow.extend(trades)
        
        # Convert to arrays for analysis
        prices = np.array([t['price'] for t in trades])
        volumes = np.array([t['amount'] for t in trades])
        sides = np.array([1 if t['side'] == 'buy' else -1 for t in trades])
        
        # Basic statistics
        total_volume = volumes.sum()
        buy_volume = volumes[sides == 1].sum()
        sell_volume = volumes[sides == -1].sum()
        
        # VWAP
        vwap = np.sum(prices * volumes) / total_volume if total_volume > 0 else prices.mean()
        
        # Trade size distribution
        volume_percentiles = np.percentile(volumes, [25, 50, 75, 90, 95, 99])
        
        # Detect trade clusters
        trade_clusters = self._detect_trade_clusters(trades)
        
        # Kyle's lambda estimation
        price_changes = np.diff(prices)
        volume_imbalances = np.array([sides[i] * volumes[i] for i in range(1, len(trades))])
        
        if len(price_changes) > 10:
            kyle_lambda = np.polyfit(volume_imbalances, price_changes, 1)[0]
        else:
            kyle_lambda = 0
        
        return {
            'total_volume': total_volume,
            'buy_volume': buy_volume,
            'sell_volume': sell_volume,
            'buy_sell_ratio': buy_volume / sell_volume if sell_volume > 0 else float('inf'),
            'vwap': vwap,
            'avg_trade_size': volumes.mean(),
            'trade_size_std': volumes.std(),
            'large_trade_threshold': volume_percentiles[4],  # 95th percentile
            'whale_trade_threshold': volume_percentiles[5],  # 99th percentile
            'trade_clusters': trade_clusters,
            'kyle_lambda': kyle_lambda,
            'price_momentum': self._calculate_price_momentum(prices),
            'trade_intensity': len(trades) / ((trades[-1]['timestamp'] - trades[0]['timestamp']) / 1000) if len(trades) > 1 else 0
        }
    
    def _detect_trade_clusters(self, trades: List[Dict]) -> List[Dict]:
        """Detect clusters of similar trades (potential algorithmic trading)"""
        
        if len(trades) < 5:
            return []
        
        clusters = []
        current_cluster = [trades[0]]
        
        for i in range(1, len(trades)):
            time_diff = trades[i]['timestamp'] - trades[i-1]['timestamp']
            size_ratio = trades[i]['amount'] / trades[i-1]['amount']
            same_side = trades[i]['side'] == trades[i-1]['side']
            
            # Cluster criteria: rapid succession, similar size, same side
            if time_diff < 1000 and 0.8 < size_ratio < 1.2 and same_side:
                current_cluster.append(trades[i])
            else:
                if len(current_cluster) >= 3:
                    clusters.append({
                        'start_time': current_cluster[0]['timestamp'],
                        'end_time': current_cluster[-1]['timestamp'],
                        'trade_count': len(current_cluster),
                        'total_volume': sum(t['amount'] for t in current_cluster),
                        'avg_price': np.mean([t['price'] for t in current_cluster]),
                        'side': current_cluster[0]['side']
                    })
                current_cluster = [trades[i]]
        
        return clusters
    
    def _calculate_price_momentum(self, prices: np.ndarray) -> Dict:
        """Calculate various price momentum metrics"""
        
        if len(prices) < 2:
            return {'short_term': 0, 'medium_term': 0}
        
        # Simple momentum
        if len(prices) >= 10:
            short_term = (prices[-1] - prices[-5]) / prices[-5]
            medium_term = (prices[-1] - prices[-10]) / prices[-10]
        else:
            short_term = (prices[-1] - prices[0]) / prices[0]
            medium_term = short_term
        
        # Acceleration
        if len(prices) >= 3:
            velocity = np.diff(prices)
            acceleration = np.diff(velocity)
            avg_acceleration = np.mean(acceleration[-3:]) if len(acceleration) >= 3 else acceleration[-1]
        else:
            avg_acceleration = 0
        
        return {
            'short_term': short_term,
            'medium_term': medium_term,
            'acceleration': avg_acceleration,
            'trend_strength': abs(short_term) / (np.std(prices) / np.mean(prices)) if np.std(prices) > 0 else 0
        }