

# ===== analysis/sentiment_analysis.py =====
import aiohttp
import asyncio
from typing import Dict, List, Optional
from textblob import TextBlob
import re
from datetime import datetime, timedelta

class SentimentAnalyzer:
    """Multi-source sentiment analysis"""
    
    def __init__(self):
        self.session = None
        self.sentiment_cache = {}
        self.api_keys = {
            'twitter': os.environ.get('TWITTER_API_KEY'),
            'reddit': os.environ.get('REDDIT_API_KEY'),
            'news': os.environ.get('NEWS_API_KEY')
        }
    
    async def initialize(self):
        """Initialize async session"""
        if not self.session:
            self.session = aiohttp.ClientSession()
    
    async def get_comprehensive_sentiment(self, symbol: str) -> Dict:
        """Aggregate sentiment from multiple sources"""
        
        # Check cache
        cache_key = f"{symbol}_{datetime.now().strftime('%Y%m%d%H')}"
        if cache_key in self.sentiment_cache:
            return self.sentiment_cache[cache_key]
        
        tasks = [
            self._get_twitter_sentiment(symbol),
            self._get_reddit_sentiment(symbol),
            self._get_news_sentiment(symbol),
            self._get_technical_sentiment(symbol)
        ]
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Aggregate results
        sentiment_data = {
            'twitter': results[0] if not isinstance(results[0], Exception) else {'score': 0, 'volume': 0},
            'reddit': results[1] if not isinstance(results[1], Exception) else {'score': 0, 'volume': 0},
            'news': results[2] if not isinstance(results[2], Exception) else {'score': 0, 'volume': 0},
            'technical': results[3] if not isinstance(results[3], Exception) else {'score': 0}
        }
        
        # Calculate weighted average
        weights = {'twitter': 0.3, 'reddit': 0.2, 'news': 0.35, 'technical': 0.15}
        
        weighted_sentiment = sum(
            sentiment_data[source].get('score', 0) * weight 
            for source, weight in weights.items()
        )
        
        sentiment_data['aggregate'] = {
            'score': weighted_sentiment,
            'signal': self._score_to_signal(weighted_sentiment),
            'confidence': self._calculate_confidence(sentiment_data)
        }
        
        # Cache result
        self.sentiment_cache[cache_key] = sentiment_data
        
        return sentiment_data
    
    async def _get_twitter_sentiment(self, symbol: str) -> Dict:
        """Analyze Twitter sentiment"""
        
        # This would use Twitter API v2
        # For now, return simulated data
        tweets = await self._simulate_twitter_data(symbol)
        
        sentiments = []
        total_engagement = 0
        
        for tweet in tweets:
            # Clean and analyze text
            text = self._clean_text(tweet['text'])
            blob = TextBlob(text)
            
            # Weight by engagement
            engagement = tweet['likes'] + tweet['retweets'] * 2
            sentiments.append(blob.sentiment.polarity * engagement)
            total_engagement += engagement
        
        if total_engagement > 0:
            weighted_sentiment = sum(sentiments) / total_engagement
        else:
            weighted_sentiment = 0
        
        return {
            'score': weighted_sentiment,
            'volume': len(tweets),
            'engagement': total_engagement,
            'trending': self._is_trending(len(tweets), total_engagement)
        }
    
    async def _get_reddit_sentiment(self, symbol: str) -> Dict:
        """Analyze Reddit sentiment"""
        
        # This would use Reddit API
        # For now, return simulated data
        posts = await self._simulate_reddit_data(symbol)
        
        sentiments = []
        total_score = 0
        
        for post in posts:
            text = self._clean_text(post['title'] + ' ' + post['body'])
            blob = TextBlob(text)
            
            # Weight by upvotes
            weight = post['score']
            sentiments.append(blob.sentiment.polarity * weight)
            total_score += weight
        
        if total_score > 0:
            weighted_sentiment = sum(sentiments) / total_score
        else:
            weighted_sentiment = 0
        
        return {
            'score': weighted_sentiment,
            'volume': len(posts),
            'total_score': total_score,
            'avg_score': total_score / len(posts) if posts else 0
        }
    
    async def _get_news_sentiment(self, symbol: str) -> Dict:
        """Analyze news sentiment"""
        
        # This would use news APIs
        articles = await self._simulate_news_data(symbol)
        
        sentiments = []
        sources_quality = {
            'reuters': 1.0,
            'bloomberg': 1.0,
            'wsj': 0.9,
            'cnbc': 0.8,
            'yahoo': 0.7,
            'other': 0.5
        }
        
        total_weight = 0
        
        for article in articles:
            text = self._clean_text(article['title'] + ' ' + article['description'])
            blob = TextBlob(text)
            
            # Weight by source quality and recency
            source_weight = sources_quality.get(article['source'].lower(), 0.5)
            time_weight = self._calculate_time_weight(article['published'])
            weight = source_weight * time_weight
            
            sentiments.append(blob.sentiment.polarity * weight)
            total_weight += weight
        
        if total_weight > 0:
            weighted_sentiment = sum(sentiments) / total_weight
        else:
            weighted_sentiment = 0
        
        return {
            'score': weighted_sentiment,
            'volume': len(articles),
            'sources': len(set(a['source'] for a in articles)),
            'avg_quality': total_weight / len(articles) if articles else 0
        }
    
    async def _get_technical_sentiment(self, symbol: str) -> Dict:
        """Technical indicator based sentiment"""
        
        # This would analyze technical indicators
        # For now, return simulated data
        return {
            'score': np.random.uniform(-0.5, 0.5),
            'rsi_signal': 'neutral',
            'macd_signal': 'bullish',
            'volume_signal': 'neutral'
        }
    
    def _clean_text(self, text: str) -> str:
        """Clean text for sentiment analysis"""
        
        # Remove URLs
        text = re.sub(r'http\S+', '', text)
        
        # Remove mentions and hashtags
        text = re.sub(r'@\w+', '', text)
        text = re.sub(r'#\w+', '', text)
        
        # Remove special characters
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        
        # Remove extra whitespace
        text = ' '.join(text.split())
        
        return text.lower()
    
    def _score_to_signal(self, score: float) -> str:
        """Convert sentiment score to signal"""
        
        if score >= 0.5:
            return 'very_bullish'
        elif score >= 0.2:
            return 'bullish'
        elif score >= -0.2:
            return 'neutral'
        elif score >= -0.5:
            return 'bearish'
        else:
            return 'very_bearish'
    
    def _calculate_confidence(self, sentiment_data: Dict) -> float:
        """Calculate confidence in sentiment signal"""
        
        # Factors: volume, agreement between sources, data quality
        
        # Volume factor
        total_volume = sum(
            data.get('volume', 0) 
            for data in sentiment_data.values() 
            if isinstance(data, dict)
        )
        volume_factor = min(1.0, total_volume / 1000)
        
        # Agreement factor
        scores = [
            data.get('score', 0) 
            for data in sentiment_data.values() 
            if isinstance(data, dict) and 'score' in data
        ]
        
        if len(scores) > 1:
            agreement_factor = 1 - np.std(scores)
        else:
            agreement_factor = 0.5
        
        # Combine factors
        confidence = (volume_factor * 0.4 + agreement_factor * 0.6) * 100
        
        return min(100, max(0, confidence))
    
    def _calculate_time_weight(self, published_time: datetime) -> float:
        """Calculate weight based on recency"""
        
        age_hours = (datetime.now() - published_time).total_seconds() / 3600
        
        if age_hours < 1:
            return 1.0
        elif age_hours < 6:
            return 0.9
        elif age_hours < 24:
            return 0.7
        elif age_hours < 72:
            return 0.5
        else:
            return 0.3
    
    def _is_trending(self, volume: int, engagement: int) -> bool:
        """Determine if topic is trending"""
        
        # Thresholds for trending
        return volume > 100 and engagement > 10000
    
    async def _simulate_twitter_data(self, symbol: str) -> List[Dict]:
        """Simulate Twitter data for testing"""
        
        return [
            {
                'text': f"${symbol} is looking bullish! Great momentum today",
                'likes': np.random.randint(10, 1000),
                'retweets': np.random.randint(5, 500)
            }
            for _ in range(np.random.randint(20, 100))
        ]
    
    async def _simulate_reddit_data(self, symbol: str) -> List[Dict]:
        """Simulate Reddit data for testing"""
        
        return [
            {
                'title': f"DD on {symbol}",
                'body': "Detailed analysis...",
                'score': np.random.randint(1, 500)
            }
            for _ in range(np.random.randint(10, 50))
        ]
    
    async def _simulate_news_data(self, symbol: str) -> List[Dict]:
        """Simulate news data for testing"""
        
        sources = ['Reuters', 'Bloomberg', 'WSJ', 'CNBC', 'Yahoo']
        
        return [
            {
                'title': f"{symbol} Shows Strong Performance",
                'description': "Market analysis...",
                'source': np.random.choice(sources),
                'published': datetime.now() - timedelta(hours=np.random.randint(1, 48))
            }
            for _ in range(np.random.randint(5, 20))
        ]