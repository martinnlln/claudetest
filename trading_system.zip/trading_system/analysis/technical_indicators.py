
# ===== analysis/technical_indicators.py =====
import pandas as pd
import numpy as np
import talib
from typing import Dict, List, Optional

class AdvancedTechnicalAnalysis:
    """Comprehensive technical analysis with 100+ indicators"""
    
    @staticmethod
    def calculate_all_indicators(df: pd.DataFrame) -> pd.DataFrame:
        """Calculate all technical indicators"""
        
        df = df.copy()
        
        # Price Action
        df = AdvancedTechnicalAnalysis._calculate_price_action(df)
        
        # Moving Averages
        df = AdvancedTechnicalAnalysis._calculate_moving_averages(df)
        
        # Momentum Indicators
        df = AdvancedTechnicalAnalysis._calculate_momentum_indicators(df)
        
        # Volatility Indicators
        df = AdvancedTechnicalAnalysis._calculate_volatility_indicators(df)
        
        # Volume Indicators
        df = AdvancedTechnicalAnalysis._calculate_volume_indicators(df)
        
        # Pattern Recognition
        df = AdvancedTechnicalAnalysis._calculate_patterns(df)
        
        # Market Structure
        df = AdvancedTechnicalAnalysis._calculate_market_structure(df)
        
        # Custom Indicators
        df = AdvancedTechnicalAnalysis._calculate_custom_indicators(df)
        
        return df
    
    @staticmethod
    def _calculate_price_action(df: pd.DataFrame) -> pd.DataFrame:
        """Price action indicators"""
        
        # Candlestick metrics
        df['body_size'] = abs(df['close'] - df['open']) / df['open']
        df['upper_wick'] = (df['high'] - df[['close', 'open']].max(axis=1)) / df['close']
        df['lower_wick'] = (df[['close', 'open']].min(axis=1) - df['low']) / df['close']
        df['wick_ratio'] = df['upper_wick'] / (df['lower_wick'] + 1e-10)
        
        # Price changes
        for period in [1, 5, 10, 20]:
            df[f'return_{period}'] = df['close'].pct_change(period)
            df[f'log_return_{period}'] = np.log(df['close'] / df['close'].shift(period))
        
        # High/Low ratios
        df['hl_ratio'] = df['high'] / df['low']
        df['co_ratio'] = df['close'] / df['open']
        
        # Range metrics
        df['daily_range'] = (df['high'] - df['low']) / df['low']
        df['true_range'] = df[['high', 'close'].shift()].max(axis=1) - df[['low', 'close'].shift()].min(axis=1)
        
        return df
    
    @staticmethod
    def _calculate_moving_averages(df: pd.DataFrame) -> pd.DataFrame:
        """Various moving averages"""
        
        periods = [5, 10, 20, 50, 100, 200]
        
        # Simple Moving Averages
        for period in periods:
            df[f'sma_{period}'] = talib.SMA(df['close'], timeperiod=period)
            df[f'sma_volume_{period}'] = talib.SMA(df['volume'], timeperiod=period)
        
        # Exponential Moving Averages
        for period in periods[:4]:  # Shorter periods for EMA
            df[f'ema_{period}'] = talib.EMA(df['close'], timeperiod=period)
        
        # Weighted Moving Average
        df['wma_20'] = talib.WMA(df['close'], timeperiod=20)
        
        # Double Exponential Moving Average
        df['dema_20'] = talib.DEMA(df['close'], timeperiod=20)
        
        # Triple Exponential Moving Average
        df['tema_20'] = talib.TEMA(df['close'], timeperiod=20)
        
        # Triangular Moving Average
        df['trima_20'] = talib.TRIMA(df['close'], timeperiod=20)
        
        # Kaufman Adaptive Moving Average
        df['kama_20'] = talib.KAMA(df['close'], timeperiod=20)
        
        # MESA Adaptive Moving Average
        df['mama'], df['fama'] = talib.MAMA(df['close'])
        
        # Hilbert Transform - Instantaneous Trendline
        df['ht_trendline'] = talib.HT_TRENDLINE(df['close'])
        
        # Volume Weighted Moving Average
        df['vwma_20'] = (df['close'] * df['volume']).rolling(20).sum() / df['volume'].rolling(20).sum()
        
        return df
    
    @staticmethod
    def _calculate_momentum_indicators(df: pd.DataFrame) -> pd.DataFrame:
        """Momentum indicators"""
        
        # RSI variations
        for period in [7, 14, 21]:
            df[f'rsi_{period}'] = talib.RSI(df['close'], timeperiod=period)
        
        # Stochastic variations
        df['stoch_k'], df['stoch_d'] = talib.STOCH(df['high'], df['low'], df['close'])
        df['stoch_rsi_k'], df['stoch_rsi_d'] = talib.STOCHRSI(df['close'])
        df['stoch_fast_k'], df['stoch_fast_d'] = talib.STOCHF(df['high'], df['low'], df['close'])
        
        # MACD variations
        df['macd'], df['macd_signal'], df['macd_hist'] = talib.MACD(df['close'])
        df['macd_fast'], df['macd_slow'], df['macd_hist_fast'] = talib.MACD(df['close'], 
                                                                            fastperiod=6, 
                                                                            slowperiod=13, 
                                                                            signalperiod=5)
        
        # Other momentum indicators
        df['mom_10'] = talib.MOM(df['close'], timeperiod=10)
        df['roc_10'] = talib.ROC(df['close'], timeperiod=10)
        df['rocp_10'] = talib.ROCP(df['close'], timeperiod=10)
        df['rocr_10'] = talib.ROCR(df['close'], timeperiod=10)
        df['rocr100_10'] = talib.ROCR100(df['close'], timeperiod=10)
        
        # Commodity Channel Index
        for period in [14, 20]:
            df[f'cci_{period}'] = talib.CCI(df['high'], df['low'], df['close'], timeperiod=period)
        
        # Williams %R
        df['willr_14'] = talib.WILLR(df['high'], df['low'], df['close'], timeperiod=14)
        
        # Ultimate Oscillator
        df['ultosc'] = talib.ULTOSC(df['high'], df['low'], df['close'])
        
        # Aroon
        df['aroon_up'], df['aroon_down'] = talib.AROON(df['high'], df['low'])
        df['aroonosc'] = talib.AROONOSC(df['high'], df['low'])
        
        # Balance of Power
        df['bop'] = talib.BOP(df['open'], df['high'], df['low'], df['close'])
        
        # Directional Movement
        df['plus_di'] = talib.PLUS_DI(df['high'], df['low'], df['close'])
        df['minus_di'] = talib.MINUS_DI(df['high'], df['low'], df['close'])
        df['plus_dm'] = talib.PLUS_DM(df['high'], df['low'])
        df['minus_dm'] = talib.MINUS_DM(df['high'], df['low'])
        
        # PPO and APO
        df['ppo'] = talib.PPO(df['close'])
        df['apo'] = talib.APO(df['close'])
        
        # TRIX
        df['trix'] = talib.TRIX(df['close'])
        
        return df
    
    @staticmethod
    def _calculate_volatility_indicators(df: pd.DataFrame) -> pd.DataFrame:
        """Volatility indicators"""
        
        # ATR variations
        for period in [7, 14, 21]:
            df[f'atr_{period}'] = talib.ATR(df['high'], df['low'], df['close'], timeperiod=period)
            df[f'natr_{period}'] = talib.NATR(df['high'], df['low'], df['close'], timeperiod=period)
        
        # Bollinger Bands
        for period in [10, 20, 30]:
            upper, middle, lower = talib.BBANDS(df['close'], timeperiod=period)
            df[f'bb_upper_{period}'] = upper
            df[f'bb_middle_{period}'] = middle
            df[f'bb_lower_{period}'] = lower
            df[f'bb_width_{period}'] = upper - lower
            df[f'bb_percent_{period}'] = (df['close'] - lower) / (upper - lower)
        
        # Keltner Channels
        for period in [10, 20]:
            ma = talib.EMA(df['close'], timeperiod=period)
            atr = talib.ATR(df['high'], df['low'], df['close'], timeperiod=period)
            df[f'kc_upper_{period}'] = ma + 2 * atr
            df[f'kc_lower_{period}'] = ma - 2 * atr
            df[f'kc_percent_{period}'] = (df['close'] - df[f'kc_lower_{period}']) / \
                                        (df[f'kc_upper_{period}'] - df[f'kc_lower_{period}'])
        
        # Donchian Channels
        for period in [10, 20, 55]:
            df[f'dc_upper_{period}'] = df['high'].rolling(period).max()
            df[f'dc_lower_{period}'] = df['low'].rolling(period).min()
            df[f'dc_middle_{period}'] = (df[f'dc_upper_{period}'] + df[f'dc_lower_{period}']) / 2
        
        # Standard Deviation
        for period in [10, 20, 30]:
            df[f'stddev_{period}'] = talib.STDDEV(df['close'], timeperiod=period)
        
        # Historical Volatility
        for period in [10, 20, 30]:
            df[f'hv_{period}'] = df['log_return_1'].rolling(period).std() * np.sqrt(252)
        
        # Parkinson Volatility
        df['parkinson_vol'] = np.sqrt(252 / (4 * np.log(2))) * \
                             (np.log(df['high'] / df['low'])).rolling(20).mean()
        
        # Garman-Klass Volatility
        df['garman_klass_vol'] = np.sqrt(252 / 20 * ((0.5 * np.log(df['high'] / df['low'])**2) - 
                                                     (2 * np.log(2) - 1) * np.log(df['close'] / df['open'])**2).rolling(20).sum())
        
        return df
    
    @staticmethod
    def _calculate_volume_indicators(df: pd.DataFrame) -> pd.DataFrame:
        """Volume indicators"""
        
        # Basic volume metrics
        df['volume_sma_20'] = talib.SMA(df['volume'], timeperiod=20)
        df['volume_ratio'] = df['volume'] / df['volume_sma_20']
        
        # On Balance Volume
        df['obv'] = talib.OBV(df['close'], df['volume'])
        df['obv_sma_20'] = talib.SMA(df['obv'], timeperiod=20)
        
        # Accumulation/Distribution
        df['ad'] = talib.AD(df['high'], df['low'], df['close'], df['volume'])
        df['adosc'] = talib.ADOSC(df['high'], df['low'], df['close'], df['volume'])
        
        # Money Flow Index
        for period in [10, 14, 20]:
            df[f'mfi_{period}'] = talib.MFI(df['high'], df['low'], df['close'], df['volume'], timeperiod=period)
        
        # Chaikin Money Flow
        mfm = ((df['close'] - df['low']) - (df['high'] - df['close'])) / (df['high'] - df['low'])
        mfm = mfm.fillna(0)
        df['cmf'] = (mfm * df['volume']).rolling(20).sum() / df['volume'].rolling(20).sum()
        
        # Volume Price Trend
        df['vpt'] = ((df['close'] - df['close'].shift(1)) / df['close'].shift(1) * df['volume']).cumsum()
        
        # Ease of Movement
        distance_moved = (df['high'] + df['low']) / 2 - (df['high'].shift(1) + df['low'].shift(1)) / 2
        emv = distance_moved / (df['volume'] / 100000000) / (df['high'] - df['low'])
        df['emv'] = emv.rolling(14).mean()
        
        # Force Index
        df['force_index'] = df['close'].diff() * df['volume']
        df['force_index_ema'] = talib.EMA(df['force_index'], timeperiod=13)
        
        # Volume Weighted Average Price (VWAP)
        df['vwap'] = (df['volume'] * (df['high'] + df['low'] + df['close']) / 3).cumsum() / df['volume'].cumsum()
        df['price_to_vwap'] = df['close'] / df['vwap']
        
        # Volume Profile (simplified)
        for lookback in [20, 50]:
            df[f'volume_profile_{lookback}'] = df['volume'].rolling(lookback).apply(
                lambda x: np.percentile(x, 75) - np.percentile(x, 25)
            )
        
        return df
    
    @staticmethod
    def _calculate_patterns(df: pd.DataFrame) -> pd.DataFrame:
        """Candlestick pattern recognition"""
        
        # Two-line patterns
        patterns_2line = [
            'CDL2CROWS', 'CDL3BLACKCROWS', 'CDL3INSIDE', 'CDL3LINESTRIKE',
            'CDL3OUTSIDE', 'CDL3STARSINSOUTH', 'CDL3WHITESOLDIERS',
            'CDLABANDONEDBABY', 'CDLADVANCEBLOCK', 'CDLBELTHOLD',
            'CDLBREAKAWAY', 'CDLCLOSINGMARUBOZU', 'CDLCONCEALBABYSWALL',
            'CDLCOUNTERATTACK', 'CDLDARKCLOUDCOVER', 'CDLDOJI',
            'CDLDOJISTAR', 'CDLDRAGONFLYDOJI', 'CDLENGULFING',
            'CDLEVENINGDOJISTAR', 'CDLEVENINGSTAR', 'CDLGAPSIDESIDEWHITE',
            'CDLGRAVESTONEDOJI', 'CDLHAMMER', 'CDLHANGINGMAN',
            'CDLHARAMI', 'CDLHARAMICROSS', 'CDLHIGHWAVE',
            'CDLHIKKAKE', 'CDLHIKKAKEMOD', 'CDLHOMINGPIGEON',
            'CDLIDENTICAL3CROWS', 'CDLINNECK', 'CDLINVERTEDHAMMER',
            'CDLKICKING', 'CDLKICKINGBYLENGTH', 'CDLLADDERBOTTOM',
            'CDLLONGLEGGEDDOJI', 'CDLLONGLINE', 'CDLMARUBOZU',
            'CDLMATCHINGLOW', 'CDLMATHOLD', 'CDLMORNINGDOJISTAR',
            'CDLMORNINGSTAR', 'CDLONNECK', 'CDLPIERCING',
            'CDLRICKSHAWMAN', 'CDLRISEFALL3METHODS', 'CDLSEPARATINGLINES',
            'CDLSHOOTINGSTAR', 'CDLSHORTLINE', 'CDLSPINNINGTOP',
            'CDLSTALLEDPATTERN', 'CDLSTICKSANDWICH', 'CDLTAKURI',
            'CDLTASUKIGAP', 'CDLTHRUSTING', 'CDLTRISTAR',
            'CDLUNIQUE3RIVER', 'CDLUPSIDEGAP2CROWS', 'CDLXSIDEGAP3METHODS'
        ]
        
        for pattern in patterns_2line:
            try:
                func = getattr(talib, pattern)
                df[pattern.lower()] = func(df['open'], df['high'], df['low'], df['close'])
            except:
                continue
        
        # Aggregate pattern signals
        pattern_cols = [col for col in df.columns if col.startswith('cdl')]
        df['bullish_patterns'] = df[pattern_cols].apply(lambda x: (x > 0).sum(), axis=1)
        df['bearish_patterns'] = df[pattern_cols].apply(lambda x: (x < 0).sum(), axis=1)
        df['pattern_strength'] = df[pattern_cols].apply(lambda x: x.abs().sum(), axis=1)
        
        return df
    
    @staticmethod
    def _calculate_market_structure(df: pd.DataFrame) -> pd.DataFrame:
        """Market structure indicators"""
        
        # Pivot Points
        df['pivot'] = (df['high'] + df['low'] + df['close']) / 3
        df['r1'] = 2 * df['pivot'] - df['low']
        df['s1'] = 2 * df['pivot'] - df['high']
        df['r2'] = df['pivot'] + (df['high'] - df['low'])
        df['s2'] = df['pivot'] - (df['high'] - df['low'])
        df['r3'] = df['high'] + 2 * (df['pivot'] - df['low'])
        df['s3'] = df['low'] - 2 * (df['high'] - df['pivot'])
        
        # Fibonacci Retracements (simplified)
        for lookback in [20, 50, 100]:
            high = df['high'].rolling(lookback).max()
            low = df['low'].rolling(lookback).min()
            diff = high - low
            
            df[f'fib_0_{lookback}'] = high
            df[f'fib_236_{lookback}'] = high - 0.236 * diff
            df[f'fib_382_{lookback}'] = high - 0.382 * diff
            df[f'fib_500_{lookback}'] = high - 0.500 * diff
            df[f'fib_618_{lookback}'] = high - 0.618 * diff
            df[f'fib_100_{lookback}'] = low
        
        # Market Profile Value Areas (simplified)
        for lookback in [20, 50]:
            df[f'poc_{lookback}'] = df['close'].rolling(lookback).apply(
                lambda x: pd.Series(x).mode()[0] if len(pd.Series(x).mode()) > 0 else x.mean()
            )
            df[f'vah_{lookback}'] = df['high'].rolling(lookback).quantile(0.7)
            df[f'val_{lookback}'] = df['low'].rolling(lookback).quantile(0.3)
        
        # Support and Resistance Levels
        for lookback in [20, 50, 100]:
            df[f'resistance_{lookback}'] = df['high'].rolling(lookback).max()
            df[f'support_{lookback}'] = df['low'].rolling(lookback).min()
            df[f'sr_range_{lookback}'] = df[f'resistance_{lookback}'] - df[f'support_{lookback}']
        
        # Trend Detection
        df['trend_sma'] = np.where(df['sma_20'] > df['sma_50'], 1, -1)
        df['trend_ema'] = np.where(df['ema_10'] > df['ema_20'], 1, -1)
        
        # Higher Highs and Lower Lows
        df['higher_high'] = (df['high'] > df['high'].shift(1)).astype(int)
        df['lower_low'] = (df['low'] < df['low'].shift(1)).astype(int)
        df['higher_low'] = (df['low'] > df['low'].shift(1)).astype(int)
        df['lower_high'] = (df['high'] < df['high'].shift(1)).astype(int)
        
        # Swing Points
        df['swing_high'] = ((df['high'] > df['high'].shift(1)) & 
                           (df['high'] > df['high'].shift(-1))).astype(int)
        df['swing_low'] = ((df['low'] < df['low'].shift(1)) & 
                          (df['low'] < df['low'].shift(-1))).astype(int)
        
        return df
    
    @staticmethod
    def _calculate_custom_indicators(df: pd.DataFrame) -> pd.DataFrame:
        """Custom proprietary indicators"""
        
        # Momentum Quality Index
        momentum = df['close'].pct_change(10)
        volatility = df['close'].pct_change().rolling(10).std()
        df['momentum_quality'] = momentum / (volatility + 1e-10)
        
        # Volume-Adjusted Momentum
        df['volume_momentum'] = momentum * (df['volume'] / df['volume_sma_20'])
        
        # Trend Strength Index
        ema_diff = df['ema_10'] - df['ema_20']
        df['trend_strength'] = ema_diff / df['atr_14'] * 100
        
        # Market Efficiency Ratio
        direction = abs(df['close'] - df['close'].shift(20))
        volatility = df['true_range'].rolling(20).sum()
        df['efficiency_ratio'] = direction / (volatility + 1e-10)
        
        # Composite Momentum Score
        df['composite_momentum'] = (
            df['rsi_14'] / 100 * 0.25 +
            (df['macd'] / df['close'] * 100).clip(-1, 1) * 0.25 +
            df['momentum_quality'].clip(-1, 1) * 0.25 +
            ((df['close'] - df['sma_20']) / df['sma_20']).clip(-0.1, 0.1) * 10 * 0.25
        )
        
        # Volatility-Adjusted Returns
        for period in [5, 10, 20]:
            returns = df['close'].pct_change(period)
            vol = df['close'].pct_change().rolling(period).std()
            df[f'sharpe_{period}'] = returns / (vol + 1e-10) * np.sqrt(252 / period)
        
        # Order Flow Imbalance (using volume as proxy)
        df['buy_volume'] = df['volume'] * (df['close'] > df['open']).astype(int)
        df['sell_volume'] = df['volume'] * (df['close'] <= df['open']).astype(int)
        df['order_flow_imbalance'] = (df['buy_volume'] - df['sell_volume']) / df['volume']
        
        # Price Density
        for lookback in [20, 50]:
            df[f'price_density_{lookback}'] = df['close'].rolling(lookback).apply(
                lambda x: len(np.unique(np.round(x, 2))) / len(x)
            )
        
        # Microstructure Noise
        df['microstructure_noise'] = (df['high'] - df['low']) / df['close'] - \
                                     2 * np.sqrt(2 / np.pi) * df['close'].pct_change().abs()
        
        return df