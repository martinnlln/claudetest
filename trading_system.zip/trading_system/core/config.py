
# ===== core/config.py =====
import os
from dataclasses import dataclass
from typing import Dict, List, Optional
import yaml

@dataclass
class ModelConfig:
    ensemble_size: int = 20
    lookback_window: int = 100
    prediction_horizons: List[int] = None
    confidence_threshold: float = 0.85
    use_gpu: bool = True
    model_types: List[str] = None
    
    def __post_init__(self):
        if self.prediction_horizons is None:
            self.prediction_horizons = [1, 5, 15, 30, 60]
        if self.model_types is None:
            self.model_types = ['transformer', 'lstm_attention', 'temporal_fusion', 
                               'wavenet', 'xgboost', 'lightgbm', 'catboost']

@dataclass
class TradingConfig:
    max_position_size: float = 0.1
    max_drawdown: float = 0.15
    risk_per_trade: float = 0.02
    use_kelly_criterion: bool = True
    stop_loss_atr_multiplier: float = 2.0
    take_profit_ratios: List[float] = None
    
    def __post_init__(self):
        if self.take_profit_ratios is None:
            self.take_profit_ratios = [1.5, 2.0, 3.0]

@dataclass
class SystemConfig:
    model_config: ModelConfig
    trading_config: TradingConfig
    data_sources: List[str]
    update_frequency: int = 5
    save_predictions: bool = True
    enable_backtesting: bool = True

def load_config(config_path: str = "config.yaml") -> SystemConfig:
    if os.path.exists(config_path):
        with open(config_path, 'r') as f:
            config_dict = yaml.safe_load(f)
        # Parse config
        return SystemConfig(
            model_config=ModelConfig(**config_dict.get('models', {})),
            trading_config=TradingConfig(**config_dict.get('trading', {})),
            data_sources=config_dict.get('data_sources', ['binance', 'coinbase'])
        )
    return SystemConfig(
        model_config=ModelConfig(),
        trading_config=TradingConfig(),
        data_sources=['binance']
    )