
# ===== core/exceptions.py =====
class TradingSystemError(Exception):
    """Base exception for trading system"""
    pass

class DataFetchError(TradingSystemError):
    """Error fetching market data"""
    pass

class ModelPredictionError(TradingSystemError):
    """Error in model prediction"""
    pass

class RiskManagementError(TradingSystemError):
    """Risk management violation"""
    pass