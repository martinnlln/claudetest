
# ===== app.py =====
from flask import Flask, render_template
from flask_socketio import SocketIO
from flask_cors import CORS
import asyncio
import logging
from datetime import datetime
import os

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'quantum-trading-secret-2024')
CORS(app)

# Initialize SocketIO
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# Load configuration
config = load_config()

# Initialize components
logger.info("Initializing trading system components...")

# Data providers
binance_provider = BinanceProvider()
data_aggregator = DataAggregator([binance_provider])

# Initialize models and analysis
prediction_engine = UltraAdvancedPredictionEngine()
microstructure_analyzer = MarketMicrostructureAnalyzer()
sentiment_analyzer = SentimentAnalyzer()
technical_analyzer = AdvancedTechnicalAnalysis()

# Trading components
signal_generator = AdvancedSignalGenerator(config.trading_config)
risk_manager = AdvancedRiskManager(config.trading_config)

# API components
websocket_server = WebSocketServer(
    socketio, 
    data_aggregator, 
    prediction_engine,
    signal_generator,
    risk_manager
)

rest_api = RestAPI(
    app,
    data_aggregator,
    prediction_engine,
    signal_generator,
    risk_manager
)

@app.route('/')
def index():
    """Serve the main application"""
    return render_template('index.html')

@app.route('/health')
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'components': {
            'data_aggregator': 'active',
            'prediction_engine': 'active',
            'risk_manager': 'active',
            'websocket_server': 'active'
        }
    })

async def initialize_system():
    """Initialize async components"""
    
    logger.info("Initializing async components...")
    
    # Initialize sentiment analyzer
    await sentiment_analyzer.initialize()
    
    # Load initial model weights if available
    model_path = "models/saved_models"
    if os.path.exists(model_path):
        logger.info("Loading saved models...")
        # Load models
    
    logger.info("System initialization complete")

def run_server():
    """Run the application server"""
    
    # Initialize async components
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(initialize_system())
    
    # Run Flask-SocketIO server
    logger.info("Starting Quantum Trading System server...")
    socketio.run(
        app,
        host='0.0.0.0',
        port=int(os.environ.get('PORT', 5000)),
        debug=False,
        use_reloader=False
    )

if __name__ == '__main__':
    run_server()