
# ===== trading/risk_manager.py =====
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta

@dataclass
class RiskMetrics:
    portfolio_var: float  # Value at Risk
    portfolio_cvar: float  # Conditional Value at Risk
    sharpe_ratio: float
    sortino_ratio: float
    max_drawdown: float
    current_drawdown: float
    beta: float
    correlation_risk: float
    concentration_risk: float
    liquidity_risk: float

class AdvancedRiskManager:
    """Comprehensive risk management system"""
    
    def __init__(self, config: TradingConfig):
        self.config = config
        self.positions = {}
        self.trade_history = []
        self.equity_curve = [10000]  # Starting capital
        self.risk_limits = {
            'max_portfolio_risk': 0.06,  # 6% max portfolio risk
            'max_position_risk': 0.02,   # 2% max per position
            'max_correlation': 0.7,      # Max correlation between positions
            'max_drawdown': config.max_drawdown,
            'max_daily_loss': 0.05,      # 5% max daily loss
            'max_positions': 10
        }
        
    def evaluate_signal(self, 
                       signal: TradingSignal,
                       current_portfolio_value: float) -> Tuple[bool, List[str]]:
        """Evaluate if signal passes risk checks"""
        
        checks_passed = []
        checks_failed = []
        
        # Check 1: Portfolio risk limit
        portfolio_risk = self._calculate_portfolio_risk(signal)
        if portfolio_risk <= self.risk_limits['max_portfolio_risk']:
            checks_passed.append("Portfolio risk within limits")
        else:
            checks_failed.append(f"Portfolio risk too high: {portfolio_risk:.2%}")
        
        # Check 2: Position risk limit
        position_risk = self._calculate_position_risk(signal, current_portfolio_value)
        if position_risk <= self.risk_limits['max_position_risk']:
            checks_passed.append("Position risk acceptable")
        else:
            checks_failed.append(f"Position risk too high: {position_risk:.2%}")
        
        # Check 3: Correlation risk
        correlation_risk = self._calculate_correlation_risk(signal)
        if correlation_risk <= self.risk_limits['max_correlation']:
            checks_passed.append("Correlation risk acceptable")
        else:
            checks_failed.append(f"High correlation with existing positions: {correlation_risk:.2f}")
        
        # Check 4: Drawdown limit
        if self._check_drawdown_limit():
            checks_passed.append("Within drawdown limits")
        else:
            current_dd = self._calculate_current_drawdown()
            checks_failed.append(f"Exceeds max drawdown: {current_dd:.2%}")
        
        # Check 5: Daily loss limit
        if self._check_daily_loss_limit():
            checks_passed.append("Within daily loss limits")
        else:
            daily_loss = self._calculate_daily_loss()
            checks_failed.append(f"Exceeds daily loss limit: {daily_loss:.2%}")
        
        # Check 6: Position limit
        if len(self.positions) < self.risk_limits['max_positions']:
            checks_passed.append("Position count within limits")
        else:
            checks_failed.append("Maximum position count reached")
        
        # Check 7: Liquidity risk
        liquidity_score = self._assess_liquidity_risk(signal)
        if liquidity_score < 0.7:
            checks_passed.append("Adequate liquidity")
        else:
            checks_failed.append(f"High liquidity risk: {liquidity_score:.2f}")
        
        # Final decision
        approved = len(checks_failed) == 0
        
        return approved, checks_failed if not approved else checks_passed
    
    def calculate_position_size_with_risk(self,
                                        signal: TradingSignal,
                                        portfolio_value: float) -> float:
        """Calculate position size considering all risk factors"""
        
        # Start with signal's suggested size
        base_size = signal.position_size
        
        # Apply risk-based adjustments
        
        # 1. Kelly Criterion with safety margin
        kelly_size = self._calculate_kelly_size(signal, portfolio_value)
        base_size = min(base_size, kelly_size * 0.25)  # Use 25% of Kelly
        
        # 2. Volatility adjustment
        vol_adjustment = self._calculate_volatility_adjustment(signal)
        base_size *= vol_adjustment
        
        # 3. Correlation adjustment
        correlation_penalty = 1 - self._calculate_correlation_risk(signal)
        base_size *= correlation_penalty
        
        # 4. Drawdown adjustment
        dd_adjustment = self._calculate_drawdown_adjustment()
        base_size *= dd_adjustment
        
        # 5. Maximum position size check
        max_size = portfolio_value * self.risk_limits['max_position_risk'] / \
                  abs(signal.entry_price - signal.stop_loss) * signal.entry_price
        
        final_size = min(base_size, max_size)
        
        # 6. Minimum size check (avoid tiny positions)
        min_size = portfolio_value * 0.001  # 0.1% minimum
        if final_size < min_size:
            final_size = 0
        
        return final_size
    
    def update_position(self, symbol: str, position: Dict):
        """Update position tracking"""
        
        self.positions[symbol] = position
        
        # Update trade history
        self.trade_history.append({
            'timestamp': datetime.now(),
            'symbol': symbol,
            'action': position.get('action'),
            'price': position.get('entry_price'),
            'size': position.get('size'),
            'stop_loss': position.get('stop_loss'),
            'take_profit': position.get('take_profit')
        })
    
    def calculate_portfolio_metrics(self, current_prices: Dict) -> RiskMetrics:
        """Calculate comprehensive portfolio risk metrics"""
        
        # Portfolio value
        portfolio_value = self._calculate_portfolio_value(current_prices)
        self.equity_curve.append(portfolio_value)
        
        # Returns
        returns = pd.Series(self.equity_curve).pct_change().dropna()
        
        # VaR and CVaR
        var_95 = self._calculate_var(returns, 0.95)
        cvar_95 = self._calculate_cvar(returns, 0.95)
        
        # Sharpe and Sortino ratios
        sharpe = self._calculate_sharpe_ratio(returns)
        sortino = self._calculate_sortino_ratio(returns)
        
        # Drawdown
        max_dd = self._calculate_max_drawdown()
        current_dd = self._calculate_current_drawdown()
        
        # Beta (against Bitcoin as benchmark)
        beta = self._calculate_portfolio_beta(returns)
        
        # Risk concentrations
        correlation_risk = np.mean([self._calculate_correlation_risk(None)])
        concentration_risk = self._calculate_concentration_risk()
        liquidity_risk = self._calculate_portfolio_liquidity_risk()
        
        return RiskMetrics(
            portfolio_var=var_95,
            portfolio_cvar=cvar_95,
            sharpe_ratio=sharpe,
            sortino_ratio=sortino,
            max_drawdown=max_dd,
            current_drawdown=current_dd,
            beta=beta,
            correlation_risk=correlation_risk,
            concentration_risk=concentration_risk,
            liquidity_risk=liquidity_risk
        )
    
    def generate_risk_report(self) -> Dict:
        """Generate comprehensive risk report"""
        
        current_prices = {symbol: pos['current_price'] 
                         for symbol, pos in self.positions.items()}
        
        metrics = self.calculate_portfolio_metrics(current_prices)
        
        report = {
            'timestamp': datetime.now().isoformat(),
            'portfolio_metrics': {
                'value_at_risk_95': f"{metrics.portfolio_var:.2%}",
                'conditional_var_95': f"{metrics.portfolio_cvar:.2%}",
                'sharpe_ratio': f"{metrics.sharpe_ratio:.2f}",
                'sortino_ratio': f"{metrics.sortino_ratio:.2f}",
                'max_drawdown': f"{metrics.max_drawdown:.2%}",
                'current_drawdown': f"{metrics.current_drawdown:.2%}",
                'portfolio_beta': f"{metrics.beta:.2f}"
            },
            'risk_exposures': {
                'correlation_risk': f"{metrics.correlation_risk:.2%}",
                'concentration_risk': f"{metrics.concentration_risk:.2%}",
                'liquidity_risk': f"{metrics.liquidity_risk:.2%}"
            },
            'position_analysis': self._analyze_positions(),
            'risk_limits_usage': self._calculate_risk_limits_usage(),
            'recommendations': self._generate_risk_recommendations(metrics)
        }
        
        return report
    
    def _calculate_portfolio_risk(self, new_signal: Optional[TradingSignal] = None) -> float:
        """Calculate total portfolio risk including new position"""
        
        total_risk = 0
        
        # Existing positions risk
        for symbol, position in self.positions.items():
            position_value = position['size'] * position['current_price']
            stop_loss_distance = abs(position['current_price'] - position['stop_loss'])
            position_risk = (stop_loss_distance / position['current_price']) * \
                          (position_value / self.equity_curve[-1])
            total_risk += position_risk
        
        # New position risk
        if new_signal:
            new_position_value = new_signal.position_size * new_signal.entry_price
            stop_loss_distance = abs(new_signal.entry_price - new_signal.stop_loss)
            new_risk = (stop_loss_distance / new_signal.entry_price) * \
                      (new_position_value / self.equity_curve[-1])
            total_risk += new_risk
        
        return total_risk
    
    def _calculate_position_risk(self, signal: TradingSignal, portfolio_value: float) -> float:
        """Calculate risk for a single position"""
        
        position_value = signal.position_size * signal.entry_price
        stop_loss_distance = abs(signal.entry_price - signal.stop_loss)
        
        risk_amount = (stop_loss_distance / signal.entry_price) * position_value
        risk_percentage = risk_amount / portfolio_value
        
        return risk_percentage
    
    def _calculate_correlation_risk(self, new_signal: Optional[TradingSignal]) -> float:
        """Calculate correlation risk with existing positions"""
        
        if len(self.positions) == 0:
            return 0
        
        # Simplified correlation estimation based on recent price movements
        # In production, use actual correlation matrices
        
        correlations = []
        
        for symbol, position in self.positions.items():
            # Estimate correlation (placeholder - use real data)
            if new_signal and hasattr(new_signal, 'metadata'):
                # Same asset class tends to be correlated
                correlation = 0.7 if symbol.split('/')[1] == 'USDT' else 0.3
            else:
                correlation = 0.5
            
            correlations.append(correlation)
        
        return np.mean(correlations) if correlations else 0
    
    def _check_drawdown_limit(self) -> bool:
        """Check if within drawdown limits"""
        
        current_dd = self._calculate_current_drawdown()
        return current_dd < self.risk_limits['max_drawdown']
    
    def _calculate_current_drawdown(self) -> float:
        """Calculate current drawdown from peak"""
        
        if len(self.equity_curve) < 2:
            return 0
        
        peak = max(self.equity_curve)
        current = self.equity_curve[-1]
        
        return (peak - current) / peak if peak > 0 else 0
    
    def _calculate_max_drawdown(self) -> float:
        """Calculate maximum drawdown"""
        
        if len(self.equity_curve) < 2:
            return 0
        
        equity_series = pd.Series(self.equity_curve)
        cumulative_returns = (1 + equity_series.pct_change()).cumprod()
        running_max = cumulative_returns.expanding().max()
        drawdowns = (cumulative_returns - running_max) / running_max
        
        return abs(drawdowns.min())
    
    def _check_daily_loss_limit(self) -> bool:
        """Check if within daily loss limits"""
        
        daily_loss = self._calculate_daily_loss()
        return daily_loss < self.risk_limits['max_daily_loss']
    
    def _calculate_daily_loss(self) -> float:
        """Calculate today's loss"""
        
        if len(self.equity_curve) < 2:
            return 0
        
        # Get today's starting value (simplified - use actual timestamps)
        today_start = self.equity_curve[-min(len(self.equity_curve), 100)]
        current = self.equity_curve[-1]
        
        return max(0, (today_start - current) / today_start)
    
    def _assess_liquidity_risk(self, signal: TradingSignal) -> float:
        """Assess liquidity risk for position"""
        
        # Factors to consider:
        # 1. Position size relative to average volume
        # 2. Spread
        # 3. Market depth
        
        liquidity_score = 0
        
        if hasattr(signal, 'metadata'):
            # Check spread
            if 'spread_bps' in signal.metadata:
                spread = signal.metadata['spread_bps']
                if spread > 20:
                    liquidity_score += 0.3
                elif spread > 10:
                    liquidity_score += 0.1
            
            # Check market conditions
            if 'market_conditions' in signal.metadata:
                conditions = signal.metadata['market_conditions']
                if conditions.get('thin_market'):
                    liquidity_score += 0.4
                if conditions.get('one_sided_market'):
                    liquidity_score += 0.2
        
        return min(liquidity_score, 1.0)
    
    def _calculate_kelly_size(self, signal: TradingSignal, portfolio_value: float) -> float:
        """Calculate Kelly Criterion position size"""
        
        # Estimate win probability from signal confidence
        win_prob = signal.confidence / 100
        
        # Calculate win/loss ratios
        if signal.take_profit_levels:
            avg_win = abs(signal.take_profit_levels[0] - signal.entry_price) / signal.entry_price
        else:
            avg_win = 0.02  # Default 2%
        
        avg_loss = abs(signal.stop_loss - signal.entry_price) / signal.entry_price
        
        # Kelly formula: f = p - q/b
        # where p = win probability, q = loss probability, b = win/loss ratio
        if avg_loss > 0:
            b = avg_win / avg_loss
            q = 1 - win_prob
            kelly_fraction = win_prob - q / b
            
            # Apply safety margin and caps
            kelly_fraction = max(0, min(0.25, kelly_fraction))
            
            return portfolio_value * kelly_fraction
        
        return 0
    
    def _calculate_volatility_adjustment(self, signal: TradingSignal) -> float:
        """Adjust size based on volatility"""
        
        if hasattr(signal, 'metadata') and 'volatility_regime' in signal.metadata:
            regime = signal.metadata['volatility_regime']
            
            adjustments = {
                'extreme_low': 1.2,
                'low': 1.1,
                'normal': 1.0,
                'high': 0.8,
                'extreme_high': 0.6
            }
            
            return adjustments.get(regime, 1.0)
        
        return 1.0
    
    def _calculate_drawdown_adjustment(self) -> float:
        """Reduce size during drawdowns"""
        
        current_dd = self._calculate_current_drawdown()
        
        if current_dd < 0.05:
            return 1.0
        elif current_dd < 0.10:
            return 0.8
        elif current_dd < 0.15:
            return 0.6
        else:
            return 0.4
    
    def _calculate_portfolio_value(self, current_prices: Dict) -> float:
        """Calculate total portfolio value"""
        
        cash = self.equity_curve[-1]  # Simplified - track cash separately
        
        for symbol, position in self.positions.items():
            if symbol in current_prices:
                position_value = position['size'] * current_prices[symbol]
                cash += position_value
        
        return cash
    
    def _calculate_var(self, returns: pd.Series, confidence: float) -> float:
        """Calculate Value at Risk"""
        
        if len(returns) < 20:
            return 0
        
        return np.percentile(returns, (1 - confidence) * 100)
    
    def _calculate_cvar(self, returns: pd.Series, confidence: float) -> float:
        """Calculate Conditional Value at Risk"""
        
        var = self._calculate_var(returns, confidence)
        return returns[returns <= var].mean()
    
    def _calculate_sharpe_ratio(self, returns: pd.Series) -> float:
        """Calculate Sharpe ratio"""
        
        if len(returns) < 20:
            return 0
        
        # Assume risk-free rate of 2% annually
        risk_free_rate = 0.02 / 252  # Daily
        
        excess_returns = returns - risk_free_rate
        
        if excess_returns.std() > 0:
            return np.sqrt(252) * excess_returns.mean() / excess_returns.std()
        
        return 0
    
    def _calculate_sortino_ratio(self, returns: pd.Series) -> float:
        """Calculate Sortino ratio"""
        
        if len(returns) < 20:
            return 0
        
        risk_free_rate = 0.02 / 252
        excess_returns = returns - risk_free_rate
        
        downside_returns = excess_returns[excess_returns < 0]
        
        if len(downside_returns) > 0 and downside_returns.std() > 0:
            return np.sqrt(252) * excess_returns.mean() / downside_returns.std()
        
        return 0
    
    def _calculate_portfolio_beta(self, returns: pd.Series) -> float:
        """Calculate portfolio beta against benchmark"""
        
        # Simplified - in production, use actual benchmark returns
        # Assume market returns with correlation
        market_returns = returns * np.random.uniform(0.7, 1.3, len(returns))
        
        if len(returns) > 20:
            covariance = np.cov(returns, market_returns)[0, 1]
            market_variance = np.var(market_returns)
            
            if market_variance > 0:
                return covariance / market_variance
        
        return 1.0
    
    def _calculate_concentration_risk(self) -> float:
        """Calculate position concentration risk"""
        
        if not self.positions:
            return 0
        
        position_values = []
        total_value = self.equity_curve[-1]
        
        for position in self.positions.values():
            value = position['size'] * position['current_price']
            position_values.append(value / total_value)
        
        # Herfindahl index
        return sum(p ** 2 for p in position_values)
    
    def _calculate_portfolio_liquidity_risk(self) -> float:
        """Calculate overall portfolio liquidity risk"""
        
        if not self.positions:
            return 0
        
        liquidity_scores = []
        
        for position in self.positions.values():
            # Simplified liquidity scoring
            score = 0
            
            if 'avg_volume' in position:
                size_to_volume = position['size'] / position['avg_volume']
                if size_to_volume > 0.1:
                    score += 0.5
                elif size_to_volume > 0.05:
                    score += 0.3
            
            liquidity_scores.append(score)
        
        return np.mean(liquidity_scores) if liquidity_scores else 0
    
    def _analyze_positions(self) -> List[Dict]:
        """Analyze individual positions"""
        
        analysis = []
        
        for symbol, position in self.positions.items():
            pnl = (position['current_price'] - position['entry_price']) / position['entry_price']
            
            analysis.append({
                'symbol': symbol,
                'size': position['size'],
                'entry_price': position['entry_price'],
                'current_price': position['current_price'],
                'pnl_percent': f"{pnl:.2%}",
                'risk_reward': position.get('risk_reward_ratio', 0),
                'time_held': str(datetime.now() - position.get('entry_time', datetime.now()))
            })
        
        return analysis
    
    def _calculate_risk_limits_usage(self) -> Dict:
        """Calculate current usage of risk limits"""
        
        return {
            'portfolio_risk': f"{self._calculate_portfolio_risk() / self.risk_limits['max_portfolio_risk']:.1%}",
            'drawdown': f"{self._calculate_current_drawdown() / self.risk_limits['max_drawdown']:.1%}",
            'daily_loss': f"{self._calculate_daily_loss() / self.risk_limits['max_daily_loss']:.1%}",
            'position_count': f"{len(self.positions)} / {self.risk_limits['max_positions']}"
        }
    
    def _generate_risk_recommendations(self, metrics: RiskMetrics) -> List[str]:
        """Generate risk management recommendations"""
        
        recommendations = []
        
        # Drawdown recommendations
        if metrics.current_drawdown > 0.1:
            recommendations.append("Consider reducing position sizes due to significant drawdown")
        
        # Concentration recommendations
        if metrics.concentration_risk > 0.3:
            recommendations.append("Diversify portfolio - high concentration risk detected")
        
        # Correlation recommendations
        if metrics.correlation_risk > 0.7:
            recommendations.append("Reduce correlated positions to lower systematic risk")
        
        # Sharpe ratio recommendations
        if metrics.sharpe_ratio < 0.5:
            recommendations.append("Poor risk-adjusted returns - review strategy")
        
        # Liquidity recommendations
        if metrics.liquidity_risk > 0.5:
            recommendations.append("High liquidity risk - consider reducing position sizes")
        
        return recommendations