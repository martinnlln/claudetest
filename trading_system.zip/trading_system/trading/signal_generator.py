
# ===== trading/signal_generator.py =====
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from enum import Enum

class SignalType(Enum):
    STRONG_BUY = "STRONG_BUY"
    BUY = "BUY"
    HOLD = "HOLD"
    SELL = "SELL"
    STRONG_SELL = "STRONG_SELL"

@dataclass
class TradingSignal:
    signal_type: SignalType
    confidence: float
    entry_price: float
    stop_loss: float
    take_profit_levels: List[float]
    position_size: float
    risk_reward_ratio: float
    expected_return: float
    time_horizon: str
    reasons: List[str]
    risk_factors: List[str]
    metadata: Dict

class AdvancedSignalGenerator:
    """Generate high-probability trading signals"""
    
    def __init__(self, config: TradingConfig):
        self.config = config
        self.signal_history = []
        self.performance_tracker = {}
        
    def generate_signal(self, 
                       market_data: pd.DataFrame,
                       predictions: Dict,
                       microstructure: Dict,
                       sentiment: Dict) -> TradingSignal:
        """Generate comprehensive trading signal"""
        
        # Extract current market state
        current_price = market_data['close'].iloc[-1]
        
        # Calculate signal components
        technical_score = self._calculate_technical_score(market_data)
        prediction_score = self._calculate_prediction_score(predictions, current_price)
        microstructure_score = self._calculate_microstructure_score(microstructure)
        sentiment_score = self._calculate_sentiment_score(sentiment)
        
        # Weight and combine scores
        weights = {
            'technical': 0.25,
            'prediction': 0.35,
            'microstructure': 0.25,
            'sentiment': 0.15
        }
        
        composite_score = (
            technical_score * weights['technical'] +
            prediction_score * weights['prediction'] +
            microstructure_score * weights['microstructure'] +
            sentiment_score * weights['sentiment']
        )
        
        # Determine signal type
        signal_type = self._score_to_signal_type(composite_score)
        
        # Calculate trading parameters
        trading_params = self._calculate_trading_parameters(
            signal_type, current_price, market_data, predictions
        )
        
        # Generate reasons and risk factors
        reasons = self._generate_signal_reasons(
            technical_score, prediction_score, microstructure_score, sentiment_score
        )
        
        risk_factors = self._identify_risk_factors(
            market_data, microstructure, sentiment
        )
        
        # Create signal
        signal = TradingSignal(
            signal_type=signal_type,
            confidence=self._calculate_confidence(composite_score, predictions),
            entry_price=trading_params['entry_price'],
            stop_loss=trading_params['stop_loss'],
            take_profit_levels=trading_params['take_profit_levels'],
            position_size=trading_params['position_size'],
            risk_reward_ratio=trading_params['risk_reward_ratio'],
            expected_return=trading_params['expected_return'],
            time_horizon=self._determine_time_horizon(signal_type, market_data),
            reasons=reasons,
            risk_factors=risk_factors,
            metadata={
                'composite_score': composite_score,
                'component_scores': {
                    'technical': technical_score,
                    'prediction': prediction_score,
                    'microstructure': microstructure_score,
                    'sentiment': sentiment_score
                },
                'market_regime': self._detect_market_regime(market_data),
                'volatility_regime': self._detect_volatility_regime(market_data)
            }
        )
        
        # Track signal
        self.signal_history.append(signal)
        
        return signal
    
    def _calculate_technical_score(self, market_data: pd.DataFrame) -> float:
        """Calculate score from technical indicators"""
        
        scores = []
        weights = []
        
        # Trend following
        if 'ema_20' in market_data and 'ema_50' in market_data:
            ema_score = 1 if market_data['ema_20'].iloc[-1] > market_data['ema_50'].iloc[-1] else -1
            scores.append(ema_score)
            weights.append(2)
        
        # Momentum
        if 'rsi_14' in market_data:
            rsi = market_data['rsi_14'].iloc[-1]
            if rsi < 30:
                rsi_score = 1
            elif rsi > 70:
                rsi_score = -1
            else:
                rsi_score = (rsi - 50) / 50
            scores.append(rsi_score)
            weights.append(1.5)
        
        # MACD
        if 'macd_hist' in market_data:
            macd_hist = market_data['macd_hist'].iloc[-1]
            macd_hist_prev = market_data['macd_hist'].iloc[-2]
            
            if macd_hist > 0 and macd_hist > macd_hist_prev:
                macd_score = 1
            elif macd_hist < 0 and macd_hist < macd_hist_prev:
                macd_score = -1
            else:
                macd_score = 0
            scores.append(macd_score)
            weights.append(1.5)
        
        # Volume confirmation
        if 'volume_ratio' in market_data:
            volume_ratio = market_data['volume_ratio'].iloc[-1]
            price_change = market_data['close'].pct_change().iloc[-1]
            
            if volume_ratio > 1.5 and price_change > 0:
                volume_score = 1
            elif volume_ratio > 1.5 and price_change < 0:
                volume_score = -1
            else:
                volume_score = 0
            scores.append(volume_score)
            weights.append(1)
        
        # Bollinger Bands
        if 'bb_percent_20' in market_data:
            bb_percent = market_data['bb_percent_20'].iloc[-1]
            if bb_percent < 0.2:
                bb_score = 1
            elif bb_percent > 0.8:
                bb_score = -1
            else:
                bb_score = 0
            scores.append(bb_score)
            weights.append(1)
        
        # Calculate weighted average
        if scores:
            return np.average(scores, weights=weights)
        return 0
    
    def _calculate_prediction_score(self, predictions: Dict, current_price: float) -> float:
        """Calculate score from model predictions"""
        
        if not predictions or 'ensemble_prediction' not in predictions:
            return 0
        
        # Price change prediction
        predicted_price = predictions['ensemble_prediction']
        price_change_pct = (predicted_price - current_price) / current_price * 100
        
        # Convert to score (-1 to 1)
        if price_change_pct > 5:
            base_score = 1
        elif price_change_pct > 2:
            base_score = 0.7
        elif price_change_pct > 0.5:
            base_score = 0.3
        elif price_change_pct > -0.5:
            base_score = 0
        elif price_change_pct > -2:
            base_score = -0.3
        elif price_change_pct > -5:
            base_score = -0.7
        else:
            base_score = -1
        
        # Adjust by confidence
        confidence = predictions.get('confidence', 50) / 100
        
        # Adjust by prediction interval
        if 'prediction_interval' in predictions:
            interval_width = predictions['prediction_interval']['upper'] - predictions['prediction_interval']['lower']
            interval_ratio = interval_width / current_price
            certainty = max(0, 1 - interval_ratio)
        else:
            certainty = 0.5
        
        return base_score * confidence * certainty
    
    def _calculate_microstructure_score(self, microstructure: Dict) -> float:
        """Calculate score from market microstructure"""
        
        if not microstructure:
            return 0
        
        scores = []
        
        # Order flow imbalance
        if 'bid_ask_imbalance' in microstructure:
            imbalance = microstructure['bid_ask_imbalance']
            scores.append(np.clip(imbalance * 2, -1, 1))
        
        # Spread quality
        if 'spread_bps' in microstructure:
            spread = microstructure['spread_bps']
            if spread < 5:
                spread_score = 0.5
            elif spread < 10:
                spread_score = 0
            else:
                spread_score = -0.5
            scores.append(spread_score)
        
        # Market depth
        if 'market_depth_ratio' in microstructure:
            depth_ratio = microstructure['market_depth_ratio']
            if depth_ratio > 1.5:
                depth_score = 0.5
            elif depth_ratio < 0.67:
                depth_score = -0.5
            else:
                depth_score = 0
            scores.append(depth_score)
        
        # Price impact
        if 'price_impact' in microstructure:
            impact = microstructure['price_impact'].get('instantaneous', 0)
            if impact < 0.001:
                impact_score = 0.5
            elif impact < 0.005:
                impact_score = 0
            else:
                impact_score = -0.5
            scores.append(impact_score)
        
        return np.mean(scores) if scores else 0
    
    def _calculate_sentiment_score(self, sentiment: Dict) -> float:
        """Calculate score from sentiment analysis"""
        
        if not sentiment or 'aggregate' not in sentiment:
            return 0
        
        # Base sentiment score
        base_score = sentiment['aggregate']['score']
        
        # Adjust by confidence
        confidence = sentiment['aggregate'].get('confidence', 50) / 100
        
        # Check for divergence
        if all(source in sentiment for source in ['twitter', 'reddit', 'news']):
            scores = [
                sentiment['twitter'].get('score', 0),
                sentiment['reddit'].get('score', 0),
                sentiment['news'].get('score', 0)
            ]
            
            # Penalize divergence
            divergence = np.std(scores)
            confidence *= max(0.5, 1 - divergence)
        
        return base_score * confidence
    
    def _score_to_signal_type(self, score: float) -> SignalType:
        """Convert composite score to signal type"""
        
        if score >= 0.7:
            return SignalType.STRONG_BUY
        elif score >= 0.3:
            return SignalType.BUY
        elif score >= -0.3:
            return SignalType.HOLD
        elif score >= -0.7:
            return SignalType.SELL
        else:
            return SignalType.STRONG_SELL
    
    def _calculate_trading_parameters(self, 
                                    signal_type: SignalType,
                                    current_price: float,
                                    market_data: pd.DataFrame,
                                    predictions: Dict) -> Dict:
        """Calculate detailed trading parameters"""
        
        # ATR for volatility-based stops
        atr = market_data['atr_14'].iloc[-1] if 'atr_14' in market_data else current_price * 0.02
        
        # Entry price (may use limit orders)
        if signal_type in [SignalType.BUY, SignalType.STRONG_BUY]:
            entry_price = current_price * 0.999  # Slightly below market
        elif signal_type in [SignalType.SELL, SignalType.STRONG_SELL]:
            entry_price = current_price * 1.001  # Slightly above market
        else:
            entry_price = current_price
        
        # Stop loss
        if signal_type in [SignalType.BUY, SignalType.STRONG_BUY]:
            stop_loss = entry_price - atr * self.config.stop_loss_atr_multiplier
        elif signal_type in [SignalType.SELL, SignalType.STRONG_SELL]:
            stop_loss = entry_price + atr * self.config.stop_loss_atr_multiplier
        else:
            stop_loss = entry_price
        
        # Take profit levels
        take_profit_levels = []
        if signal_type != SignalType.HOLD:
            for ratio in self.config.take_profit_ratios:
                if signal_type in [SignalType.BUY, SignalType.STRONG_BUY]:
                    tp = entry_price + atr * ratio
                else:
                    tp = entry_price - atr * ratio
                take_profit_levels.append(tp)
        
        # Risk-reward ratio
        if signal_type != SignalType.HOLD and take_profit_levels:
            risk = abs(entry_price - stop_loss)
            reward = abs(take_profit_levels[0] - entry_price)
            risk_reward_ratio = reward / risk if risk > 0 else 0
        else:
            risk_reward_ratio = 0
        
        # Position sizing
        position_size = self._calculate_position_size(
            signal_type, 
            entry_price, 
            stop_loss,
            market_data,
            predictions
        )
        
        # Expected return
        if predictions and 'ensemble_prediction' in predictions:
            expected_price = predictions['ensemble_prediction']
            expected_return = (expected_price - entry_price) / entry_price
        else:
            expected_return = 0
        
        return {
            'entry_price': entry_price,
            'stop_loss': stop_loss,
            'take_profit_levels': take_profit_levels,
            'position_size': position_size,
            'risk_reward_ratio': risk_reward_ratio,
            'expected_return': expected_return
        }
    
    def _calculate_position_size(self,
                               signal_type: SignalType,
                               entry_price: float,
                               stop_loss: float,
                               market_data: pd.DataFrame,
                               predictions: Dict) -> float:
        """Calculate optimal position size"""
        
        if signal_type == SignalType.HOLD:
            return 0
        
        # Base position size from config
        base_size = self.config.max_position_size
        
        # Adjust for signal strength
        signal_multipliers = {
            SignalType.STRONG_BUY: 1.0,
            SignalType.BUY: 0.6,
            SignalType.SELL: 0.6,
            SignalType.STRONG_SELL: 1.0
        }
        
        size = base_size * signal_multipliers.get(signal_type, 0.5)
        
        # Kelly Criterion adjustment
        if self.config.use_kelly_criterion and predictions:
            win_probability = predictions.get('confidence', 50) / 100
            
            if 'accuracy_metrics' in predictions:
                historical_win_rate = predictions['accuracy_metrics'].get('win_rate', 0.5)
                win_probability = (win_probability + historical_win_rate) / 2
            
            avg_win = abs(predictions.get('expected_return', 0.02))
            avg_loss = abs(stop_loss - entry_price) / entry_price
            
            if avg_loss > 0:
                kelly_fraction = (win_probability * avg_win - (1 - win_probability) * avg_loss) / avg_win
                kelly_fraction = max(0, min(0.25, kelly_fraction))  # Cap at 25%
                size *= kelly_fraction / 0.25  # Scale by Kelly
        
        # Volatility adjustment
        if 'realized_volatility' in market_data:
            current_vol = market_data['realized_volatility'].iloc[-1]
            avg_vol = market_data['realized_volatility'].mean()
            
            if current_vol > avg_vol * 1.5:
                size *= 0.7  # Reduce size in high volatility
            elif current_vol < avg_vol * 0.5:
                size *= 1.2  # Increase size in low volatility
        
        # Risk per trade limit
        risk_amount = abs(entry_price - stop_loss) / entry_price * size
        if risk_amount > self.config.risk_per_trade:
            size = self.config.risk_per_trade / (abs(entry_price - stop_loss) / entry_price)
        
        return min(size, self.config.max_position_size)
    
    def _calculate_confidence(self, composite_score: float, predictions: Dict) -> float:
        """Calculate overall signal confidence"""
        
        # Base confidence from composite score
        base_confidence = min(100, abs(composite_score) * 100)
        
        # Adjust for prediction confidence
        if predictions and 'confidence' in predictions:
            prediction_confidence = predictions['confidence']
            base_confidence = (base_confidence + prediction_confidence) / 2
        
        # Adjust for model agreement
        if predictions and 'predictions' in predictions:
            model_predictions = list(predictions['predictions'].values())
            if len(model_predictions) > 1:
                cv = np.std(model_predictions) / np.mean(model_predictions)
                agreement_factor = max(0.5, 1 - cv)
                base_confidence *= agreement_factor
        
        return base_confidence
    
    def _determine_time_horizon(self, signal_type: SignalType, market_data: pd.DataFrame) -> str:
        """Determine optimal time horizon for the signal"""
        
        if signal_type == SignalType.HOLD:
            return "N/A"
        
        # Base on volatility and signal strength
        if 'atr_14' in market_data:
            atr_percent = market_data['atr_14'].iloc[-1] / market_data['close'].iloc[-1] * 100
            
            if atr_percent > 5:
                return "5-30 minutes"
            elif atr_percent > 2:
                return "30 minutes - 2 hours"
            elif atr_percent > 1:
                return "2-6 hours"
            else:
                return "6-24 hours"
        
        return "1-4 hours"
    
    def _generate_signal_reasons(self, 
                               technical_score: float,
                               prediction_score: float,
                               microstructure_score: float,
                               sentiment_score: float) -> List[str]:
        """Generate human-readable reasons for the signal"""
        
        reasons = []
        
        # Technical reasons
        if technical_score > 0.5:
            reasons.append("Strong technical indicators favor upward movement")
        elif technical_score < -0.5:
            reasons.append("Technical indicators suggest downward pressure")
        
        # Prediction reasons
        if prediction_score > 0.5:
            reasons.append("AI models predict significant price increase")
        elif prediction_score < -0.5:
            reasons.append("AI models predict price decline")
        
        # Microstructure reasons
        if microstructure_score > 0.3:
            reasons.append("Order flow shows strong buying pressure")
        elif microstructure_score < -0.3:
            reasons.append("Order flow indicates selling pressure")
        
        # Sentiment reasons
        if sentiment_score > 0.3:
            reasons.append("Market sentiment is bullish")
        elif sentiment_score < -0.3:
            reasons.append("Market sentiment is bearish")
        
        return reasons
    
    def _identify_risk_factors(self,
                             market_data: pd.DataFrame,
                             microstructure: Dict,
                             sentiment: Dict) -> List[str]:
        """Identify potential risk factors"""
        
        risks = []
        
        # Volatility risks
        if 'realized_volatility' in market_data:
            current_vol = market_data['realized_volatility'].iloc[-1]
            avg_vol = market_data['realized_volatility'].mean()
            
            if current_vol > avg_vol * 2:
                risks.append("Extremely high volatility")
            elif current_vol > avg_vol * 1.5:
                risks.append("Elevated volatility")
        
        # Liquidity risks
        if microstructure and 'spread_bps' in microstructure:
            if microstructure['spread_bps'] > 20:
                risks.append("Wide bid-ask spread")
            
            if microstructure.get('market_conditions', {}).get('thin_market'):
                risks.append("Low market liquidity")
        
        # Sentiment risks
        if sentiment and 'aggregate' in sentiment:
            if sentiment['aggregate'].get('confidence', 0) < 30:
                risks.append("Low sentiment confidence")
        
        # Technical risks
        if 'rsi_14' in market_data:
            rsi = market_data['rsi_14'].iloc[-1]
            if rsi > 80:
                risks.append("Extremely overbought conditions")
            elif rsi < 20:
                risks.append("Extremely oversold conditions")
        
        return risks
    
    def _detect_market_regime(self, market_data: pd.DataFrame) -> str:
        """Detect current market regime"""
        
        # Trend detection
        if 'ema_20' in market_data and 'ema_50' in market_data:
            ema20 = market_data['ema_20'].iloc[-1]
            ema50 = market_data['ema_50'].iloc[-1]
            
            if ema20 > ema50 * 1.02:
                trend = "uptrend"
            elif ema20 < ema50 * 0.98:
                trend = "downtrend"
            else:
                trend = "sideways"
        else:
            trend = "unknown"
        
        # Volatility regime
        if 'realized_volatility' in market_data:
            vol = market_data['realized_volatility'].iloc[-1]
            if vol > 0.5:
                vol_regime = "high_volatility"
            elif vol < 0.2:
                vol_regime = "low_volatility"
            else:
                vol_regime = "normal_volatility"
        else:
            vol_regime = "unknown"
        
        return f"{trend}_{vol_regime}"
    
    def _detect_volatility_regime(self, market_data: pd.DataFrame) -> str:
        """Detect volatility regime"""
        
        if 'realized_volatility' not in market_data:
            return "unknown"
        
        current_vol = market_data['realized_volatility'].iloc[-1]
        vol_percentile = (market_data['realized_volatility'] <= current_vol).mean() * 100
        
        if vol_percentile > 90:
            return "extreme_high"
        elif vol_percentile > 75:
            return "high"
        elif vol_percentile > 25:
            return "normal"
        elif vol_percentile > 10:
            return "low"
        else:
            return "extreme_low"
