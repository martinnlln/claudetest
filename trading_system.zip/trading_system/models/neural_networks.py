
# ===== models/neural_networks.py =====
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import TransformerEncoder, TransformerEncoderLayer
import numpy as np
from typing import Tuple, Dict, Optional

class TemporalFusionTransformer(nn.Module):
    """State-of-the-art Temporal Fusion Transformer for time series prediction"""
    
    def __init__(self, 
                 input_size: int,
                 hidden_size: int = 256,
                 num_heads: int = 8,
                 num_layers: int = 4,
                 dropout: float = 0.1):
        super().__init__()
        
        self.input_size = input_size
        self.hidden_size = hidden_size
        
        # Variable selection networks
        self.input_embeddings = nn.Linear(input_size, hidden_size)
        self.variable_selection = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, input_size),
            nn.Softmax(dim=-1)
        )
        
        # Temporal processing
        self.lstm_encoder = nn.LSTM(hidden_size, hidden_size, 
                                   num_layers=2, 
                                   batch_first=True,
                                   dropout=dropout)
        
        # Multi-head attention
        encoder_layer = TransformerEncoderLayer(
            d_model=hidden_size,
            nhead=num_heads,
            dim_feedforward=hidden_size * 4,
            dropout=dropout,
            activation='gelu'
        )
        self.transformer = TransformerEncoder(encoder_layer, num_layers=num_layers)
        
        # Prediction heads
        self.point_predictor = nn.Sequential(
            nn.Linear(hidden_size, hidden_size // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_size // 2, 1)
        )
        
        self.quantile_predictors = nn.ModuleList([
            nn.Linear(hidden_size, 1) for _ in range(9)  # 0.1 to 0.9 quantiles
        ])
        
    def forward(self, x: torch.Tensor, return_attention: bool = False) -> Dict[str, torch.Tensor]:
        batch_size, seq_len, _ = x.shape
        
        # Variable selection
        embedded = self.input_embeddings(x)
        weights = self.variable_selection(embedded)
        selected = embedded * weights.unsqueeze(-1).expand_as(embedded)
        
        # LSTM encoding
        lstm_out, _ = self.lstm_encoder(selected)
        
        # Transformer with positional encoding
        position_ids = torch.arange(seq_len, device=x.device).unsqueeze(0).expand(batch_size, -1)
        position_embeddings = self._positional_encoding(position_ids, self.hidden_size)
        transformer_input = lstm_out + position_embeddings
        
        # Self-attention
        transformer_out = self.transformer(transformer_input.transpose(0, 1)).transpose(0, 1)
        
        # Aggregate sequence
        aggregated = transformer_out.mean(dim=1)  # Global average pooling
        
        # Predictions
        point_prediction = self.point_predictor(aggregated)
        quantile_predictions = torch.cat([
            predictor(aggregated) for predictor in self.quantile_predictors
        ], dim=-1)
        
        outputs = {
            'prediction': point_prediction,
            'quantiles': quantile_predictions,
            'variable_weights': weights.mean(dim=1)  # Feature importance
        }
        
        if return_attention:
            outputs['attention'] = transformer_out
        
        return outputs
    
    def _positional_encoding(self, position_ids: torch.Tensor, d_model: int) -> torch.Tensor:
        """Sinusoidal positional encoding"""
        pe = torch.zeros(position_ids.shape[0], position_ids.shape[1], d_model, device=position_ids.device)
        position = position_ids.unsqueeze(-1).float()
        
        div_term = torch.exp(torch.arange(0, d_model, 2, device=position_ids.device).float() *
                           -(torch.log(torch.tensor(10000.0)) / d_model))
        
        pe[:, :, 0::2] = torch.sin(position * div_term)
        pe[:, :, 1::2] = torch.cos(position * div_term)
        
        return pe

class WaveNet(nn.Module):
    """WaveNet architecture for capturing long-range dependencies"""
    
    def __init__(self, 
                 input_channels: int,
                 residual_channels: int = 32,
                 skip_channels: int = 256,
                 dilations: List[int] = None):
        super().__init__()
        
        if dilations is None:
            dilations = [2**i for i in range(10)] * 2  # 2 cycles
        
        self.dilations = dilations
        self.residual_channels = residual_channels
        self.skip_channels = skip_channels
        
        # Input projection
        self.start_conv = nn.Conv1d(input_channels, residual_channels, kernel_size=1)
        
        # Dilated convolutions
        self.dilated_convs = nn.ModuleList()
        self.skip_convs = nn.ModuleList()
        
        for dilation in dilations:
            self.dilated_convs.append(
                nn.Conv1d(residual_channels, 2 * residual_channels, 
                         kernel_size=2, dilation=dilation, padding=dilation)
            )
            self.skip_convs.append(
                nn.Conv1d(residual_channels, skip_channels, kernel_size=1)
            )
        
        # Output projection
        self.end_conv1 = nn.Conv1d(skip_channels, skip_channels, kernel_size=1)
        self.end_conv2 = nn.Conv1d(skip_channels, 1, kernel_size=1)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x shape: (batch, channels, time)
        x = self.start_conv(x)
        
        skip_connections = []
        
        for i, (dilated_conv, skip_conv) in enumerate(zip(self.dilated_convs, self.skip_convs)):
            # Dilated convolution
            dilated = dilated_conv(x)
            
            # Gated activation
            filter_gate = torch.sigmoid(dilated[:, :self.residual_channels, :])
            input_gate = torch.tanh(dilated[:, self.residual_channels:, :])
            activated = filter_gate * input_gate
            
            # Skip connection
            skip = skip_conv(activated)
            skip_connections.append(skip)
            
            # Residual connection
            x = x + activated
        
        # Aggregate skip connections
        skip_sum = torch.stack(skip_connections, dim=0).sum(dim=0)
        
        # Output projection
        out = F.relu(skip_sum)
        out = self.end_conv1(out)
        out = F.relu(out)
        out = self.end_conv2(out)
        
        return out.squeeze(1)

class LSTMAttention(nn.Module):
    """LSTM with multi-head attention mechanism"""
    
    def __init__(self, 
                 input_size: int,
                 hidden_size: int = 128,
                 num_layers: int = 3,
                 num_heads: int = 8,
                 dropout: float = 0.2):
        super().__init__()
        
        self.lstm = nn.LSTM(
            input_size, 
            hidden_size, 
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout,
            bidirectional=True
        )
        
        self.attention = nn.MultiheadAttention(
            hidden_size * 2,  # Bidirectional
            num_heads=num_heads,
            dropout=dropout
        )
        
        self.layer_norm = nn.LayerNorm(hidden_size * 2)
        
        self.output_projection = nn.Sequential(
            nn.Linear(hidden_size * 2, hidden_size),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_size, 1)
        )
        
    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        # LSTM encoding
        lstm_out, _ = self.lstm(x)
        
        # Self-attention
        attended, attention_weights = self.attention(
            lstm_out.transpose(0, 1),
            lstm_out.transpose(0, 1),
            lstm_out.transpose(0, 1)
        )
        attended = attended.transpose(0, 1)
        
        # Residual connection and normalization
        lstm_out = self.layer_norm(lstm_out + attended)
        
        # Global pooling
        pooled = lstm_out.mean(dim=1)
        
        # Prediction
        output = self.output_projection(pooled)
        
        return output, attention_weights