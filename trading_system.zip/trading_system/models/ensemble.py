
# ===== models/ensemble.py =====
import numpy as np
import pandas as pd
from typing import List, Dict, Tuple, Optional
from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor
from sklearn.linear_model import Ridge, Lasso, ElasticNet
import xgboost as xgb
import lightgbm as lgb
import catboost as cb
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import mean_squared_error, mean_absolute_percentage_error
import optuna

class AdvancedEnsemble:
    """Advanced ensemble with automatic model selection and hyperparameter tuning"""
    
    def __init__(self, config: ModelConfig):
        self.config = config
        self.models = {}
        self.weights = {}
        self.feature_importance = {}
        self.performance_history = []
        
        # Initialize base models
        self._initialize_models()
        
    def _initialize_models(self):
        """Initialize all base models"""
        
        # Tree-based models
        self.models['xgboost'] = xgb.XGBRegressor(
            n_estimators=1000,
            max_depth=10,
            learning_rate=0.01,
            subsample=0.8,
            colsample_bytree=0.8,
            tree_method='gpu_hist' if self.config.use_gpu else 'hist'
        )
        
        self.models['lightgbm'] = lgb.LGBMRegressor(
            n_estimators=1000,
            max_depth=10,
            learning_rate=0.01,
            subsample=0.8,
            colsample_bytree=0.8,
            device='gpu' if self.config.use_gpu else 'cpu'
        )
        
        self.models['catboost'] = cb.CatBoostRegressor(
            iterations=1000,
            depth=10,
            learning_rate=0.01,
            task_type='GPU' if self.config.use_gpu else 'CPU',
            verbose=False
        )
        
        self.models['random_forest'] = RandomForestRegressor(
            n_estimators=500,
            max_depth=15,
            min_samples_split=5,
            n_jobs=-1
        )
        
        self.models['extra_trees'] = ExtraTreesRegressor(
            n_estimators=500,
            max_depth=15,
            min_samples_split=5,
            n_jobs=-1
        )
        
        # Linear models for diversity
        self.models['ridge'] = Ridge(alpha=1.0)
        self.models['lasso'] = Lasso(alpha=0.001)
        self.models['elastic_net'] = ElasticNet(alpha=0.001, l1_ratio=0.5)
        
    def optimize_hyperparameters(self, X: np.ndarray, y: np.ndarray, model_name: str):
        """Use Optuna for hyperparameter optimization"""
        
        def objective(trial):
            if model_name == 'xgboost':
                params = {
                    'n_estimators': trial.suggest_int('n_estimators', 100, 2000),
                    'max_depth': trial.suggest_int('max_depth', 3, 15),
                    'learning_rate': trial.suggest_float('learning_rate', 0.001, 0.3, log=True),
                    'subsample': trial.suggest_float('subsample', 0.5, 1.0),
                    'colsample_bytree': trial.suggest_float('colsample_bytree', 0.5, 1.0),
                }
                model = xgb.XGBRegressor(**params, tree_method='gpu_hist' if self.config.use_gpu else 'hist')
            
            elif model_name == 'lightgbm':
                params = {
                    'n_estimators': trial.suggest_int('n_estimators', 100, 2000),
                    'max_depth': trial.suggest_int('max_depth', 3, 15),
                    'learning_rate': trial.suggest_float('learning_rate', 0.001, 0.3, log=True),
                    'subsample': trial.suggest_float('subsample', 0.5, 1.0),
                    'colsample_bytree': trial.suggest_float('colsample_bytree', 0.5, 1.0),
                    'reg_alpha': trial.suggest_float('reg_alpha', 1e-8, 10.0, log=True),
                    'reg_lambda': trial.suggest_float('reg_lambda', 1e-8, 10.0, log=True),
                }
                model = lgb.LGBMRegressor(**params, device='gpu' if self.config.use_gpu else 'cpu')
            else:
                return float('inf')
            
            # Time series cross-validation
            tscv = TimeSeriesSplit(n_splits=3)
            scores = []
            
            for train_idx, val_idx in tscv.split(X):
                X_train, X_val = X[train_idx], X[val_idx]
                y_train, y_val = y[train_idx], y[val_idx]
                
                model.fit(X_train, y_train, eval_set=[(X_val, y_val)], early_stopping_rounds=50, verbose=False)
                pred = model.predict(X_val)
                score = mean_squared_error(y_val, pred, squared=False)
                scores.append(score)
            
            return np.mean(scores)
        
        study = optuna.create_study(direction='minimize')
        study.optimize(objective, n_trials=50, n_jobs=-1)
        
        return study.best_params
    
    def train(self, X: np.ndarray, y: np.ndarray, optimize: bool = False):
        """Train all models in the ensemble"""
        
        # Split data for validation
        split_point = int(len(X) * 0.8)
        X_train, X_val = X[:split_point], X[split_point:]
        y_train, y_val = y[:split_point], y[split_point:]
        
        model_scores = {}
        
        for name, model in self.models.items():
            try:
                # Optimize hyperparameters for key models
                if optimize and name in ['xgboost', 'lightgbm']:
                    best_params = self.optimize_hyperparameters(X_train, y_train, name)
                    if name == 'xgboost':
                        model = xgb.XGBRegressor(**best_params, tree_method='gpu_hist' if self.config.use_gpu else 'hist')
                    else:
                        model = lgb.LGBMRegressor(**best_params, device='gpu' if self.config.use_gpu else 'cpu')
                    self.models[name] = model
                
                # Train model
                if hasattr(model, 'fit') and hasattr(model, 'eval_set'):
                    model.fit(X_train, y_train, eval_set=[(X_val, y_val)], 
                             early_stopping_rounds=50, verbose=False)
                else:
                    model.fit(X_train, y_train)
                
                # Evaluate
                pred = model.predict(X_val)
                score = mean_squared_error(y_val, pred, squared=False)
                model_scores[name] = score
                
                # Extract feature importance
                if hasattr(model, 'feature_importances_'):
                    self.feature_importance[name] = model.feature_importances_
                
            except Exception as e:
                print(f"Error training {name}: {e}")
                model_scores[name] = float('inf')
        
        # Calculate ensemble weights based on performance
        self._calculate_weights(model_scores)
        
        # Store performance
        self.performance_history.append({
            'timestamp': pd.Timestamp.now(),
            'scores': model_scores,
            'weights': self.weights.copy()
        })
    
    def _calculate_weights(self, scores: Dict[str, float]):
        """Calculate optimal ensemble weights"""
        
        # Inverse error weighting
        valid_scores = {k: v for k, v in scores.items() if v != float('inf')}
        
        if not valid_scores:
            self.weights = {k: 1/len(self.models) for k in self.models.keys()}
            return
        
        # Convert to weights (lower error = higher weight)
        inverse_scores = {k: 1/v for k, v in valid_scores.items()}
        total_inverse = sum(inverse_scores.values())
        
        self.weights = {k: v/total_inverse for k, v in inverse_scores.items()}
        
        # Set zero weight for failed models
        for k in scores:
            if k not in self.weights:
                self.weights[k] = 0
    
    def predict(self, X: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Generate ensemble predictions with uncertainty estimates"""
        
        predictions = []
        
        for name, model in self.models.items():
            if self.weights.get(name, 0) > 0:
                try:
                    pred = model.predict(X)
                    predictions.append(pred * self.weights[name])
                except:
                    continue
        
        if not predictions:
            raise ModelPredictionError("No models available for prediction")
        
        # Weighted average
        ensemble_pred = np.sum(predictions, axis=0)
        
        # Uncertainty estimation (std of individual predictions)
        individual_preds = [model.predict(X) for name, model in self.models.items() 
                           if self.weights.get(name, 0) > 0]
        uncertainty = np.std(individual_preds, axis=0)
        
        return ensemble_pred, uncertainty
    
    def get_feature_importance(self) -> pd.DataFrame:
        """Aggregate feature importance across models"""
        
        if not self.feature_importance:
            return pd.DataFrame()
        
        # Weighted average of feature importances
        weighted_importance = np.zeros(len(next(iter(self.feature_importance.values()))))
        
        for name, importance in self.feature_importance.items():
            if name in self.weights:
                weighted_importance += importance * self.weights[name]
        
        return pd.DataFrame({
            'feature_importance': weighted_importance,
            'rank': np.argsort(weighted_importance)[::-1]
        })