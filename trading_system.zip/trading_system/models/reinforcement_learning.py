
# ===== models/reinforcement_learning.py =====
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from collections import deque
import random
from typing import Tuple, List, Dict

class TradingEnvironment:
    """Custom trading environment for RL"""
    
    def __init__(self, data: pd.DataFrame, initial_balance: float = 10000):
        self.data = data
        self.initial_balance = initial_balance
        self.reset()
        
    def reset(self) -> np.ndarray:
        self.current_step = 0
        self.balance = self.initial_balance
        self.position = 0
        self.trades = []
        self.equity_curve = [self.initial_balance]
        
        return self._get_state()
    
    def step(self, action: int) -> Tuple[np.ndarray, float, bool, Dict]:
        """Execute action and return new state, reward, done, info"""
        
        current_price = self.data.iloc[self.current_step]['close']
        
        # Actions: 0=hold, 1=buy, 2=sell
        if action == 1 and self.position == 0:  # Buy
            self.position = self.balance / current_price
            self.balance = 0
            self.trades.append(('buy', current_price, self.current_step))
            
        elif action == 2 and self.position > 0:  # Sell
            self.balance = self.position * current_price
            self.position = 0
            self.trades.append(('sell', current_price, self.current_step))
        
        # Calculate reward
        equity = self.balance + self.position * current_price
        reward = (equity - self.equity_curve[-1]) / self.equity_curve[-1]
        self.equity_curve.append(equity)
        
        # Move to next step
        self.current_step += 1
        done = self.current_step >= len(self.data) - 1
        
        info = {
            'equity': equity,
            'position': self.position,
            'balance': self.balance,
            'trades': len(self.trades)
        }
        
        return self._get_state(), reward, done, info
    
    def _get_state(self) -> np.ndarray:
        """Get current state representation"""
        
        if self.current_step >= len(self.data) - 1:
            return np.zeros(50)  # Terminal state
        
        # Include price data, technical indicators, and position info
        row = self.data.iloc[self.current_step]
        
        state = [
            row['close'] / row['open'] - 1,  # Price change
            row['volume'] / row['volume_sma'] if 'volume_sma' in row else 1,
            row['rsi'] / 100 if 'rsi' in row else 0.5,
            row['macd'] if 'macd' in row else 0,
            1 if self.position > 0 else 0,  # Position flag
            self.equity_curve[-1] / self.initial_balance - 1  # PnL
        ]
        
        # Add more features as available
        feature_cols = ['atr', 'adx', 'cci', 'mfi', 'volatility']
        for col in feature_cols:
            if col in row:
                state.append(row[col])
        
        return np.array(state, dtype=np.float32)

class DQNAgent:
    """Deep Q-Network agent for trading"""
    
    def __init__(self, state_size: int, action_size: int = 3, learning_rate: float = 0.001):
        self.state_size = state_size
        self.action_size = action_size
        self.memory = deque(maxlen=10000)
        self.epsilon = 1.0
        self.epsilon_min = 0.01
        self.epsilon_decay = 0.995
        self.learning_rate = learning_rate
        
        # Neural network
        self.q_network = self._build_model()
        self.target_network = self._build_model()
        self.update_target_network()
        
        self.optimizer = optim.Adam(self.q_network.parameters(), lr=learning_rate)
        
    def _build_model(self) -> nn.Module:
        """Build DQN model"""
        
        class DQN(nn.Module):
            def __init__(self, input_size, output_size):
                super().__init__()
                self.fc1 = nn.Linear(input_size, 128)
                self.fc2 = nn.Linear(128, 256)
                self.fc3 = nn.Linear(256, 128)
                self.fc4 = nn.Linear(128, output_size)
                self.dropout = nn.Dropout(0.2)
                
            def forward(self, x):
                x = torch.relu(self.fc1(x))
                x = self.dropout(x)
                x = torch.relu(self.fc2(x))
                x = self.dropout(x)
                x = torch.relu(self.fc3(x))
                x = self.fc4(x)
                return x
        
        return DQN(self.state_size, self.action_size)
    
    def remember(self, state, action, reward, next_state, done):
        """Store experience in replay buffer"""
        self.memory.append((state, action, reward, next_state, done))
    
    def act(self, state: np.ndarray) -> int:
        """Choose action using epsilon-greedy policy"""
        
        if np.random.random() <= self.epsilon:
            return random.randrange(self.action_size)
        
        state_tensor = torch.FloatTensor(state).unsqueeze(0)
        q_values = self.q_network(state_tensor)
        return np.argmax(q_values.detach().numpy())
    
    def replay(self, batch_size: int = 32):
        """Train the model on a batch of experiences"""
        
        if len(self.memory) < batch_size:
            return
        
        batch = random.sample(self.memory, batch_size)
        states = torch.FloatTensor([e[0] for e in batch])
        actions = torch.LongTensor([e[1] for e in batch])
        rewards = torch.FloatTensor([e[2] for e in batch])
        next_states = torch.FloatTensor([e[3] for e in batch])
        dones = torch.FloatTensor([e[4] for e in batch])
        
        current_q_values = self.q_network(states).gather(1, actions.unsqueeze(1))
        next_q_values = self.target_network(next_states).max(1)[0].detach()
        target_q_values = rewards + (1 - dones) * 0.99 * next_q_values
        
        loss = nn.MSELoss()(current_q_values.squeeze(), target_q_values)
        
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay
    
    def update_target_network(self):
        """Copy weights from main to target network"""
        self.target_network.load_state_dict(self.q_network.state_dict())